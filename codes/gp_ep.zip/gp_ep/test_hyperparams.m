corrects = [];
for gamma_i = .01:.05:5
    for gamma_u = .01:.05:5
        [conv, t, correct, pref_length, test_count] = run_hyper_ep('sushi20', -1,-1, gamma_u, gamma_i);
        correct
        corrects = [corrects;[gamma_i, gamma_u,correct]];
        dlmwrite('results/hyperparams20.csv', corrects);
    end    
end