function [t, t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
            util_loss, util_loss_std, wrongs, wrongs_std] = test_sparse_ep(suffix, D_u, D_it, option, utils)
    global entropy;
 
	% Item specific IVM
    if(D_u > 0 || D_it > 0)
    load(['cache/params_', suffix, '.mat']);
    
    tic        
        d = [];
        if strcmp(option, 'sparse_ep')
            entropy(entropy == 0) = -Inf;
            [e, idx] = sort(entropy, 'descend');
        else
            kl(kl == 0) = -Inf;
            [e, idx] = sort(kl, 'descend');
        end
        
        if D_u < size(u,1)
            sparse_users = sparse_users(idx); % [dummy idx1] 
            % sparse_users = sparse_users(idx1);
            sparse_users = sparse_users(1:D_u);
        else
            sparse_users = 1:size(u,1);
        end
        if D_it < size(x,1)
            s_temp = sparse_items(idx); % [dummy idx1]
            for ui = 1 : length(sparse_users)
                a = [1:D_it] + ((ui-1) * D_it);
                s{ui} = s_temp(a);
                d = [d, a];
            end
            sparse_items = s;
            %sparse_items = sparse_items(idx);            
            %sparse_items = sparse_items(1:D_it);
            %clear dummy;
        else
            sparse_items = size(x,1);
        end
       % D = length(sparse_users) * length(sparse_items);
        idx = idx(d); %idx(1:D);
        Sigma = Sigma(idx, idx);
        nu = nu(idx);   
        t = toc ;

        [t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
            util_loss, util_loss_std, wrongs, wrongs_std] = test_preference(sparse_users, sparse_items, ...
            nu, x, u, pref, pref_test, covfunc_u, covfunc_x, params_u, params_it, option, utils);

    end    
return ;
