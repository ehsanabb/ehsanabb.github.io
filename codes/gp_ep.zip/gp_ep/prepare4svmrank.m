function [users item_count item_dim] = prepare4svmrank(suffix)

x = dlmread(strcat('data/x_' , suffix , '.csv'));
u = dlmread(strcat('data/u_' , suffix , '.csv'));
pref = dlmread(strcat('data/pref_', suffix , '.csv'));
%pref_test = dlmread(strcat('data/pref_' , suffix , '_test.csv'));
p_test = strcat('data/pref_' , suffix , '_test.csv');

users = writepref(pref, x, u, suffix, 'pref');
item_dim = size(x,2);
item_count = size(x,1);

test_no = 10;
if(isstr(p_test))
   file_path = p_test;
   for i = 1 : test_no
       pt = strrep(file_path, '.csv', strcat('.', int2str(i), '.csv'));
       p_test1 = dlmread( pt );
       writepref(p_test1, x, u, suffix, ['pref_test' num2str(i)]);
   end
end
% writepref(pt, x, u, suffix, 'pref_test');
%dlmwrite(strcat('data/pref_svmrank_', suffix, '.txt'), pref_out);
return ;

function [users] = writepref(pref, x, u, suffix, name)
pref_out = {};
    idx = 1;
    qid = 1;
    prev_u = -1;
    users = [];
    
    for uu = 1 : size(u,1)
        p = pref(pref(:,1) == uu,:);
        users = [users; uu];
        
        for i = 1 : size(p, 1)            
            s = [int2str(idx) ' qid:'  num2str(qid)  ' '  getrow(pref(i,2), u,x) ''];%  ' ', getrow(pref(i,3), u,x)];
            pref_out{idx} = s;
            idx = idx + 1;
            s = [int2str(idx) ' qid:'  num2str(qid)  ' '  getrow(pref(i,3), u,x)];%  ' ', getrow(pref(i,3), u,x)];
            pref_out{idx} = s;
            fid = fopen(strcat('data/svmrank/', name, '_', suffix, '_', int2str(uu), '_', ...
                            num2str(i), '.dat') , 'w');
            fprintf(fid,'%s\n', pref_out{[idx-1, idx]});
            fclose(fid);
            idx = idx + 1;
            qid = qid + 1;          
        end
        
        fid = fopen(strcat('data/svmrank/', name, '_', suffix, '_', int2str(uu),'.dat') , 'w');
        fprintf(fid,'%s\n', pref_out{:});
        fclose(fid);
        pref_out = {};
        idx = 1;
        qid = 1;
    end
    
    
%     for i = 1 : size(pref, 1)        
%         if(prev_u == -1)
%             prev_u = pref(i,1);
%         end
%         
%         if(pref(i,1) ~= prev_u)
%             system ('rm data/svmrank/', name, suffix, '_', int2str(prev_u),'.dat');
%             %system ('rm data/svmrank/pref_test_', suffix, '_', int2str(prev_u),'.dat');
%                 fid = fopen(strcat('data/svmrank/', name, '_', suffix, '_', int2str(prev_u),'.dat') , 'w');
%                 fprintf(fid,'%s\n', pref_out{:});
%                 pref_out = {};
%                 prev_u = -1;
%                 idx = 1;
%                 qid = 1;
%         end
%         
%         s = [int2str(idx) ' qid:'  num2str(qid)  ' '  getrow(pref(i,2), u,x) ''];%  ' ', getrow(pref(i,3), u,x)];
%         pref_out{idx} = s;
%         idx = idx + 1;
%         s = [int2str(idx) ' qid:'  num2str(qid)  ' '  getrow(pref(i,3), u,x)];%  ' ', getrow(pref(i,3), u,x)];
%         pref_out{idx} = s;
%         idx = idx + 1;
%         qid = qid + 1;
%      end

return ;

function s = getrow(p, u, x)
s = '';
for i = 1 : size(x, 2)
%    if (i < size(x, 1))
%        s = [s ' '];
%    end
    s = [s int2str(i) ':' num2str(x(p,i)) ' '];
end
return ;