function [k d] = ard_kernel(x1, x2, M, sigma1, sigma2)
if (norm(x1-x2) == 0)
    delta = 1;
else
    delta = 0;    
end

dif = (x1 - x2);
if(size(dif, 1) == 1)
    val = dif * M * dif';    
    d = dif * dif';
else
    val = dif' * M * dif;
end;

k = sigma1^2 * exp(-.5 * val ) + sigma2^2 * delta;
end