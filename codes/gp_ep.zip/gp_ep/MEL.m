function [index, f_best, mel, S_tmp] = MEL(u, ui, x, m, sig_inv, indeces, option, f_best)
    global covfunc_u covfunc_x params_u params_it item_count;

    idx = indeces + item_count .* (ui-1) .* ones(size(indeces));
    mu = m(idx); %indeces
    
%     if option == 1
%         f_best = max(mu + .5*diag(sig_inv(idx,idx)));
%     elseif option == 2
%         f_best = max(mu);
%     elseif option == 3
%         f_best = normmax(mu, sig_inv(idx, idx)); %
% 	elseif option == 4 || option == 5
%         [m,s]=normmax(mu, sig_inv(idx, idx)); %
%         f_best = m + s;
%     end 
    mel = -Inf;
    index = -1;
    
    for i = indeces        
        if option == 1
            start = item_count .* (ui-1);
            best_f = max(m(start + i) + .5*diag(sig_inv(start + i, start + i)), f_best);
        elseif option == 2
            best_f = max(mu(start + i), f_best);     
        end 
        
        % if f_best is changed, reflect it to the returing value.
        f_best = max(f_best, best_f);
        
        if option == 5 || option == 1 || option == 2 % notice here ....
            S_tmp = sig_inv(i,i);
        else            
            [ks ku kx] = computeKStar(u, 1:size(u,1), x, indeces, u(ui,:), [x(i,:); x(2,:)], ...
                                covfunc_u, covfunc_x, params_u, params_it);
            idx = indeces;
            for j = [1 : size(u,1)-1]
                idx = [idx,indeces + item_count .* j .* ones(size(indeces))];
            end
            %ks = ks(1,:);
            S_tmp = ks * sig_inv(idx, idx) * ks';
            [ks ku kx] = computeKStar(u, [ui], x, [i,i], u(ui,:), [x(i,:); x(i,:)], covfunc_u, ...
                                        covfunc_x, params_u, params_it);
            S_tmp = kron( ku(1,1), kx ) - S_tmp; % (1,1)
        end

        s = sqrt( max(abs( S_tmp(1, 1) ), .00001) );
        [ei] = computeEI(best_f, m(i), s); 
        if(ei > mel)
             mel = ei; 
             index = i;
            % fprintf(FID, ' >> user: %d, item_idx: %d, mel: %d\n', ui, index, full(mel));
        end   
    end
    
	% fprintf(FID, 'user: %d, item_idx: %d, mel: %d\n', ui, index, full(mel));
            
return ;

function [ei] = computeEI(f_best, mu, s)
    %item = itemOffsets(u, i, i, item_count);
    z = (mu - f_best) / s;
    ei = s * (z * normcdf(z) + normpdf(z));
return ;