function  [params_u, params_it] = load_kernel_params(suffix)
[path, s] = kernel_path(suffix);
    try 
        if strcmp(s, 'car_sp')
            x = dlmread(strcat('data/x_', suffix, '.1.csv'));
            u = dlmread(strcat('data/u_', suffix , '.1.csv'));
            params_u{1,1} = 'sigma1';
            params_u{2,1} = 'sigma2';
            params_u{3,1} = 'M';
            params_u{1,2} = 1;
            params_u{2,2} = 1;
            params_u{3,2} = eye(size(u,2) ) + ones(size(u,2));

            params_it{1,1} = 'sigma1';
            params_it{2,1} = 'sigma2';
            params_it{3,1} = 'M';
            params_it{1,2} = 1;
            params_it{2,2} = 1;
            coef = 1e5;                
            params_it{3,2} = eye(size(x,2) ) + coef*ones(size(x,2) );        
            return;
        end        
        
    load (path);
    fprintf('Using kernel in [%s].\nRemove and run again if you feel this is not useful for this dataset\n', path);
    catch ex
        if strcmp( ex.identifier,  ['MATLAB:load:couldNotReadFile'])
            if isempty( strfind(path, '_identity') )
               % if ~isempty( strfind(suffix, 'car2') )
               %     s = [s '2'];
               % end
              %  if strcmp(s, 'fb')
              %      NUM = 20;
              %  else
              %      NUM = 50;
              %  end
              %  a = [s num2str(NUM)];
                a = suffix;
                NUM = str2num( strrep(suffix, s, '') );
                fprintf('The kernel is not in the cache. Trying to optimize it with %s ....\n', a);
                prepare(s, NUM,1,1);
                test_optimize_kernel(a);
                load (path);
            else
                fprintf('Using identity kernel\n');
                params_u{1,1} = 'sigma1';
                params_u{2,1} = 'sigma2';
                params_u{3,1} = 'M';
                params_u{1,2} = 0;
                params_u{2,2} = 1;
                params_u{3,2} = 0;
                
                params_it{1,1} = 'sigma1';
                params_it{2,1} = 'sigma2';
                params_it{3,1} = 'M';
                params_it{1,2} = 0;
                params_it{2,2} = 1;
                params_it{3,2} = 0;                
            end
        else
            fprintf('%s', ['run_ep: ' ex.message]);
        end
    end
end