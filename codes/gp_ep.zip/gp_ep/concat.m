clear 

a = dlmread('results/car_sp_ecml.csv'); % car_sp1_ecml.csv'); 
b = dlmread('results/accuracy_time_car_sp_22.04.2013.22.24.csv');

% a = car_sp1_ecml;
a(a(:,3) == 7,:) = [];
a = [a;b(b(:,3) == 7,:)];

dlmwrite('results/car_sp1_1_ecml.csv', b);

plot_accuracy('car_sp1_1_ecml.csv', 'car_sp', 60, 40)


clear 

a = dlmread('results/fb.csv'); % car_sp1_ecml.csv'); 
b = dlmread('results/accuracy_time_fb_22.04.2013.19.15.csv');

% a = car_sp1_ecml;
a(a(:,3) == 7,:) = [];
a = [a;b(b(:,3) == 7,:)];

dlmwrite('results/fb_ecml.csv', b);

plot_accuracy('fb_ecml.csv', 'fb', 20, 40)

