function item_count = prepare_car(user_count, suffix, no_folds, replication)

if ~exist('suffix', 'var')
    s = strcat('car', int2str(user_count));
else
    s = strcat(suffix, int2str(user_count));
end

if replication > 0
    s = strcat(s, '.', num2str(replication));
end

if exist(strcat('data/x_', s, '.csv'), 'file')
	fprintf('%s\n', [s ' exists.']);
    x = dlmread(strcat('data/x_', s, '.csv'));
    item_count = size(x,1);
 %   return ;
end

u = dlmread('../amazonturk/users1.csv', ',');
x = dlmread('../amazonturk/items1.csv', ',');
prefs = dlmread('../amazonturk/prefs1.csv', ',');

item_count = size(x,1);

u = u(1:user_count,2:end);
u = add_idx(u);
p = [];
p_test = [];

for i = 1 : user_count
   t = prefs(prefs(:,1)==i,:);
   l = size(t,1);
   r = randperm(l, int64(l*(3./5.)) ); %was 2/3
   tmp = t(r,:);
   p = [p;tmp];
   tmp=t(~ismember(1:l,r),:);
   p_test = [p_test;tmp];
end

dlmwrite(strcat('data/x_', s, '.csv'), x);
dlmwrite(strcat('data/u_', s, '.csv'), u);
dlmwrite(strcat('data/pref_', s, '.csv'), p);
dlmwrite(strcat('data/pref_', s, '_test.csv'), p_test);
%-----------
partition_csv(strcat('data/pref_', s, '_test.csv'), no_folds);
%-----------
return ;
