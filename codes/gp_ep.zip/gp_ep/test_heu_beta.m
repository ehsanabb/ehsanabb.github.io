function test_heu_beta(suffix, D_it)

for beta = -1 : 1 : 1
      for j = 1 : length(D_it)
      	for alpha = -1 : 1 : 1
            for n = 5 : 10 : 75
                try
              [t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, pref_loss_std2, ...
                    util_loss2, util_loss_std2, wrongs2, wrongs_std2] = ...
                        test_heuristics([suffix num2str(n)], 10, D_it(j), [], beta, alpha);
                catch ex
                    fprintf('%s', ['test_heu_beta: ' ex.message]);
                end
            end
        end
%        [t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%            pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = ...
%            add_test_pref_results(t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
%                pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2, ...
%                t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%                pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std);
      end
end

return ;