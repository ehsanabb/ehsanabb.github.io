% generate samples from the GPPE model
function generate_samples_model(M, N)
%clear all;
   
%path(path(), '/Users/edwinbonilla/Documents/Matlab/gpml-matlab/gpml');
%path(path(), '/Users/edwinbonilla/Documents/Matlab/Netlab');
%path(path(), '/Users/edwinbonilla/Documents/Matlab/utils');

if (ischar(M)) 
    M = str2double(M); 
end

path(path(), './external');
path(path(), './scripts');


%rand('state',18);
%randn('state',20);

%% General settings here
covfunc_t = 'covSEard';
covfunc_x = 'covSEard';
%M = 10;    % Number of training users
%N = 10;   % Number of items
Ntrain_ratio = 1; % How many training pairs to use
D_x = 3; % dimensionality of the input data (item features)
D_t = 2; % Dimesionality of user feaures
sigma = 0.1;
EPSILON = sigma*randn;
LEARN_GP = 1;
GENERATE_DATA = 0; % 0: load from previous run

if (GENERATE_DATA) 
    %% Generating features and latent functions
    t = 5*(rand(M,D_t)-0.5);
    x = 15*(rand(N,D_x)-0.5);
    
    logtheta_x = zeros(D_x+1,1);
    logtheta_t = zeros(D_t+1,1);
    theta = [logtheta_t; logtheta_x; log(sigma)];

    Kt = feval(covfunc_t, logtheta_t, t);
    Kx = feval(covfunc_x, logtheta_x, x);

    % K is the kronecker product Kf (x) Kx
    jitter = 1;
    K  = kron(Kt, Kx);

    % now genereates the targets Y: gaussian mean 0 cov K
    % we sample this multivariate gaussian distribution N(mu,K)
    n = N*M;
    mu = zeros(n,1);
    f = mu + chol(K)'*randn(n,1);
    F = reshape(f,N,M);
    %plot(F);

    idx_pairs =  combnk(1:N, 2); % all possible pairs
    
    Y = ( F(idx_pairs(:,1) ,:) - F(idx_pairs(:,2),:) ) > EPSILON;
    
    % For each user we create a cell that contains the ordered pairs
    all_pairs = cell(1,M);
    for j = 1 : M
        tmp_pairs = idx_pairs;
        idx_0 = find(Y(:,j) == 0); % indices in reverse order
        tmp_pairs(idx_0,:) = fliplr(idx_pairs(idx_0,:));
        all_pairs{j} = tmp_pairs;
    end
    
    
    %% Assigning training and testing data
    Mtrain = M-1;
    test_idx = M;
    Npairs_train = floor(size(idx_pairs,1)*Ntrain_ratio);
    train_pairs = get_training_pairs( all_pairs, Mtrain, Npairs_train);
    test_pairs  = all_pairs{test_idx};
    train_t = t(1:Mtrain,:);
    test_t = t(test_idx,:);
    ftest = F(:,test_idx);

    
    %% get indices for later computations
    % We compute here the global index of all training pairs
    [idx_global_1, idx_global_2] = compute_global_index(train_pairs, N);
    idx_global = unique([idx_global_1; idx_global_2]);
    [ind_x ind_t] = ind2sub([N M], idx_global); % idx of seen points and tasks
    
    %% saving dat for C++ code and for elicitation queries on toydata
    DataTr = convert_pairs_to_matrix(train_pairs);
    save('toydata.mat', 'F', 'train_pairs', 'test_pairs', 'ftest', 'train_t', 'x', ...
        'test_t', 'idx_global', 'DataTr', 'ind_x', 'ind_t', 'K', 'test_idx', 'Kx', ...
        'Kt', 'theta', 'idx_pairs');

else
    load('toydata.mat');

end
%% Checking gradients of the conditional likelihood
% check_gradient_f(train_pairs, sigma, M, N);
% check_hessian_f(train_pairs, sigma, M, N);
 
% P = zeros(size(Y,1),1);
%[f Kx, Kinv, W, L]  = approx_gppe_laplace_fast(covfunc_t, covfunc_x, ...
%theta, train_t, x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N);


%% making predictions on a new user
% make_predictions_new_user(Y, M, N, idx_pairs, covfunc_t, covfunc_x, ...
% theta, f, Kx, Kinv, W, L, train_t, x, idx_global, ind_t, ind_x, test_t);

%% We do elicitation process here 
% maximum_expected_loss_gppe(covfunc_t, covfunc_x, theta, f, Kx, Kinv,...
%      W, L, t, x, idx_global, ind_t, ind_x, test_t, 1 : N);


%% Here we test the elicitation stuff
 ptr_query_func = @make_query_toydata;
 ptr_stop_func = @stop_query_toydata;
 evoi = elicitate_gppe(covfunc_t, covfunc_x, theta, train_t, x, train_pairs, ...
    test_t, test_idx, idx_pairs, ptr_query_func, ...
    ptr_stop_func);
% save('tmp.mat', 'train_pairs', 'evoi', 'idx_pairs');



%% here we check gradients of the marginal log-likelihood
% check_gradients_marginal_lohlikelihood(covfunc_t, covfunc_x, ...
%     theta, train_t, x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N);

% Learn model with scaled conjugate gradient
%theta_learned = learn_gppe_with_netlab(covfunc_t, covfunc_x, ...
%    theta, train_t, x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N);


%% Learn model using Carl Rassmussen's minimize
%profile on;
%if (LEARN_GP)
    tic;
    % Initialization is a big issue
    %theta0 = zeros(size(theta)); %rand(size(theta));
%    theta0= theta;
%    theta_learned = learn_gppe_with_minimize(covfunc_t, covfunc_x, ...
%        theta0, train_t, x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N);
%    toc;
%    theta_learned
%else
%    load('theta_learned.mat');
%end
%profile viewer;

%% Making predictions after learning hyper-param
%test_idx = M; ftrue = F(:,test_idx); ytrue = Y(:,test_idx); test_t = t(test_idx, :);
% make_predictions_new_user(covfunc_t, covfunc_x, theta_learned, train_t, x, ...
%     train_pairs,idx_global, ind_t, ind_x, test_t, idx_pairs, ftrue, ytrue);

 
 return;

%% function make_predictions_new_user
% Make predictions on a new user
function make_predictions_new_user(covfunc_t, ...
    covfunc_x, theta, train_t, x, train_pairs, idx_global, ...
    ind_t, ind_x, test_t, idx_pairs, ftrue, ytrue)
N      = size(x,1);
Mtrain = size(train_t,1);

% get the f values first
[f Kx, Kinv, W, L]  = approx_gppe_laplace(covfunc_t, covfunc_x, ...
    theta, train_t, x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N);

Npairs = size(idx_pairs,1);
Fstar  = NaN(N,Npairs);
for i = 1 : Npairs
    pair = idx_pairs(i,:);
    [p mustar] = predict_gppe_laplace(covfunc_t, covfunc_x, theta, f, Kx, ...
        Kinv, W, L, train_t, x, idx_global, ind_t, ind_x, test_t, pair);
    P(i,1) = p;
    
    Fstar([pair(1), pair(2)],i) = mustar;
    % mu
    % F(pair, M)
end
fstar = mynanmean(Fstar, 2);

% P is the preditive probabilities of the pair being a > relationship
ypred = P > 0.5;
fprintf('error=%.2f\n', sum(ytrue ~= ypred,1)/size(ytrue,1));


% ystar = ( fstar(idx_pairs(:,1)) - fstar(idx_pairs(:,2)) ) > EPSILON; 


% Plotting the underlying utility functions
%plot(ftrue, fstar, '.');
plot(ftrue, 'b'); hold on; plot(fstar, 'r');

[val, idx_true] = sort(ftrue, 'descend');
[val, idx_pred] = sort(fstar, 'descend');
% [idx_true, idx_pred]

return;




%% get training pairs
function train_pairs = get_training_pairs( all_pairs, Mtrain, Ntrain)
all_pairs = all_pairs(1:Mtrain);
train_pairs = cell(Mtrain,1);
for j = 1 : Mtrain
    pairs = all_pairs{j};
    idx   = randperm(size(pairs,1));
    idx   = idx(1:Ntrain);
    train_pairs{j} = pairs(idx, :);
end

return;



%% check_gradient_f
function check_gradient_f(train_pairs, sigma, M, N)
% First derivatives working good!
delta = zeros(M*N, 10);
for j = 1 : 10
    f = rand(M*N,1);
    [gradient, delta(:,j)] = gradchek(f', @log_likelihood_gppe, ...
        @deriv_log_likelihood_gppe, sigma, train_pairs, M, N);
end
hist(delta(:));
return;


%% check_hessian_f
function check_hessian_f(train_pairs, sigma, M, N)
% Second derivatives working good!
% Checking the Hessian here
delta = zeros(M*N*M*N,10);
for j = 1 : 10
    f = rand(M*N,1);
    [h hcent delta(:,j)] = myhesschek(f, @log_likelihood_gppe, ...
        @deriv2_log_likelihood_gppe, sigma, train_pairs, M, N);
end
hist(delta(:));

return;

%% check_gradients_marginal_lohlikelihood
function check_gradients_marginal_lohlikelihood(covfunc_t, covfunc_x, ...
    theta, train_t, x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N)
ptr_func      = @negative_marginal_log_likelihood;
ptr_gradfunc = @gradient_negative_marginal_loglikelihood; 
delta = zeros(length(theta), 10);
for j = 1 : 10
    theta = rand(size(theta));
    [gradient, delta(:,j)] = gradchek(theta', ptr_func, ...
        ptr_gradfunc, covfunc_t, covfunc_x,  train_t, ...
        x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N);
end
figure;
hist(delta(end,:));
save('delta.mat', 'delta');



%%  learn_gppe_with_netlab
function theta_learned = learn_gppe_with_netlab(covfunc_t, covfunc_x, ...
    theta, train_t, x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N)
PRECISION = 1e-4;
MAXITER   = 100;
options = foptions();
options(1)  = 1; % Shows error values
options(2)  = PRECISION;
options(3)  = PRECISION;
options(14) = MAXITER;
options(15) = PRECISION;

ptr_func      = @negative_marginal_log_likelihood;
ptr_gradfunc = @gradient_negative_marginal_loglikelihood; 
[theta_learned, options, flog] = scg(ptr_func, theta', options, ...
    ptr_gradfunc, covfunc_t, covfunc_x, train_t, x, train_pairs, ...
    idx_global, ind_t, ind_x, Mtrain, N);

save('tmp.mat', 'theta_learned', 'options', 'flog');
return;


%% Learn things with minimize function
function theta_learned = learn_gppe_with_minimize(covfunc_t, covfunc_x, ...
    theta, train_t, x, train_pairs, idx_global , ind_t, ind_x, Mtrain, N)
ptr_func = @learn_gppe;
MAXITER = 100; % Line searches

[theta_learned, nl, niter] = minimize(theta, ptr_func, MAXITER, ... 
    covfunc_t, covfunc_x, train_t, x, train_pairs, idx_global, ...
    ind_t, ind_x, Mtrain, N);

save('theta_learned.mat', 'theta_learned', 'nl', 'niter');

return;





function pairs = convert_pairs_to_matrix(cell_pairs)
pairs = [];
for i = 1 : length(cell_pairs)
    pairs = [pairs; [repmat(i, size(cell_pairs{i},1), 1), cell_pairs{i}]];
end





















