function [ Y ] = add_idx( X )

%Y = zeros(size(X,1), size(X,1) + size(X,2));
%Y(1:size(X,1),1:size(X,2)) = X;
%    for i = 1 : size(X,1)
%     Y(i,i + size(X,2)) = 1;   
%    end

Y = [X,eye(size(X,1))];
end