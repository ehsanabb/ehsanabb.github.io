function [ K ] = polynomial_kernel_m( d,  X )
    K = zeros(size(X,1), size(X,1));

    for i = 1 : size(X,1)
        for j = 1 : i
           dd = X(i,:) * X(j,:)';
           K(i,j) = (dd + 1)^d; %exp( -d );
           K(j,i) = K(i,j);
        end
    end 
end

