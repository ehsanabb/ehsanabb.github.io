_runa=rand(3,3);
b=rand(2,2);
c=rand(10,3);
d=3;
e=5;

mex ep_efficient.c -lmwlapack


[k sigma nu mu entropy sparse_items sparse_users S_tilde entropy_ivm] = ep_efficient(a,b,c,d,e) ;

sigma
entropy_ivm
