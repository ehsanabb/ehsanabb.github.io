function [t, t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
            util_loss, util_loss_std, wrongs, wrongs_std] = test_ivm(suffix, D_u, D_it, utils)
% [t, t_test, c_mean, c_std, test_count, pref_loss, util_loss]

	% original IVM
    p = [];
     try
        if(D_u > 0 || D_it > 0)
            load(['cache/params_', suffix, '.mat']);
            tic
            [sparse_items, sparse_users idx] = find_ivm_items(x,u, pref, entropy_ivm, D_u, D_it);
            
            idx(find(idx == 0))=1;
            Sigma = Sigma(idx, idx);
            nu = nu(idx);
            t = toc ;

            [t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
                        util_loss, util_loss_std, wrongs, wrongs_std] = test_preference(sparse_users, sparse_items, ...
                nu, x, u, pref, pref_test, covfunc_u, covfunc_x, params_u, params_it, 'ivm_ep1', utils);

            test_ivm2 = false;
            if test_ivm2            
                x_idx = cell2mat(sparse_items);
                x_idx(x_idx < 1) = [];
                [dummy, ii] = unique(x_idx(:), 'first');
                x_idx = x_idx(sort(ii));
                if length(x_idx) > D_it
                    x_idx = x_idx(1:D_it);
                end

                [K_u] = feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u(sparse_users, :));  
                [K_it] = feval (covfunc_x, params_it{1,2}, params_it{2,2}, params_it{3,2}, x(x_idx, :)); 

                p = pref(ismember(pref(:,1), sparse_users) & ismember(pref(:,2), x_idx) & ismember(pref(:,3), x_idx),:);
                for i = 1 : length(x_idx)
                    if ~isempty(p) && size(p,1)>= i
                         p(find(p(:,2) == x_idx(i)),2) = i;
                         p(find(p(:,3) == x_idx(i)),3) = i;
                    end
                end
                [k_inv, Sigma, nu, mu] = ep_efficient_inverse_sparse(...
                                    K_u, K_it,p , 3, size(x_idx,1));

                clear S_tilde k_inv
               % sig = inv(Sigma);
               % nu = sig * mu;

                % IVM with re-inference in EP
                [t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
                            pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2] ...
                                = test_preference(sparse_users, sparse_items, nu, x, u, pref, ...
                                pref_test, covfunc_u, covfunc_x, params_u, params_it, 'ivm_ep2', utils);

                [t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
                            pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = add_test_pref_results( ...
                                    0, t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
                            pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2, ...
                            t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
                            pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std);
            end
        end
    catch err
        t = 0;
        t_test=0;
        c_mean=0;
        c_std=0;
        test_count=0;
        pref_loss=0;
        pref_loss_std=0;
        util_loss=0;
        util_loss_std=0;
        wrongs=0;
        wrongs_std=0;
        pref_length=0;
        fprintf('%s\n', ['test_ivm: ' err.message]);
    end
   
  return ;
 
 
