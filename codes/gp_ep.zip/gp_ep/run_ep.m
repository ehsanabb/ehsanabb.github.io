function [conv, t, c_mean, c_std, pref_length, test_count, t_test loss util_loss] = run_ep(suffix, D_u, D_it, replication)
   [params_u, params_it] = load_kernel_params(suffix);
   [t, c_mean, c_std, pref_length, test_count, t_test loss util_loss] = ...
    		run_hyper_ep(suffix, D_u, D_it, params_u, params_it, replication);
    		conv = [];
return;       
