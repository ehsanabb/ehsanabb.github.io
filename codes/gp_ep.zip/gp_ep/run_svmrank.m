function [t,  c_mean, c_std, test_count, t_test] = run_svmrank(suffix, iteration)    
    
    %% If the kernel is not learnt, let's learn it then
    kernel_file = ['cache/kernels_', suffix, 'svmrank.mat'];
    if ~exist(kernel_file, 'file')
        [m sigma1 sigma2] = cross_validate_svmrank(suffix);
    else
        load (kernel_file);
        % num2str(params_it{3,2})
        [s1 s2] = system( ['cd ../svm_rank_linux && sh prepare.sh ' num2str(m_max) ' ' ...
                num2str(sigma1_max) ' ' num2str(sigma2_max)] ); % prepare.sh M sigma1 sigma2
        fprintf(s2);
        fprintf('\n------------\n');
    end
    
    original_suffix = suffix;
    FID_RESULTS = get_results_file(suffix);
    fprintf(FID_RESULTS, 'test\n');
    
    %% Let's run it for each user
    c_mean = [];
    for u = iteration
        prepare(original_suffix, u);
        [users item_count item_dim] = prepare4svmrank([suffix num2str(u)]);        
        [t,  c_mean, c_std, loss, loss_std, util_loss, util_loss_std, wrongs, wrongs_std, ... 
                test_count, t_test] = test_svmrank([suffix num2str(u)], users, item_count);   
        if ~isempty(FID_RESULTS)
            fprintf(FID_RESULTS, '%d, %d, %d, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.1f, %2.2f\n', ...
                item_dim, u, alg_id('svmrank'), c_mean, c_std, ...
                loss, loss_std, util_loss, util_loss_std, wrongs, wrongs_std, test_count, t_test);    
        end
    end;
	fclose('all');    
return ;
