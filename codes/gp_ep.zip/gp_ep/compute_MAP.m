function compute_MAP()


return ; 