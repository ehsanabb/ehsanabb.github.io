function [ K ] = gaussian_linear_kernel_m( gamma, X )
    K = zeros(size(X,1), size(X,1));

    for i = 1 : size(X,1)
        for j = 1 : i
           d = gaussian_kernel(X(i,:), X(j,:), gamma) + X(i,:) * X(j,:)'; 
           K(i,j) = d; %exp( -d );
           K(j,i) = K(i,j);
        end
    end 
    
  %  K = normalize_kernel(K);
end

