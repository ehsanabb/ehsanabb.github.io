% computes the probability p(x(test_pair(1),:) > x(test_pair(2),:) for a
% new user tstar
%
% Kx: train Kx 
% Kinv: inverse of Kt \kron Kx
% L: cholesky decomposition of big matrix C = (W + Kinv)
function [p mustar] = predict_gppe_laplace(covfunc_t, covfunc_x, theta, f,...
    Kx, Kinv, W, L, t, x, idx_global, ind_t, ind_x, tstar, test_pair)
covfunc_t = check_covariance(covfunc_t);
covfunc_x = check_covariance(covfunc_x);

[theta_t, theta_x, theta_sigma] = get_gppe_parameters(covfunc_t, covfunc_x, theta, t, x);
clear theta;
sigma = exp(theta_sigma);


[Kt_ss, Kt_star] = feval(covfunc_t{:}, theta_t, t, tstar);
Kx_star = Kx(test_pair,:)';             % test to training
Kx_star_star = Kx(test_pair, test_pair); % test to test

kstar = kron(Kt_star, Kx_star);
kstar = kstar(idx_global,:);
Kss = Kt_ss * Kx_star_star;


mustar = kstar'*Kinv*f(idx_global);

Css    = Kss - kstar'*W*solve_chol(L',Kinv*kstar);  % Kss - Kstar'*(K + W^{-1} )^{-1} * kstar

sigma_star = sqrt(Css(1,1) + Css(2,2) - 2*Css(1,2) + sigma^2);
val = ( mustar(1) - mustar(2) )/sigma_star;
p   = normcdf(val);

return;
