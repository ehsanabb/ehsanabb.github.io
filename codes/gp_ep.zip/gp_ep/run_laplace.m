function [t,  c_mean, c_std, pref_length, test_count, t_test] = run_laplace(suffix)


%mex -lmwlapack -lmwblas solve_chol.c

x = dlmread(strcat('data/x_' , suffix , '.csv'));
u = dlmread(strcat('data/u_' , suffix , '.csv'));
pref = dlmread(strcat('data/pref_', suffix , '.csv'));
%pref_test = dlmread(strcat('data/pref_' , suffix , '_test.csv')); % _test
pref_test = strcat('data/pref_' , suffix , '_test.csv');

%pref = pref_test;


tic
pref_length = size(pref,1);

N = size(x,1);
M = size(u,1);

%covfunc_t = 'ard_kernel_m'; %'gaussian_kernel_m'; %'gaussian_kernel_m'; %'covSEard';
%covfunc_x = 'ard_kernel_m'; %'gaussian_kernel_m'; %'covSEard';
Ntrain_ratio = 1; % How many training pairs to use
D_x = size(x,2); %3; % dimensionality of the input data (item features)
D_t = size(u,2); %2; % Dimesionality of user feaures
sigma = 0.1;
EPSILON = sigma*randn;
LEARN_GP = 1;

%logtheta_x = ones(D_x+1,1) * .1;
%logtheta_t = ones(D_t+1,1) * 1;

logtheta_x = ( 1   ); %.31 % log
logtheta_t = ( 10 ) ;  % log
theta = [logtheta_t; logtheta_x; log(sigma)];

[params_u, params_it] = load_kernel_params(suffix);

%load (kernel_path(suffix));
covfunc_u = 'ard_kernel_m'; 
covfunc_x = 'ard_kernel_m'; 
[Kt] = feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u);  
[Kx] = feval (covfunc_x, params_it{1,2}, params_it{2,2}, params_it{3,2}, x); 

%Kt = feval (covfunc_t, logtheta_t,  u); % 100
%Kx = feval (covfunc_x, logtheta_x, x); % 10

Mtrain = M;
train_t = u(1:Mtrain,:);
train_pairs = get_training_pairs_sushi(pref,M);

%% Get indices for later computations
%  We compute here the global index of all training pairs

    [idx_global_1, idx_global_2] = compute_global_index(train_pairs, N);
    idx_global = unique([idx_global_1; idx_global_2]);
    [ind_x ind_t] = ind2sub([N M], idx_global); % idx of seen points and tasks

  %  check_gradient_f(train_pairs, sigma, M, N);
  %  check_hessian_f(train_pairs, sigma, M, N);

    [f Kx, Kinv]  = approx_gppe_laplace_fast(covfunc_u, covfunc_x, ...
                 params_u, params_it, train_t, x, train_pairs, idx_global, idx_global_1, ...
                 idx_global_2, ind_t, ind_x, Mtrain, N);
   
   %nu = Kinv * f;
   t1 = toc;
   
   [t_test,  c_mean, c_std, test_count] = test_preference([1:size(u,1)], [1:size(x,1)], ...
       Kinv, f, x, u, pref, pref_test, covfunc_u, covfunc_x, params_u, params_it, 'laplace');
   t = t1;

   
   % %% making predictions on a new user
%  make_predictions_new_user(Y, M, N, idx_pairs, covfunc_t, covfunc_x, ...
%  theta, f, Kx, Kinv, W, L, train_t, x, idx_global, ind_t, ind_x, test_t);

return; 

%% function make_predictions_new_user
% Make predictions on a new user
function make_predictions_new_user(covfunc_t,  covfunc_x, theta, train_t, x, train_pairs, idx_global, ...
    idx_global_1, idx_global_2, ind_t, ind_x, test_t, idx_pairs, ytest)
% Make predictions on a new user

N      = size(x,1);
Mtrain = size(train_t,1);

% get the f values first
[f Kx, Kinv, W, L]  = approx_gppe_laplace_fast(covfunc_t, covfunc_x, ...
    theta, train_t, x, train_pairs, idx_global, idx_global_1, idx_global_2, ind_t, ind_x, Mtrain, N);

Npairs = size(idx_pairs,1);
P = zeros(Npairs,1);
for i = 1 : Npairs
    pair = idx_pairs(i,:);
    [p mustar] = predict_gppe_laplace(covfunc_t, covfunc_x, theta, f, Kx, ...
        Kinv, W, L, train_t, x, idx_global, ind_t, ind_x, test_t, pair);
    P(i,1) = p;    
end

% P is the preditive probabilities of the pair being a > relationship
ypred = P > 0.5;

fprintf('Accuracy=%.2f\n', sum(ytest == ypred,1)/size(ytest,1));


% ystar = ( fstar(idx_pairs(:,1)) - fstar(idx_pairs(:,2)) ) > EPSILON; 


% Plotting the underlying utility functions
%plot(ftrue, fstar, '.');
%plot(ftrue, 'b'); hold on; plot(fstar, 'r');
%[val, idx_true] = sort(ftrue, 'descend');
%[val, idx_pred] = sort(fstar, 'descend');

return;


%% function make_predictions_new_user
% Make predictions on a new user
% function make_predictions_new_user(covfunc_t, ...
%     covfunc_x, theta, train_t, x, train_pairs, idx_global, ...
%     ind_t, ind_x, test_t, idx_pairs, ftrue, ytrue)
% N      = size(x,1);
% Mtrain = size(train_t,1);
% 
% % get the f values first
% [f Kx, Kinv, W, L]  = approx_gppe_laplace(covfunc_t, covfunc_x, ...
%     theta, train_t, x, train_pairs, idx_global, ind_t, ind_x, Mtrain, N);
% 
% Npairs = size(idx_pairs,1);
% Fstar  = NaN(N,Npairs);
% for i = 1 : Npairs
%     pair = idx_pairs(i,:);
%     [p mustar] = predict_gppe_laplace(covfunc_t, covfunc_x, theta, f, Kx, ...
%         Kinv, W, L, train_t, x, idx_global, ind_t, ind_x, test_t, pair);
%     P(i,1) = p;
%     
%     Fstar([pair(1), pair(2)],i) = mustar;
%     % mu
%     % F(pair, M)
% end
% fstar = mynanmean(Fstar, 2);
% 
% % P is the preditive probabilities of the pair being a > relationship
% ypred = P > 0.5;
% fprintf('error=%.2f\n', sum(ytrue ~= ypred,1)/size(ytrue,1));
% 
% 
% % ystar = ( fstar(idx_pairs(:,1)) - fstar(idx_pairs(:,2)) ) > EPSILON; 
% 
% 
% % Plotting the underlying utility functions
% %plot(ftrue, fstar, '.');
% plot(ftrue, 'b'); hold on; plot(fstar, 'r');
% 
% [val, idx_true] = sort(ftrue, 'descend');
% [val, idx_pred] = sort(fstar, 'descend');
% % [idx_true, idx_pred]
% 
% return;




% get training pairs
function train_pairs = get_training_pairs_sushi(pref, M)
%uid = unique(pref(:,1));
%M = length(uid);

train_pairs = cell(M,1);

for i = 1 : M
    idx = pref(:,1)==i; %uid(i);
    train_pairs{i} = pref(idx,2:3);
end

return;



%% check_gradient_f
function check_gradient_f(train_pairs, sigma, M, N)
% First derivatives working good!
delta = zeros(M*N, 10);
for j = 1 : 10
    f = rand(M*N,1);
    [gradient, delta(:,j)] = gradchek(f', @log_likelihood_gppe, ...
        @deriv_log_likelihood_gppe, sigma, train_pairs, M, N);
end
hist(delta(:));
return;


%% check_hessian_f
function check_hessian_f(train_pairs, sigma, M, N)
% Second derivatives working good!
% Checking the Hessian here
delta = zeros(M*N*M*N,10);
for j = 1 : 10
    f = rand(M*N,1);
    [h hcent delta(:,j)] = myhesschek(f, @log_likelihood_gppe, ...
        @deriv2_log_likelihood_gppe, sigma, train_pairs, M, N);
end
hist(delta(:));

return;
