function [t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
            util_loss, util_loss_std, wrongs, wrongs_std]...
            = get_min_risks( suffix, D_u, D_it, loss, utils, pref_test1)

global covfunc_u covfunc_x params_u params_it item_count mu K_star %FID

tic 
load (['cache/params_', suffix, '.mat']);

if exist('pref_test1', 'var')
   pref_test = pref_test1; 
end

if isempty(K_star)
    [K_u] = sparse( feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u) );  
    [K_it] = sparse( feval (covfunc_x, params_it{1,2}, params_it{2,2}, params_it{3,2}, x) ); 
    K_star = kron(K_u, K_it);
end

% FID = fopen('results/mel.txt','w');


item_count = size(x,1);
sparse_type = get_option('sparse_type');
sparse_items = [];
sparse_users= [];

if strcmpi(loss, 'ucb')
	alpha = 1; beta = 1;
    if strcmpi(sparse_type, 'users_items')
        [vals, idx] = sort(alpha * mu +  beta * diag(sig) + beta*mu.^2, 'descend' ); % .5 was on sig side
        idx(idx>size(u,1)*size(x,1)) = [];
        idx = idx(1:int32(D_it*D_u));
    else
        for ui = 1 : size(u,1)  
            idx = ( [1:item_count] + ((ui-1) * (item_count)) );
            [m,s] = normmax(mu(idx), sig(idx,idx));
            beta = 1;
            alpha = 1 * alpha; 
            [vals, idx] = sort(alpha * mu( idx ) +  beta * diag(sig(idx,idx)) + beta*mu( idx ).^2, 'descend' ); % .5 was on sig side
            sparse_items{ui} = idx(1:int32(D_it));
        end 
        sparse_users = 1:size(u,1);
    end
    alg = ['heu' num2str(alpha) num2str(beta)];
    
elseif strcmpi(loss, 'ivm')
    if strcmpi(sparse_type, 'users_items')
        [vals, idx] = sortrows(entropy_ivm, 2);  
        idx(idx>size(u,1)*size(x,1)) = [];
        idx = idx(1:int32(D_it*D_u));
    else
        [sparse_items, sparse_users idx] = find_ivm_items(x,u, pref, entropy_ivm, D_u, D_it);
    end
    alg = 'ivm_ep1';

elseif strcmpi(loss, 'voi')
    best_fs = zeros(1,size(u,1)*size(x,1));
    b_idx = 1;
    opt = 2;
    SS = sig;     
    items = {};
    dim_limit = D_it;
    best_f = -Inf;
    for ui = 1 : size(u,1)    
        %for opt = 1 : 2
            items{ui,opt} = [];
            idx = [1:item_count];
            for i = 1 : item_count  %dim_limit
                reserve_idx = idx(~ismember(idx,idx(items{ui,opt})));
                [index best_f] = MEL(u, ui, x, mu, SS, reserve_idx, 1, best_f); 
                items{ui,opt} = [items{ui,opt}; index];
                best_fs(b_idx) = best_f;
                b_idx = b_idx + 1;
            end    
        %end
    end         
    if strcmpi(sparse_type, 'users_items')
        [vals, idx] = sort(best_fs, 'ascend' ); % .5 was on sig side
        idx(idx>size(u,1)*size(x,1)) = [];
        idx = idx(1:int32(D_it*D_u));
    else
        sparse_users = 1:size(u,1);
        for ui = 1 : size(u,1)    
            sparse_items{ui} = items{ui,opt}(1:int32(D_it));
        end
    end
    alg = ['mel' num2str(opt)];
end

if strcmpi(sparse_type, 'users_items')
	[sparse_items, sparse_users] = extract_users_items(idx, item_count, size(u,1));    
else
    idx = [];
end

if D_u == size(u,1) && D_it == size(x,1)
    sparse_users = 1:size(u,1);
    for uu =  sparse_users
        sparse_items{uu} = 1:size(x,1);
    end
end

t_test=toc;

[t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
    util_loss, util_loss_std, wrongs, wrongs_std] = test_preference(sparse_users, sparse_items, Sigma, mu, x, u, ...
        pref, pref_test, covfunc_u, covfunc_x, params_u, params_it, alg, utils, ...
        sparse_type, int32(D_it*D_u), idx, t_test);
return ;


function [sparse_items, sparse_users] = extract_users_items(idx, item_count, user_count)
sparse_items = cell(user_count, 1);
sparse_users= [];

for uj = [1:user_count]
    temp = [];
        for xj = [1:item_count]
            if( ~isempty(find(xj + item_count * (uj-1) == idx)) )
                temp = [temp,xj];
                sparse_users = [sparse_users,uj];
            end
        end
        sparse_items{uj} = unique(temp);
    end
    % sparse_items = unique(sparse_items);
    sparse_users = unique(sparse_users);
return;