function [util prefs pref_test item_count] = prepare_simple_synthetic(user_count, opt, no_folds,replication)
item_count = 25;

s = ['simple_synthetic' opt num2str(user_count) '.' num2str(replication)];

if exist(['data/x_' s '.csv'], 'file'),
  fprintf('%s\n', [s ' exists.']);
  x = dlmread(strcat('data/x_', s, '.csv'));
  item_count = size(x,1);
  % util = dlmread(strcat('data/utils_', s, '.csv'));
  util = [];
  prefs = [];
  pref_test = [];
  
  return ;
end

u = eye(user_count);
x = eye(item_count);

like_x = round (item_count / 2);
util = zeros(user_count * item_count, 1);
idx = 1;
for i = 1 : user_count
   for j = 1 :  item_count
       if j <= like_x
            util(idx) = 10;
       else
           util(idx) = 5;
       end
       if strcmp(opt, '-uniform')
           util(idx) = util(idx) + round(2 * rand);
       elseif strcmp(opt, '-gaussian')
           util(idx) = util(idx) + round(2 * randn);
       end
       idx = idx + 1;
   end
end

%bar(util);

[prefs pref_test] = extract_preferences(x, u, util);

dlmwrite(strcat('data/x_', s, '.csv'), x);
dlmwrite(strcat('data/u_', s, '.csv'), u);
dlmwrite(strcat('data/pref_', s, '.csv'), prefs);
dlmwrite(strcat('data/pref_', s, '_test.csv'), pref_test);
dlmwrite(strcat('data/utils_', s, '.csv'), util);    

partition_csv(strcat('data/pref_', s, '_test.csv'), no_folds);
return ;