function [] = partition_csv(file_path, nobatch)

if nobatch <= 1, return; end;

original = dlmread(file_path);
% samples_count = int32( 3 * size(a,1) / nobatch );
users = unique(original(:,1));
    for i = 1 : nobatch
        subset = zeros(size(original,1),3);
        idx = 1;
        for uu = users'
            a = original(original(:,1) == uu,:);
            rr = randperm(size(a,1), max(2,floor(size(a,1)/5)));
            subset(idx:idx+length(rr)-1,:) = a(rr,:);
            idx = idx+length(rr);
        end
       subset(subset(:,1) == 0,:) = [];
        %rr = randperm(size(original,1),samples_count); % randint(int32(length(a)/10),1, [1,length(a)]);
        %subset = a(rr,:);
        s = strrep(file_path, '.csv', strcat('.', int2str(i), '.csv'));
        dlmwrite(s , subset);
    end

end