function draw_voi()

x = [-10:.1:10];
y1 = normpdf(x, 2, 2);
y2 = normpdf(x, -3, 1);


star = zeros(1,2)+4;
y_star = [0, normpdf(star(1), 2, 2)];
xp = x + star(1);
yp = x;
yp(yp<0) = 0;
xp(yp>max(y2)) = [];
yp(yp>max(y2)) = [];

figure('visible', 'off');


hold on
    %H=area(x(100:120),y(100:120), 'FaceColor', 'r');
    %h1=get(H,'children');
    %H = area(x(100:150),y(100:150), 'FaceColor', 'y');
    %h2=get(H,'children');
    
    plot(x,y1, 'b', 'LineWidth', 3);
    plot(x,y2, 'k', 'LineWidth', 3);
    plot(star, y_star, 'r', 'LineWidth', 4);
    %plot(xp, yp, 'g', 'LineWidth', 4);
   % annotation('textarrow', [.3 .5], [.6 .5], 'String' , 'f^*', 'FontSize', 20);
hold off

    %set_values(h1);
    %set_values(h2);
    
shading flat
axis off
axis tight


print ('-depsc', 'voi.eps');
system(['epstopdf voi.eps']);

return ;


function set_values(h)
%set(h, 'FaceColor', 'flat');
set(h, 'FaceAlpha', 0.9);
set(h, 'EdgeColor', 'k');
% set(h, 'FaceVertexCData', rand(7,3))
%set(gca, 'Color', [1 1 1]*0.85)
%set(gca, 'GridLineStyle', 'none');
return ;