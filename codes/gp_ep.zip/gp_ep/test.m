clear
clc

si_u = 2;
si_x = 10;
for u1 = 1 : si_u
    for u2 = 1 : si_u
        for i = 1 : si_x
            for j = 1 : si_x
                fprintf('u1=%d, u2=%d, i=%d, j=%d, k=[%d,%d]\n', u1, u2, i, j, (u1-1) * si_x + i, (u2-1) * si_x + j);
                
                %=  gaussian_kernel(u(u1,:), u(u2,:), gamma_u) * gaussian_kernel(x(i,:), x(j,:), gamma_i);
                %K(idx2,idx1) = K(idx1,idx2);
            end
        end     
    end
end