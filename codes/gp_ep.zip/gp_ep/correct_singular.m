function [ A ] = correct_singular( A )

lambda = 5.0;
it = 0;
e = eye(size(A));
while(det(A) <= 0.1e-2 && it < 100)
   A = A + lambda * e; 
   it = it + 1;
end

end

