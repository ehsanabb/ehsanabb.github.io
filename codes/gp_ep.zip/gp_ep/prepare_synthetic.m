function [util prefs pref_test] = prepare_synthetic( user_count )
    item_count = 25;
    x = 5 * rand(item_count, 5);
    u = 2 * rand(user_count, 4);
    util = utils(x,u);
    
    bar(util(:));
    set(gca, 'FontSize', 24);
    print -depsc 'tex/synthetic-noiseless-gen-5.eps'
    xlabel('Users-Item', 'FontSize', 24); ylabel('Utility', 'FontSize', 24);
    
    [prefs pref_test] = extract_preferences(x, u, util);

    s = ['synthetic' num2str(user_count)];
    dlmwrite(strcat('data/x_', s, '.csv'), x);
    dlmwrite(strcat('data/u_', s, '.csv'), u);
    dlmwrite(strcat('data/pref_', s, '.csv'), prefs);
    dlmwrite(strcat('data/pref_', s, '_test.csv'), pref_test);
    dlmwrite(strcat('data/utils_', s, '.csv'), util);    
    
    partition_csv(strcat('data/pref_', s, '_test.csv'), 10);
return ;


function [util] = utils(x, u)
    util = kron( sum(u,2), sum(x, 2) );
    
    for ui = 1 :  size(u, 1)
        idx = [[1:size(x,1)] + (size(x,1) * (ui - 1))];
        m = mean(util(idx));
        for i = idx
            if rand > .5  b = 1;else b = -1;end
            if util(i) >= m 
                util(i) = 10 + b * round(rand * 0);
            else
                util(i) = 5  + b * round(rand * 0);
            end
        end
    end
return ;

