function [ K ] = gaussian_kernel_m( gamma, X )
    K = zeros(size(X,1), size(X,1));

    for i = 1 : size(X,1)
        for j = 1 : i
           d = gaussian_kernel(X(i,:), X(j,:), gamma);
           K(i,j) = d;
           K(j,i) = K(i,j);
        end
    end 
end

