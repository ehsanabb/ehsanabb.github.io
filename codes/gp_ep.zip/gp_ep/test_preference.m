function [t, c_mean, c_std, test_count, loss, loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = ...
                test_preference(sparse_users, sparse_items, Sigma, mu, x, u, ...
                    pref, p_test, covfunc_u, covfunc_x, params_u, params_it, alg, ...
                    util, opt, orig_number, idx, t_test)

global FID_RESULTS FID_TEST K_star k_inv gam;

if isempty(FID_TEST)
  %  FID_TEST = fopen(strcat('results/test.csv'), 'w');
end

if ~exist('util', 'var')
    util = [];
end

if ~exist('opt' ,'var')
    opt = '';
end

%fprintf('algorithm: %s\n', alg);
t=tic;
item_count = size(x, 1);
prob = Inf(item_count, item_count);

if strcmpi(alg, 'laplace')
    SS = Sigma;
    nu = Sigma * mu; 
	item_dim = length(sparse_items);
    idx = 1 : length(sparse_users) * length(sparse_items);

elseif strcmpi(alg, 'ep') || strcmpi(alg, 'optimize_kernel')
    SS = inv( k_inv + Sigma ); 
    nu = SS * mu;  % inv(K_star +  Sigma) * mu; 
    item_dim = length(sparse_items);
    idx = 1 : length(sparse_users) * length(sparse_items);

else
    uc = length(sparse_users);
    ic = length(sparse_items);
    new_idx = false;
    if ~exist('idx', 'var') || isempty(idx),
        idx = zeros(1,uc * ic);
        new_idx = true;
    end
    i = 1;
    item_dim = 0; %size(sparse_items{1},1);
    for uj = 1 : uc
        items = sparse_items{uj};
        item_dim = item_dim + length(items);
        if new_idx,
            for xj = 1 : length(items)
               idx(i) = items(xj) + item_count * (sparse_users(uj)-1);
               i = i + 1;
            end
        end
    end
  
    if strcmpi(get_option('sparse_type'), 'users_items')
        item_dim = item_dim / uc;
    else
        item_dim = length(sparse_items{1});
    end
    idx(idx == 0) = [];
    SS = inv( correct_singular( k_inv(idx,idx) +  Sigma(idx,idx) ) );   
    nu = SS * mu(idx); 
end

correct = 0;
test_count = 0;
c_list = [];
pref_orders = [];
loss  = [];
util_loss = [];
wrongs = [];

%-----------
test_no = 1;
%-----------
test_count = [];

if(isstr(p_test))
   file_path = p_test;
   p_test = {}; 
   if test_no > 1
       for i = 1 : test_no
           p_test{i} = dlmread(strrep(file_path, '.csv', strcat('.', int2str(i), '.csv')) );
       end
   else
       p_test{1} = dlmread(file_path);
   end
end

if (iscell (p_test) )
   test_no = length(p_test);    
end

for test = 1 : test_no
    if(iscell(p_test))
        pref_test = p_test{test};
    else
        rr = randint(int32(length(p_test)/10),1, [1,length(p_test)]);
        pref_test = p_test(rr,:);
    end 
    
    test_c = 0;
    for itr = 1 : size(pref_test,1)           
%         if(iscell(sparse_items))
%             items = sparse_items{pref_test(itr, 1)};            
%             item_dim = size(sparse_items{1},1);
%         else
%             items = sparse_items;
%             item_dim = length(sparse_items);
%         end
% 
%         idx = items(:);
%         item_count = size(x, 1);
%         for j = [1:size(u,1)-1]
%             idx = [idx;items(:) + item_count * j * ones(size(items(:)))];
%         end
%         idx(idx > length(nu)) = [];
            
        if ~isempty(K_star)
            item1 = (pref_test(itr, 1)-1)*item_count + pref_test(itr, 2);
            item2 = (pref_test(itr, 1)-1)*item_count + pref_test(itr, 3);
            k_star = full( K_star([item1,item2],idx) ); 
        else            
            k_star = computeKStar(u, sparse_users, x, items, u(pref_test(itr,1),:), ...
                                               [x(pref_test(itr, 2),:); x(pref_test(itr, 3),:)], ...
                                                    covfunc_u, covfunc_x, params_u, params_it);
        end

        mean = k_star * nu; 
        C_star = computeKStar(u, [pref_test(itr,1)], x, [pref_test(itr, 2),pref_test(itr, 3)], ...
                                      u(pref_test(itr,1),:), [x(pref_test(itr, 2),:); x(pref_test(itr, 3),:)], ...
                                                    covfunc_u, covfunc_x, params_u, params_it);
        C_star = C_star - k_star * SS * k_star';
        p = (normcdf( (mean(1)-mean(2)) / ...
                (gam^2 + C_star(1,1) + C_star(2,2) - C_star(1,2) - C_star(2,1) ) ));
        if prob(pref_test(itr, 2),pref_test(itr, 3)) == inf
            prob(pref_test(itr, 2),pref_test(itr, 3)) = 0;
        end
        
        p = log(p);

        if isnan(p) || isinf(p), p = 0; end;

        prob(pref_test(itr, 2),pref_test(itr, 3)) = prob(pref_test(itr, 2),pref_test(itr, 3)) + (p);
        
%       if(size(k_star, 2) == size(nu,1))
%            mean = k_star * nu; 
%       else
%           mean = k_star * nu(idx);
%       end
        
        if( (mean(1) == mean(2) && rand >= .5) || (mean(1) > mean(2)) )
            correct = correct + 1;
            pref_orders = [pref_orders; pref_test(itr,1), pref_test(itr,2), pref_test(itr,3)];
        else
            pref_orders = [pref_orders; pref_test(itr,1), pref_test(itr,3), pref_test(itr,2)];
        end
        
        test_c = test_c + 1;
    end
    if test_c == 0, continue; end;
    test_count = [test_count; test_c];
    [user_loss util_losses wrongs_loss] = test_pref_orders(sparse_users, pref_test, ...
                        pref_orders, size(x, 1), util, mu);
    loss = [loss; sum(user_loss)/length(user_loss)];
    util_loss = [util_loss; sum(util_losses)];
    wrongs = [wrongs; sum(wrongs_loss) / item_dim * 100]; % length(pref_test)  * 100];
    c_list = [c_list; correct / length(pref_test) * 100];
    pref_orders = [];
    correct = 0;
end
if(length(c_list) > 0)
    c_mean = sum(c_list)/length(c_list);
    c_std  = std(c_list);
else
    c_mean = 0;
    c_std  = NaN;
end

loss_std = std(loss);
loss = sum(loss )/length(loss );
util_loss_std = std(util_loss);
util_loss = sum(util_loss)/length(util_loss);
wrongs_std = std(wrongs);
wrongs = sum(wrongs)/length(wrongs);
test_count = sum(test_count) / length(test_count);

t = toc(t);

if exist('t_test', 'var')
    t = t + t_test;
end

try        
	fprintf('%d, %d, %s, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.1f, %2.2f, %2.10f, %2.2f\n', ...
        item_dim, size(sparse_users,2), alg, c_mean, c_std, loss, loss_std, util_loss, ...
                util_loss_std, wrongs, wrongs_std, test_count, t, sum(prob(prob~=inf)), orig_number);

    if ~isempty(FID_RESULTS) % && ( ~strcmpi(opt, 'users_items') || ...
                   % strcmpi(alg, 'ep') || strcmpi(alg, 'optimize_kernel') || ...
                   %     strcmpi(alg, 'laplace') )
        fprintf(FID_RESULTS, '%d, %d, %d, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.1f, %2.2f, %2.10f, %2.2f\n', ...
         item_dim, size(sparse_users,2), alg_id(alg), c_mean, c_std, loss, loss_std, util_loss, ...
                util_loss_std, wrongs, wrongs_std, test_count, t, sum(prob(prob~=inf)),orig_number);
    end
    
%     if ~isempty(FID_RESULTS2) && (strcmpi(opt, 'users_items') || ...
%                     strcmpi(alg, 'ep') || strcmpi(alg, 'optimize_kernel') || ...
%                         strcmpi(alg, 'laplace') )
%         fprintf(FID_RESULTS2, '%d, %d, %d, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.1f, %2.10f\n', ...
%          item_dim, size(sparse_users,2), alg_id(alg), c_mean, c_std, loss, loss_std, util_loss, ...
%                 util_loss_std, wrongs, wrongs_std, test_count, toc);    
%    end
catch ex
     fprintf('%s', ['test_preferences: ' ex.message]);
end

if ~isempty(FID_TEST)
%    fprintf(FID_TEST, '\n%s >> accuracy: %d, std_accuracy: %d', alg, c_mean, c_std);
end
% fprintf('\n%s >> accuracy: %d, std_accuracy: %d', alg, c_mean, c_std);
%fprintf('\n%d min, %2.0f sec\n', floor(toc/60), toc - floor(toc/60) * 60);


return;

return ;


return ;