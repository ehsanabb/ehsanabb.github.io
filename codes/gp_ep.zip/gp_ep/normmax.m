function [m,s] = normmax(mu, sigma)
	while length(mu) > 1
		m =zeros(round(length(mu)/2),1);
		s =zeros(size(m));
		idx = 1;
		for i = 1 : 2 : floor(length(mu)/2)*2
		   [mm, ss] = normmax_pair(mu(i),mu(i+1),sigma(i,i), sigma(i+1,i+1));
		   m(idx) = mm;
		   s(idx) = ss;
		   idx = idx + 1;
		end
		if idx <= length(m)   
		   m(idx) = mu(length(mu));
		   s(idx) = sigma(length(mu),length(mu));
		end

		mu = m;
		sigma = diag(s);
	end
	m = mu(1);
	s = sigma(1,1);
return ;

function [mu, sigma] = normmax_pair(mu1, mu2, sigma1, sigma2)
% max of x1 and x2 assuming that both are normally distributed
% max = normpdf(v;mu1, sigma1)*normcdf((v - mu2)/sigma2) + normpdf(v;mu2, sigma2)*normcdf((v - mu1)/sigma1)
% first we compute the product of cdf * pdf and project it back to pdf.
% This is done throgh the normalizer of their product. First derivative is
% first momenet and second one the second.

[m1, s1] = proj_cdfpdf(mu1, mu2, sigma1, sigma2);
[m2, s2] = proj_cdfpdf(mu2, mu1, sigma2, sigma1);

mu = m1+m2;
sigma = s1+s2;
return ;

function [mu, sigma] = proj_cdfpdf(pdf_mu, cdf_mu, pdf_sigma, cdf_sigma)
% product of cdf and pdf, then the normalizer is used to produce the
% moments
cdf_sigma = abs(cdf_sigma);
pdf_sigma = abs(pdf_sigma);
denom = (cdf_sigma * sqrt(1 + (pdf_sigma/cdf_sigma^2) ));
z = (pdf_mu - cdf_mu) / denom;
try
	temp = normpdf(z) / normcdf(z);
	if(normcdf(z) == 0 || isnan(temp))
		temp = abs(z);
	end
catch ex
disp(cdf_sigma);
disp(pdf_sigma);
disp(denom)
disp(z)
disp(ex)
end
mu = pdf_mu + temp * pdf_sigma / denom;
sigma = pdf_sigma - (pdf_sigma^2 * temp / (pdf_sigma + cdf_sigma^2)) * (z + temp);
return ;
