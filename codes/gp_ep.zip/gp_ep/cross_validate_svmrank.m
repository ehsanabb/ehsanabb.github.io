
function [m_max sigma1_max sigma2_max best_mean] = cross_validate_svmrank(suffix)
u = 20; % we will use 20 users by default
m_max=0; sigma1_max=0; sigma2_max=0;
best_mean=0;
prepare(suffix, u);
[users item_count item_dim] = prepare4svmrank([suffix num2str(u)]);        
for m = 1.4 : .2 : 2.0
    for sigma1 = 4 : .2 : 5
        for sigma2 = 4 : .2 : 5
            system( ['cd ../svm_rank_linux && sh prepare.sh ' num2str(m) ' ' ...
                      num2str(sigma1) ' ' num2str(sigma2)] ); % prepare.sh M sigma1 sigma2

            [t,  c_mean, c_std, loss, loss_std, util_loss, ...
                    util_loss_std, wrongs, wrongs_std, ... 
                    test_count, t_test] ...
                = test_svmrank([suffix num2str(u)], users, item_count);   
                
            if c_mean > best_mean, 
                best_mean = c_mean; 
                m_max = m
                sigma1_max = sigma1
                sigma2_max = sigma2
            end;
        end 
    end
end
kernel_file = ['cache/kernels_', suffix, 'svmrank.mat'];
save(kernel_file, 'm_max', 'sigma1_max', 'sigma2_max');
disp(m_max);
disp(sigma1_max);
disp(sigma2_max);
return ;