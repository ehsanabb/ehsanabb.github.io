function test_lang()

m1 = rand(2000, 2000);
m2 = rand(2000, 2000);
javaaddpath java/gp/bin/

tic 
a = javaObjectEDT('Multiply');
b = a.multiply(m1, m2);
toc

tic
c = zeros(size(m1));
for i = 1 : size(m1,1)
    for j = 1 : size (m2,1)
        c(i,j) = m1(i,j) * m2(i,j);
    end
end
toc
clear c, a

mex multiply.c
tic
c = multiply(m1,m2);
toc
return ;