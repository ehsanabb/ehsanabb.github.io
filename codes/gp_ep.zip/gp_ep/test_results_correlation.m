function test_results_correlation(result_file)
% clear
data = csvread(['results/' result_file]); % accuracy_time_sushi_20.04.2012.17.27.csv

sub_data = [data(:,1),data(:,2), data(:,3), data(:,4), data(:,5), data(:,6),data(:,7)];
sub_data = sub_data(sub_data(:,1) == 4,:);

idx = 6; % loss

r = sub_data(sub_data(:,3) == 1,idx);
rs_data = sub_data(sub_data(:,3) == 2,idx);
rm2_data = sub_data(sub_data(:,3) == 8,idx);
ri_data = sub_data(sub_data(:,3) == 5,idx);
rh1_data = sub_data(sub_data(:,3) == 7,idx);

[h,p,ci,stats] = ttest(rm2_data, rs_data, .05)

[h,p,ci,stats] = ttest(rh1_data, rs_data, .05)
return;
