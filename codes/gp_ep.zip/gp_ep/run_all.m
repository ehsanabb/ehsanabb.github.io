clear 
run_synthetic = true;
run_synthetic_u = false;
run_synthetic_g = false;
run_sushi = true;
run_car = false;
run_car_sp = true;
run_fb = true;

run_ep = true;

idx = 1;
options{idx,1} = 'identity_opt';
options{idx,2} = '';

update_option(options{1,1}, options{1,2});
idx = 0;

% idx = idx + 1;
% options{idx,1} = 'identity_opt';
% options{idx,2} = '_identity';

idx = idx + 1;
options{idx,1} = 'sparse_type';
options{idx,2} = 'users_items';

% ADD THIS ---------
idx = idx + 1;
options{idx,1} = 'sparse_type';
options{idx,2} = '';
% ------------------
for i = 1 : idx
    update_option(options{i,1}, options{i,2});

	if run_fb == true
        iteraiton  = 20; %10:10:50;
        iterative_run('fb', iteraiton, run_ep)
    end
    
     if run_car_sp
        iteration  = 60; %10:10:60;
        iterative_run('car_sp', iteration, run_ep)
    end
    
    if run_synthetic == true,
        iteration  = 50;%10:10:50;
	    iterative_run('simple_synthetic', iteration, run_ep)
    end

    if run_sushi
        iteration  = 20; % 10:10:200;    
        iterative_run('sushi', iteration, run_ep)    
    end
    
    if run_synthetic_u
        iteration  = 50; %10:10:50;
        iterative_run('simple_synthetic-uniform', iteration, run_ep)    
    end

    if run_synthetic_g
        iteration  = 50; %10:10:50;    
        iterative_run('simple_synthetic-gaussian', iteration, run_ep)    
    end
    
    if run_car == true
        iteration  = 50; %10:10:50;
        iterative_run('car', iteraiton, run_ep)
    end
    
   
end

% if run_synthetic == true,
%     %opt = '';
%     %save('kernel_path_opt.mat');
%     iteration  = 10:10:50;
%     update_option();
%     iterative_run('simple_synthetic', iteration, run_ep)
        
%     %clear
%     %opt = '_identity';
%     %save('kernel_path_opt.mat');
%     update_option('identity_opt', '_identity');
%     iterative_run('simple_synthetic', iteration, run_ep)
    
    
% end

% if run_synthetic_u
%     iteration  = 10:10:50;
%     update_option('identity_opt', '');
%     iterative_run('simple_synthetic-uniform', iteration, run_ep)
    
%     update_option('identity_opt', '_identity');
%     iterative_run('simple_synthetic-uniform', iteration, run_ep)
% end

% if run_synthetic_g
%     iteration  = 10:10:50;
%     update_option('identity_opt', '');
%     iterative_run('simple_synthetic-gaussian', iteration, run_ep)
    
%     update_option('identity_opt', '_identity');
%     iterative_run('simple_synthetic-gaussian', iteration, run_ep)
% end

% if run_sushi
%     iteration  = 10:10:200;
%     update_option('identity_opt', '');    
%     iterative_run('sushi', iteration, run_ep)
    
%     update_option('identity_opt', '_identity');
%     iterative_run('sushi', iteration, run_ep)
% end

% %%
% % The kernel parameters of the car is removed so that it is optimized in
% % case it remained from previous experiment
% %%
% %if exist('cache/kernels_car_.mat', 'file')    
% %    system('mv cache/kernels_car_.mat cache/kernels_car.mat');
% %else
% %    system('rm cache/kernels_car.mat');
% %end
% % ---------------

% if run_car == true
%     iteration  = 10:10:50;
%     update_option('identity_opt', '');
%     iterative_run('car', iteraiton)
%     system('mv cache/kernels_car.mat cache/kernels_car_.mat', run_ep);

%     update_option('identity_opt', '_identity');
%     iterative_run('car', iteration, run_ep)
% end

% %%
% % The kernel parameters of the car is removed so that it is optimized in
% % case it remained from previous experiment
% %%
% %if exist('cache/kernels_car_2.mat', 'file')    
% %    system('mv cache/kernels_car_2.mat cache/kernels_car.mat');
% %else
% %    system('rm cache/kernels_car.mat');
% %end
% % ---------------

% if run_car_sp
%     iteration  = 10:10:60;
%     update_option('identity_opt', '');
%     iterative_run('car_sp', iteration, run_ep)

%     update_option('identity_opt', '_identity');
%     iterative_run('car_sp', iteration, run_ep)
% end



