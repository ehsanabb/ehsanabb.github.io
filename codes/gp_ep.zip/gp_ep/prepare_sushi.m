function [item_count] = prepare_sushi(user_count, no_folds, replication)

if ~exist('no_folds', 'var')
    no_folds = 10;
end

s_token = strcat('sushi', int2str(user_count), '.', num2str(replication));


if exist(strcat('data/x_', s_token, '.csv'), 'file')
    fprintf('%s\n', [s_token ' exists.']);
    x = dlmread(strcat('data/x_', s_token, '.csv'));
    item_count = size(x,1);
    return ;
end;

udata = dlmread('sushi3/sushi3.udata', '\t');
idata = dlmread('sushi3/sushi3.idata', '\t');
ordered = dlmread('sushi3/sushi3a.5000.10.order', ' ');

udata = udata(:,2:size(udata,2));
idata = idata(1:size(idata,1),2:size(idata,2)); % :
pref  = ordered(2:size(ordered, 1),3:size(ordered,2));

u_feature_count = [length(unique(udata(:,1))), length(unique(udata(:,2))), 1, ...
    length(unique(udata(:,4))) , length(unique(udata(:,5))) , length(unique(udata(:,6))) , ...
    length(unique(udata(:,7))) , length(unique(udata(:,8))) , length(unique(udata(:,9))) , ...
    length(unique(udata(:,10)))];

x_feature_count = [length(unique(idata(:,1))), length(unique(idata(:,2))),length(unique(idata(:,3)))];

id = 1;
n = size(pref,2); 
%user_count = 200;
item_count = int32(n*(n-1)/4);

%x = idata; %[]; %zeros(n,size(idata,2));
u = []; %zeros(user_count, sum(u_feature_count)) ;  % size(udata,2)
p = zeros((item_count-1) * user_count,3);
p_test = zeros((item_count-1) * user_count,3);

idx = 1;
idx_test = 1;
for id = 1 : user_count % size(udata, 1)
    u = [u; get_user(udata(id, :), u_feature_count)];  % udata(id, :);
    c = 1;
    tmp = [];
    for i = 1 : n
%        x = [x; get_item(idata(pref(id,i)+1,:), x_feature_count)]; % idata(pref(id,i)+1,:);
         for j = i + 1 : n
             tmp = [tmp;[id,pref(id,i)+1,pref(id,j)+1]];
            %if(c < item_count)
            %    p(idx,:) = [id,pref(id,i)+1,pref(id,j)+1];
            %    idx = idx + 1;
            %else
            %    p_test(idx_test,:) = [id,pref(id,i)+1,pref(id,j)+1];
            %    idx_test = idx_test + 1;
            %end
            %c = c + 1;
        end    
    end
    l = size(tmp,1);
    l2 = int32(3*l/5);
    a = randperm(l,l2);
    p(idx:idx+l2-1,:) = tmp(a,:);
    tmp(a,:) =  [];
    p_test(idx_test:idx_test+(l-l2)-1,:) = tmp;
    
%     tmp = tmp(randperm(l), :);    
%     p(idx:idx+l2-1,:) = tmp(1:l2,:);
% 	p_test(idx_test:idx_test+(l-l2)-1,:) = tmp(l2+1:l,:);
    idx = idx + l2;
    idx_test = idx_test + (l-l2);
end

p(p(:,1)==0,:) = [];
p_test(p_test(:,1)==0,:) = [];

u = add_idx(u);
a= p(:,[2,3]);
a = a(:);
[idx, dummy] = unique(a);
x = add_idx(idata((idx),:)); %x => idata

item_count = size(x,1);
dlmwrite(strcat('data/x_', s_token, '.csv'), x);
dlmwrite(strcat('data/u_', s_token, '.csv'), u);
dlmwrite(strcat('data/pref_', s_token, '.csv'), p);
dlmwrite(strcat('data/pref_', s_token, '_test.csv'), p_test);

partition_csv(strcat('data/pref_', s_token, '_test.csv'), no_folds);
return ;


function [ x ] = get_item(x_row, x_feature_count)
x = zeros(1, sum(x_feature_count));

x(1,x_row(1) + 1) = 1;
x(1,x_feature_count(1) + x_row(2) + 1) = 1;
x(1,sum(x_feature_count([1,2])) + 1 + x_row(3)) = 1;
%x(1,sum(x_feature_count([1,2,3])) + x_row(4) + 1) = 1;
x(1,sum(x_feature_count([1,2,3])) + 1) = x_row(4);
x(1,sum(x_feature_count([1,2,3])) + 2) = x_row(5);
x(1,sum(x_feature_count([1,2,3])) + 3) = x_row(6);
return ;

function [ u ] = get_user(u_row, u_feature_count)
u = zeros(1, sum(u_feature_count));

u(1, u_row(1) + 1) = 1;
u(1,u_feature_count(1) + u_row(2) + 1) = 1;
u(1,sum(u_feature_count([1,2])) + 1) = u_row(3);
u(1,sum(u_feature_count([1,2,3])) + u_row(4) + 1) = 1;
u(1,sum(u_feature_count([1,2,3,4])) + u_row(5) + 1) = 1;
u(1,sum(u_feature_count([1,2,3,4,5])) + u_row(6) + 1) = 1;
u(1,sum(u_feature_count([1,2,3,4,5,6])) + u_row(7) + 1) = 1;
u(1,sum(u_feature_count([1,2,3,4,5,6,7])) + u_row(8) + 1) = 1;
u(1,sum(u_feature_count([1,2,3,4,5,6,7,8])) + u_row(9) + 1) = 1;
u(1,sum(u_feature_count([1,2,3,4,5,6,7,8,9])) + u_row(10) + 1) = 1;

return ;