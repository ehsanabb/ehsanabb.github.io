function [item_ids] = get_best_item(pref, ui)

if isempty(pref) || size(pref,1) == 0, 
        item_ids = []; 
        return; 
end;

p = pref(pref(:,1) == ui,:);
item_ids = unique(p(~ismember(p(:,2), p(:,3)),2));

return ;