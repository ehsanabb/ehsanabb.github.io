function prepare_sushi_edwin(user_count)
load data/data_suhi_ehsan.mat

train_test_percentage = .8;
p = [];
p_test = [];

for i = 1 : user_count
    a = cell_pairs{1,i};
    l=length(a);
    l2 = l * train_test_percentage; %int32(l/2);
    b = randperm(l);
    zz= zeros(l2, 1) + i;
    p = [p;[zz,a(b(1:l2),:)]];
    zz= zeros(l-l2+1, 1) + i;
    p_test = [p_test;[zz,a(b(l2:l),:)]];
end

if(train_test_percentage == 1)
    p_test = p;    
end

s = strcat('sushi_edwin', int2str(user_count));

dlmwrite(strcat('data/x_', s, '.csv'), x);
dlmwrite(strcat('data/u_', s, '.csv'), t(1:user_count,:));
dlmwrite(strcat('data/pref_', s, '.csv'), p);
dlmwrite(strcat('data/pref_', s, '_test.csv'), p_test);

return;