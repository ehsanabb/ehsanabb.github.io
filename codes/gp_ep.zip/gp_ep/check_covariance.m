function covfunc = check_covariance(covfunc)
if ischar(covfunc)   % convert to cell if needed
    covfunc = cellstr(covfunc); 
end 
return;
