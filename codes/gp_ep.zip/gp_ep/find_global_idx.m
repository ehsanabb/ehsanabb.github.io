function [idx, item_dim] = find_global_idx(sparse_users, sparse_items, item_count)

    uc = length(sparse_users);
    ic = length(sparse_items); % item_count; 
    idx = zeros(1,uc * ic);
    i = 1;
    item_dim = 0; 
    for uj = 1 : uc
        if iscell(sparse_items)
            items = sparse_items{uj};
        else
            items = sparse_items;
        end
        item_dim = item_dim + length(items);
        for xj = 1 : length(items)
           idx(i) = items(xj) + item_count * (sparse_users{uj}-1);
           i = i + 1;
        end
    end
return ;