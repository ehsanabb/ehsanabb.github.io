%function plot_accuracy_lastones()

% plot_accuracy('accuracy_time_sushi_20.04.2012.17.27.csv', 'sushi')
% plot_accuracy('accuracy_time_simple_synthetic_28.05.2012.22.30.csv', 'simple_synthetic');
% plot_accuracy('accuracy_time_simple_synthetic-uniform_28.05.2012.22.31.csv', 'simple_synthetic-uniform');
% plot_accuracy('accuracy_time_simple_synthetic-gaussian_28.05.2012.22.30.csv', 'simple_synthetic-gaussian');
 
clc

plot_accuracy('car_sp1_2.csv', 'car_sp', 60, 40)
plot_accuracy('fb.csv', 'fb', 20, 40)
plot_accuracy('simple_synthetic.csv', 'simple_synthetic', 10, 40, true)

return ;


idx = 1;

filenames{idx} = 'simple_synthetic_50.csv';
names{idx} = 'simple_synthetic';
no_users{idx} = 50;
add_legend{idx} = true;
idx = idx + 1;

filenames{idx} = 'sushi_200.csv';
names{idx} = 'sushi';
no_users{idx} = [200];
add_legend{idx} = false;
idx = idx + 1;

filenames{idx} = 'car2_1_60.csv'; % 'car2_1_20.csv';
names{idx} = 'car_sp';
no_users{idx} = [60];
add_legend{idx} = false;
idx = idx + 1;


filenames{idx} = 'simple_synthetic_users_items50.csv'; 
names{idx} = 'simple_synthetic_users_items';
no_users{idx} = [-1];
add_legend{idx} = true;
idx = idx + 1;

filenames{idx} = 'car_sp_users_items60.csv'; 
names{idx} = 'car_sp_users_items';
no_users{idx} = [-1];
add_legend{idx} = false;
idx = idx + 1;

filenames{idx} = 'sushi_users_items200.csv'; 
names{idx} = 'sushi_users_items';
no_users{idx} = [-1];
add_legend{idx} = false;
idx = idx + 1;


% filenames{idx} = 'simple_synthetic-uniform_1_50-25.csv';
% names{idx} = 'simple_synthetic-uniform';
% no_users{idx} = 50;
% idx = idx + 1;
% 
% filenames{idx} = 'simple_synthetic-gaussian_1_50-25.csv';
% names{idx} = 'simple_synthetic-gaussian';
% no_users{idx} = 50;
% idx = idx + 1;
% 
% filenames{idx} = 'simple_synthetic_identity_1_50-25.csv';
% names{idx} = 'simple_synthetic_identity';
% no_users{idx} = 50;
% idx = idx + 1;
% 
% filenames{idx} = 'simple_synthetic-uniform_identity_1_50-25.csv';
% names{idx} = 'simple_synthetic-uniform_identity';
% no_users{idx} = 50;
% idx = idx + 1;
% 
% filenames{idx} = 'simple_synthetic-gaussian_identity_1_50-25.csv';
% names{idx} = 'simple_synthetic-gaussian_identity';
% no_users{idx} = 50;
% idx = idx + 1;
% 
% filenames{idx} = 'sushi_1_60_identity.csv';
% names{idx} = 'sushi_identity';
% no_users{idx} = 60;
% idx = idx + 1;
% 
% filenames{idx} = 'sushi_1_200.csv';
% names{idx} = 'sushi';
% no_users{idx} = 130;
% idx = idx + 1;
% 
% filenames{idx} = 'sushi_1_200.csv';
% names{idx} = 'sushi';
% no_users{idx} = 200;
% idx = idx + 1;
% 
% 
% filenames{idx} = 'car2_identity_1_60.csv'; %'car2_identity_1_20.csv';
% names{idx} = 'car2_identity';
% no_users{idx} = 20;
% idx = idx + 1;
% 
% filenames{idx} = 'car2_1_60.csv'; % 'car2_1_20.csv';
% names{idx} = 'car2';
% no_users{idx} = 40;
% idx = idx + 1;
% 
% filenames{idx} = 'car2_identity_1_60.csv'; %'car2_identity_1_20.csv';
% names{idx} = 'car2_identity';
% no_users{idx} = 40;
% idx = idx + 1;
% 
% filenames{idx} = 'car2_1_60.csv'; % 'car2_1_20.csv';
% names{idx} = 'car2';
% no_users{idx} = 60;
% idx = idx + 1;
% 
% filenames{idx} = 'car2_identity_1_60.csv'; %'car2_identity_1_20.csv';
% names{idx} = 'car2_identity';
% no_users{idx} = 60;
% idx = idx + 1;
% 
% filenames{idx} = 'car_1_50.csv';
% names{idx} = 'car';
% no_users{idx} = 20;
% idx = idx + 1;
% 
% filenames{idx} = 'car_1_50_identity.csv';
% names{idx} = 'car_identity';
% no_users{idx} = 20;
% idx = idx + 1;
% 
% filenames{idx} = 'car_1_50.csv';
% names{idx} = 'car';
% no_users{19} = 40;
% idx = idx + 1;
% 
% filenames{idx} = 'car_1_50_identity.csv';
% names{idx} = 'car_identity';
% no_users{idx} = 40;
% idx = idx + 1;
% 
% filenames{idx} = 'car_1_50.csv';
% names{idx} = 'car';
% no_users{idx} = 50;
% idx = idx + 1;
% 
% filenames{idx} = 'car_1_50_identity.csv';
% names{idx} = 'car_identity';
% no_users{idx} = 50;
% idx = idx + 1;

for i = 1 : size(filenames, 2)
    fprintf(' >> %s, %s, %d\n', filenames{i}, names{i}, no_users{i});
    plot_accuracy(filenames{i}, names{i}, no_users{i}, add_legend{i});
end

system('cd tex && pdflatex -synctex=1 -interaction=nonstopmode icml.tex');

%end


% 
% plot_accuracy('simple_synthetic_1_50.csv', 'simple_synthetic',50);
% plot_accuracy('simple_synthetic-uniform_1_50.csv', 'simple_synthetic-uniform',50);
% plot_accuracy('simple_synthetic-gaussian_1_50.csv', 'simple_synthetic-gaussian',50);
% 
% plot_accuracy('simple_synthetic_identity_1_50.csv', 'simple_synthetic_identity',50);
% plot_accuracy('simple_synthetic-uniform_identity_1_50.csv', 'simple_synthetic-uniform_identity',50);
% plot_accuracy('simple_synthetic-gaussian_identity_1_50.csv', 'simple_synthetic-gaussian_identity',50);
% 
% plot_accuracy('sushi_1_200.csv', 'sushi', 60);
% plot_accuracy('sushi_1_60_identity.csv', 'sushi_identity', 60);
% plot_accuracy('sushi_1_200.csv', 'sushi', 130);
% plot_accuracy('sushi_1_200.csv', 'sushi', 200);
% 
% plot_accuracy('car2_1_20.csv', 'car2', 20);
% plot_accuracy('car2_identity_1_20.csv', 'car2_identity', 20);
% 
% plot_accuracy('car_1_50.csv', 'car', 50);
% plot_accuracy('car_1_50_identity.csv', 'car_identity', 50);
