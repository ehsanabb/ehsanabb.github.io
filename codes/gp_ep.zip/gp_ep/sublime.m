function sublime(file)
	system(['"/opt/Sublime Text 2/sublime_text" ' file])
return;