function [ K ] = linear_kernel_m( gamma , X )
    K = zeros(size(X,1), size(X,1));

    for i = 1 : size(X,1)
        for j = 1 : i
           d = X(i,:) * X(j,:)';
           K(i,j) = d; %exp( -d );
           K(j,i) = K(i,j);
        end
    end 
end

