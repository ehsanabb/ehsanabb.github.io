data = dlmread('results/accuracy_time_sushi_15.02.2013.17.47.csv');
dims = unique(data(:,1))';
algs = [7,5,8];
times = zeros(length(dims), 4);
times_std = zeros(length(dims), 4);
for i = 1 : length(dims)
    times(i,1) = dims(i);
    times_std(i,1) = dims(i);
    for alg = 1 : length(algs)
         a = data(data(:,1) == i,:);
         b = a(a(:,3) == algs(alg),13);  
         if ~isempty(b)
             m = mean(b);
             s = std(b) * 2 / sqrt(20);
         end
         times(i,alg+1) = m;
         times_std(i,alg+1) = s;
    end
end

times(:,1) = times(:,1) ./ max(times(:,1)) * 100;

r_color = 'b--';
rl_color = 'y--';
rs_color = 'r';
rm_color = '[0.2 0.2 .2]';
ri_color = 'k';
ri2_color = 'm';
rh1_color = 'g';
rm2_color = 'b';
rm3_color = 'c';
rm4_color = 'b';
rm5_color = '[0.2 0.2 .2]';
kl_color = 'r';
svm_color = 'r--';

r_marker = 'o';
rl_marker= 'o';
rs_marker = '+';
rm_marker= '*';
ri_marker = 'v';
ri2_marker = 'd';
rh1_marker = 's';
rm2_marker= '+';
rm3_marker = '+';
rm4_marker = '*';
rm5_marker = 'v';
kl_marker = 'd';
svm_marker = '*';

marker_size = 12;

figure('visible','off');
hold on
errorbar(times(:,1), times(:,2), times_std(:,2), rh1_color, 'LineWidth', 2, 'Marker', rh1_marker, 'MarkerSize', marker_size);
errorbar(times(:,1), times(:,4), times_std(:,4), rm2_color, 'LineWidth', 2, 'Marker',rm2_marker, 'MarkerSize', marker_size);
errorbar(times(:,1), times(:,3), times_std(:,3), ri_color,'LineWidth', 2, 'Marker',ri_marker, 'MarkerSize', marker_size);
hold off

set(gca, 'FontSize', 24);
legend('VVM-UCB', 'VVM-VOI', 'IVM', 'Location', 'NorthWest');
xlabel('Percent of items selected.', 'FontSize', 24);
ylabel('Time (s)', 'FontSize', 24);
% grid on
legend boxoff
axis tight

print ('-depsc', 'tex/images/sushi200_time.eps');
system(['epstopdf tex/images/sushi200_time.eps']);