
function single_run( i, suffix, k )
global FID_RESULTS RUN_EP

  
fprintf('Replication: %d\n', k);
[suffix D_u D_it] = prepare(suffix, i, RUN_EP, k);
s = strcat(suffix, int2str(i));    
[conv, t, c_mean, c_std, pref_length, test_count,t_test, loss, util_loss] = ...
                    run_ep(s, D_u, D_it, k);            
    try
        % [t, c_mean, c_std, pref_length, test_count,t_test] = run_laplace(s);   
    catch err
        fprintf('%s', ['single_run: ' err.message]);
    end

fprintf('single_run %d : %2.0f is finished!\n', k, i);
return; 