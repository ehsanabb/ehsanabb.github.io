figure;
hold on;
x = [-3:.1:5];
mu1 = 0; mu2 = .5;
sig1 = 2; sig2 = .6;
y = normpdf(x, mu1, sig1);
m = max(y);
plot(x, y, 'b', 'LineWidth', 3);
y = normpdf(x, mu2, sig2);
m = max(max(y), m);
plot(x, y, 'k', 'LineWidth', 3);
y = [0:.1:m + .2];
gamma1 = mu1 + .5 * sig1;
gamma2 = mu2 + .5 * sig2;
l1 = zeros(length(y),1) + gamma1;
l2 = zeros(length(y),1) + mu2 + .5 * sig2;
plot(l1, y, 'b--', 'LineWidth', 2);
plot(l2, y, 'k--', 'LineWidth', 2);
xlabel(['f'], 'FontSize', 24); ylabel('p(f)', 'FontSize', 24);
text(gamma1+.05,.6,...
     '\color{blue}\gamma(u^*,x_2)',...
     'FontSize',20)
 
 text(gamma2-1.2,.7,...
     '\gamma(u^*,x_1)',...
     'FontSize',20)
 
  text(gamma1+.7,.14,...
     '\color{blue}f(u^*,x_2)=N(\mu_2,\sigma_2^2)',...
     'FontSize',20)
 
 text(gamma2-3.4,.5,...
     'f(u^*,x_1)=N(\mu_1,\sigma_1^2)',...
     'FontSize',20)
hold off

print ('-depsc', 'tex/images/util.eps');
system(['epstopdf ' 'tex/images/util.eps']);
