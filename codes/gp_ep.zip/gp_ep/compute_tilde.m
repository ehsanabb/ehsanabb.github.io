function [sig_tilde, mu_tilde, item1, item2] = compute_tilde(pref, i, item_count, Sigma, mu, nu, sig_tilde_all, gamma, n)

one_1 = [1;-1];
one_2 = [1 , -1;
         -1, 1];


user_offset = (pref(i, 1)-1) * item_count;
    item1 = pref(i, 2) + user_offset  
    item2 = pref(i, 3) + user_offset

%     sparse_items(item1) = pref(i, 2);
%     sparse_items(item2) = pref(i, 3);
% 
%     sparse_users(item1) = pref(i, 1);
%     sparse_users(item2) = pref(i, 1);

    sig_t = [Sigma(item1, item1), Sigma(item1,item2);
             Sigma(item2,item1),Sigma(item2,item2)];
    mu_t =  [mu(item1); mu(item2) ]

%     if(det(sig_t) <= 0)
%     continue;
%     end

    %         if(det(sig_tilde) > 0)
    %             inv_sig_tild = inv(sig_tilde);
    %         else
    %             inv_sig_tild = zeros(2,2);
    %         end

    sig_tilde = [sig_tilde_all(item1, item1), sig_tilde_all(item1,item2);
                 sig_tilde_all(item2,item1),sig_tilde_all(item2,item2)];

    sig_sub = (sig_t - sig_tilde); % inv_sig_tild);        % inv
    mu_sub =  (sig_t * mu_t - [nu(item1); nu(item2)] ) % inv_sig_tild * mu_tilde); % sig_sub * 

    %% calcumating \hat(mu) and \hat(sigma): since it is inverted, we invert it first
    % sig_sub is in fact tau 
    sig_sub_inv = inv (correct_singular (sig_sub)); % sig_sub is the precision, hence the inversion
    sig_star = (gamma^2  + sig_sub_inv(1,1) + sig_sub_inv(2,2) - sig_sub_inv(1,2) - sig_sub_inv(2,1))
    if(abs(sig_star) < .01)
    sig_star = .01 * sign(sig_star)
    end
    s = (mu(item1) - mu(item2)) / sig_star
    if(abs(s) > 1000)
    s = 1000 * sign(s);
    end
    coef = (normpdf(s) / normcdf(s));
    if(normcdf(s) == 0 || isnan(coef))
    coef =abs(s);
    end
    coef
    temp =  (coef/sig_star) * one_1  % .* sig_sub_inv 
    changed = true;
    w = (temp * temp' + s/sig_star * temp * one_1' )   % (coef/(sig_star^2) * one_2)
    sig_hat = sig_sub_inv - (sig_sub_inv * w * sig_sub_inv); 
    mu_hat = mu_t + sig_sub_inv * temp % mu_sub here is the \sigma^{-1}mu so we multiply it by \sgima
    sig_hat = inv ( correct_singular(sig_hat))
    %% 
    delta_sig_tilde =  sig_hat - (sig_sub) -  sig_tilde; % correct_singular (inv(sig_hat) )
    sig_tilde = sig_tilde + delta_sig_tilde;  % correct_singular (inv   )
    %sig_tilde = inv(sig_tilde);
    % sig_tilde = max(sig_tilde, 0);
    mu_tilde = (sig_hat * mu_hat - mu_sub); ; %sig_sub * mu_sub)       % sig_tilde * 

    sig_bar = Sigma; %zeros(n,n); % zeros(2,2); %
    sig_bar(item1,item1) = sig_tilde(1,1);
    sig_bar(item1,item2) = sig_tilde(1,2);
    sig_bar(item2,item1) = sig_tilde(2,1);
    sig_bar(item2,item2) = sig_tilde(2,2);

    mu_bar = zeros(n,1); % mu;
    mu_bar(item1) = mu_tilde(1);
    mu_bar(item2) = mu_tilde(2);

    s_ij = Sigma(:,[item1,item2]);    
    delta_inv = (inv(correct_singular(delta_sig_tilde)) )
    
end

