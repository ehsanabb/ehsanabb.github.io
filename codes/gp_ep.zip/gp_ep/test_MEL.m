function [t, t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
            util_loss, util_loss_std, wrongs, wrongs_std]  = test_MEL(suffix, D_u, D_it, utils)
global FID covfunc_u covfunc_x params_u params_it item_count mu;

FID = fopen('results/mel.txt','w');

load (['cache/params_', suffix, '.mat']);
tic 
% mu = nu' * sig;
% mu = sig * nu;

item_count = size(x,1);

%    [K_u] = feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u);  
%    [K_it] = feval (covfunc_x, params_it{1,2}, params_it{2,2}, params_it{3,2}, x); 
  
%    SS =Sigma;     
  %%  SS = inv( correct_singular (kron(K_u,K_it) + inv( correct_singular( S_tilde)) )) ;
SS = sig;     
items = {};
dim_limit = D_it;
best_f = -Inf;
for ui = 1 : size(u,1)    
%    mel{ui} = -Inf;
    for opt = 1 : 2
        items{ui,opt} = [];
        idx = [1:item_count];
        for i = 1 : dim_limit
            reserve_idx = idx(~ismember(idx,idx(items{ui,opt})));
            [index best_f] = MEL(u, ui, x, mu, SS, reserve_idx, 1, best_f); % sig
            items{ui,opt} = [items{ui,opt}; index];
        end    
    end
end 

fclose(FID);
t = toc;
    
for opt = 1 : 2
    [t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
            util_loss, util_loss_std, wrongs, wrongs_std] = test_preference(1:size(u,1), {items{:,opt}}, nu, x, u, ...
        pref, pref_test, covfunc_u, covfunc_x, params_u, params_it, ['mel' num2str(opt)], utils);
end
% 'data/pref_sushi10_test.csv'

end