function [] = test_EVOI()

global FID covfunc_u covfunc_x gamma_u gamma_i item_count g;
FID = fopen('results/evoi.csv','w');

load params.mat
 
item_count = size(x,1);
 indeces = [];
%rnd_ind = randperm(item_count, D_it);
rnd_ind = [];
p = pref(rnd_ind, :);
%it = getItems(p);
[k_inv Sigma nu mu] = ep_efficient_inverse_sparse(...
                K_u, K_it, p, g, size(x,1));
sig = inv(Sigma);
%mu = sig * nu;
all_idx = 1:item_count; %size(pref,1);
while(length(indeces) < D_it)
    it = getItems(pref(indeces,:));
    reserve_idx = all_idx(~ismember(all_idx,all_idx(it)));
    [ind, i,j, evoi] = max_EVOI(u, x, mu, sig, pref, reserve_idx, indeces);
%     if(~ismember(i, indeces))
%         indeces = [indeces, i];
%     end
%     if(~ismember(j, indeces))
%         indeces = [indeces, j];
%     end
    indeces = [indeces, ind];
    %rnd_ind = [rnd_ind(2:D_it), ind]
    rnd_ind = [rnd_ind, ind];
%     if(~ismember(i, rnd_ind))
%         rnd_ind = [rnd_ind(2:D_it), i];
%     end
%     if(~ismember(j, rnd_ind))
%         rnd_ind = [rnd_ind(2:D_it), j];
%     end
    p = pref(rnd_ind, :);
    %it = getItems(p);
    [k_inv Sigma nu mu] = ep_efficient_inverse_sparse(...
                K_u, K_it, p, g, size(x,1));
    sig = inv(Sigma);
    mu = sig * nu;
end

fclose(FID);


[t_test, c_mean, c_std, test_count] = test_preference(1:size(u,1), 1:item_count, nu, x, u, ...
        pref_test, covfunc_u, covfunc_x, gamma_i, gamma_u, 3);

return;


function [ind indx1,indx2, evoi] = max_EVOI(u, x, mu, sig, pref, item_indeces, pref_indx)
    max_evoi = -Inf;
    ss = size(pref, 1);
    for i = 1 : ss
        [evoi] = EVOI(u, pref(i, 1), x, pref(i, 2), pref(i,3), mu, sig, item_indeces); 
        fprintf('%d: %d out of %5.0f\n', i, evoi, ss);
        if(evoi > max_evoi && ~ismember(i, pref_indx))
            max_evoi = evoi;
            indx1 = pref(i, 2);
            indx2 = pref(i, 3);
            ind = i;
        end
    end
return ;


function [indx] = getItems(pref)
    indx = [];
    for i = 1 : size(pref, 1 )
        if(~ismember(pref(i,2), indx))
            indx = [indx, pref(i,2)];
        end
        if(~ismember(pref(i,3), indx))
            indx = [indx, pref(i,3)];
        end
    end
return ;


% for ui = 1 : size(u,1)    
%     mei{ui} = -Inf;
%     for i = 1 : item_count
%        for j = 1 : item_count
%             if(i == j) 
%                 continue; end;
%                 if(~ ismember(i,items) )
%                     xp = [xp; x(i,:)];
%                     items = [items; i];
%                 end
% 
%                 if(~ ismember(j,items) )
%                     xp = [xp; x(j,:)];
%                     items = [items; j];
%                 end
%                 m = mu(items);
%               
%                 fprintf('%d, %d\n', i, j);
%                 mei{ui} = EVOI(ui, i, j, xp, mu(items), Sigma, gamma, mei{ui});
%                 mei{ui} = MEL(ui, xp, mu(items), Sigma);
%         end
%     end
%     xp = [];
%     items = [];
% end 
