function [opt] = get_option(param)
    %load( 'options.mat' );	
    %eval(['opt=' param ';']);
    opt = '';
return ;