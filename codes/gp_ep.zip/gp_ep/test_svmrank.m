
function [t,  c_mean, c_std, loss, loss_std, util_loss, ...
                    util_loss_std, wrongs, wrongs_std, ... 
                    test_count, t_test] ...
            = test_svmrank(suffix, users, item_count)

l = length(users);
test_folds = 10;
t = 0;
correct = 0;
test_count = 0;
t_test = 0;
c_list = [];
pref_orders = [];
loss  = [];
util_loss = [];
wrongs = [];
test_count = [];

p_test = strcat('data/pref_' , suffix , '_test.csv');
for i = 1 : l 
    u = users(i);
    % -t 2 -g 100000 
    str = strcat('cd ../svm_rank_linux/ && ./svm_rank_learn -c 1 -t 4 ../gp_ep/data/svmrank/pref_', ...
                    suffix,'_', num2str(u) , '.dat ../gp_ep/data/svmrank/', suffix,'_', ...
                    num2str(u), '.model');
    system (str);
    tic;
	for j = 1 : test_folds
        pref_test = dlmread( strrep(p_test, '.csv', strcat('.', int2str(j), '.csv')) );
        test_c = 0;
        for idx = 1 : size(pref_test,1)
            idx = idx + 1;
            data_file = strcat('../gp_ep/data/svmrank/pref_test', num2str(j) ,'_', ...
                            suffix,'_', num2str(u), '_', num2str(idx) , '.dat');
            if ~exist(data_file, 'file'), break, end;
            str = ['cd ../svm_rank_linux/ && ./svm_rank_classify', ' ' , data_file, ...
                        ' ', '../gp_ep/data/svmrank/', ...
                        suffix,'_', num2str(u), '.model ../gp_ep/data/svmrank/', ...
                        suffix,'_', num2str(u) , '.prediction | tee ../gp_ep/results/result_svmrank_', ...
                        suffix,'_', num2str(u) , '.txt'];
            [s, tmp] = system ( str );

             tmp = tmp(strfind(tmp, 'Zero/one-error on test set'):end);
             n = tmp(strfind(tmp, '(')+1:strfind(tmp, ',')-9);
             c= str2double(n);
             n = tmp(strfind(tmp, 'incorrect')+11:strfind(tmp, ')')-6);
             tot= str2double(n);
             tmp = tmp(strfind(tmp, ':')+1:strfind(tmp, '%')-1);
             tmp = 100 - str2double(tmp);
             if ~isempty(n) && str2double(n) ~= 0,
                 if( c > 0 )
                    correct = correct + c;
                    pref_orders = [pref_orders; pref_test(idx,1), pref_test(idx,2), pref_test(idx,3)];
                 else
                    pref_orders = [pref_orders; pref_test(idx,1), pref_test(idx,3), pref_test(idx,2)];
                end
             end
            test_c = test_c + tot;
        end
        if test_c == 0 || isnan(correct) || isnan(tot), continue; end;
        test_count = [test_count; test_c];
        [user_loss util_losses wrongs_loss] = test_pref_orders(users, pref_test, pref_orders, item_count, []);
        loss = [loss; sum(user_loss)];
        util_loss = [util_loss; sum(util_losses)];
        wrongs = [wrongs; sum(wrongs_loss) /  test_c * 100];
        c_list = [c_list; correct / test_c * 100];
        pref_orders = [];
        correct = 0;
    end
	t = t + toc;
    t_test  = t_test + toc;
end

if(length(c_list) > 0)
    c_mean = sum(c_list)/length(c_list);
    c_std  = std(c_list);
else
    c_mean = 0;
    c_std  = NaN;
end

loss_std = std(loss);
loss = sum(loss )/length(loss );
util_loss_std = std(util_loss);
util_loss = sum(util_loss)/length(util_loss);
wrongs_std = std(wrongs);
wrongs = sum(wrongs)/length(wrongs);
test_count = sum(test_count) / length(test_count);

return; 

