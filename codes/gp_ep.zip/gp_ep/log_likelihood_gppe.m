% f: full-length vector with posible NaN values
% conditional log-likelihood p(D | f, theta)
function loglike = log_likelihood_gppe(f, sigma, all_pairs, M, N)
loglike = 0; 
M = length(all_pairs);
for j = 1 :  M
    if ( isempty(all_pairs{j}) )
        continue;
    end
    
    pairs = all_pairs{j};
    idx_1 = ind2global(pairs(:,1), j, N);
    idx_2 = ind2global(pairs(:,2), j, N);
    
    
    
    z = ( f(idx_1) - f(idx_2) )/sigma;
    
    % disp(z');
    
    cdf_val  = normcdf(z);
    loglike = loglike + sum(log(cdf_val));
end

return;


