
data = dlmread(['results/' filename]);
bar_tick_width = 10;
marker_size = 10;

if ~exist('no_user_performance', 'var')
   no_user_performance = max(data(:,2)); 
end

%% Results to plot
r_plot = 1;
rl_plot = 0;
rs_plot = 0;
rm_plot = 0;
rm2_plot = 1;
rm3_plot = 0;
rm4_plot = 0;
rm5_plot = 0;
ri_plot = 1;
ri2_plot = 0;
rh1_plot = 1;
kl_plot = 0;
svm_plot = 0;

r_color = 'b--';
rl_color = 'y--';
rs_color = 'r';
rm_color = '[0.2 0.2 .2]';
ri_color = 'k';
ri2_color = 'm';
rh1_color = 'g';
rm2_color = 'b';
rm3_color = 'c';
rm4_color = 'b';
rm5_color = '[0.2 0.2 .2]';
kl_color = 'r';
svm_color = 'r--';

r_marker = 'o';
rl_marker= 'o';
rs_marker = '+';
rm_marker= '*';
ri_marker = 'v';
ri2_marker = 'd';
rh1_marker = 's';
rm2_marker= '+';
rm3_marker = '+';
rm4_marker = '*';
rm5_marker = 'v';
kl_marker = 'd';
svm_marker = '*';