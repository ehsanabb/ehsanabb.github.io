function [t, c_mean, c_std, pref_length, test_count, t_test pref_loss util_loss] = ...
            run_hyper_ep(suffix, D_u, D_it, params_u, params_it, replication)

global FID_RESULTS USE_IDENTITY_KERNEL RUN_EP K_star k_inv gam
filename = ['cache/params_', suffix, '.mat'];

if isempty(FID_RESULTS)
     FID_RESULTS = fopen(strcat('results/accuracy_time_', suffix, '.csv'), 'w');
end

x = dlmread(strcat('data/x_', suffix , '.', num2str(replication) , '.csv'));
u = dlmread(strcat('data/u_', suffix , '.',num2str(replication), '.csv'));
pref = dlmread(strcat('data/pref_', suffix, '.', num2str(replication), '.csv'));
% pref_test = dlmread(strcat('data/pref_' , suffix , '_test.csv'));
pref_test = strcat('data/pref_', suffix , '.', num2str(replication) , '_test.csv');

covfunc_u = 'ard_kernel_m'; %'gaussian_kernel_m'; %'polynomial_kernel_m'; %'linear_kernel_m'; %'gaussian_kernel_m'; %'covSEard';
covfunc_x = 'ard_kernel_m'; %'gaussian_kernel_m'; %'polynomial_kernel_m'; %'linear_kernel_m'; %'gaussian_kernel_m'; %'covSEard';

if exist(strcat('data/utils_', suffix, '.', num2str(replication) , '.csv'), 'file')
    utils = dlmread( strcat('data/utils_', suffix, '.', num2str(replication) , '.csv') );
else
    utils = [];
end

[K_u] = sparse( feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u) );  
[K_it] = sparse( feval (covfunc_x, params_it{1,2}, params_it{2,2}, params_it{3,2}, x) ); 
K_star = sparse(kron(K_u, K_it));
k_inv = sparse( kron(inv(correct_singular(K_u)), inv(correct_singular(K_it))) );
gam = .01;
    
if RUN_EP
    si_x = size(x,1);
    si_u = size(u,1);

    pref_length = size(pref,1);

    %    dlmwrite('K_u.csv', K_u);
    %    dlmwrite('K_it.csv', K_it);
    
    tic
    [Sigma, nu, mu, entropy, sparse_items, sparse_users, S_tilde entropy_ivm sig kl] = ...
    		ep_efficient_inverse_sparse( k_inv, pref, gam, size(x,1) );
    
        
    %    mex ep_efficient.c -lmwlapack
    %    [k_inv Sigma nu mu entropy sparse_items sparse_users S_tilde entropy_ivm] = ep_efficient(K_u, K_it, pref, g, size(x,1)) ;
    %    sig = inv(Sigma);
    %    nu = sig * mu;
      
    t1 = toc;
    save(filename, 'covfunc_u', 'covfunc_x', 'params_u', 'params_it', 'mu', 'x', 'u', ...
                     'pref', 'pref_test', 'nu', 'Sigma', 'sig', ...
                     'entropy', 'sparse_users', 'sparse_items', 't1', 'pref_length', 'entropy_ivm', 'S_tilde', 'kl', 'K_star'); % , 'FID_RESULTS'
else
    fprintf('%s\n', ['EP is not executed, instead previously saved parameters from [' filename ...
                '] is used. Set RUN_EP to true if you wish otherwise.']);
            
    pref_test1 = pref_test;
    load(filename); 
    pref_test = pref_test1;
end                 
% m = nu; 
%else
%    load (filename);
%end  

%[t, c_mean, c_std, test_count, loss, loss_std, util_loss, util_loss_std, wrongs, wrongs_std] ...

t = t1;

clearvars -except D_it D_u FID_RESULTS x u pref pref_test utils nu ...
                    covfunc_u covfunc_x params_u params_it t suffix K_star Sigma mu k_inv gam 

[t_test, c_mean, c_std, test_count, pref_loss, ...
            pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] ...
                = test_preference(1:size(u,1), 1:size(x,1), Sigma, mu, x, u, pref, ...
                pref_test, covfunc_u, covfunc_x, params_u, params_it, 'ep', utils, '', size(x,1)*size(u,1));

%opts{1} = 'users_items';
%opts{2} = 'items';

losses{1} = 'ucb';
losses{2} = 'ivm';
losses{3} = 'voi';

%for opt = 1 : length(opts)
%    update_option('sparse_type', opts{opt});
    for i = 1 : length(D_u)
         for j = 1 : length(D_it)
             for l = 1 : length(losses)
                [t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
                    util_loss, util_loss_std, wrongs, wrongs_std]...
                         = get_min_risks(suffix, D_u(i), D_it(j), losses{l}, utils, pref_test);
             end
         end
    end
%end
pref_length = size(pref,1);


% for i = 1 : length(D_u)
%     for j = 1 : length(D_it)
%         [t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, pref_loss_std2, ...
%             util_loss2, util_loss_std2, wrongs2, wrongs_std2] = test_ivm(suffix, D_u(i), D_it(j), utils);
%         [t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%             pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = ...
%             add_test_pref_results(t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
%                 pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2, ...
%                 t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%                 pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std);
%         
%         [t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, pref_loss_std2, ...
%             util_loss2, util_loss_std2, wrongs2, wrongs_std2] = test_sparse_ep(suffix, D_u(i), D_it(j), 'sparse_ep', utils);
%         [t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%             pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = ...
%             add_test_pref_results(t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
%                 pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2, ...
%                 t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%                 pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std);
%             
%         [t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, pref_loss_std2, ...
%             util_loss2, util_loss_std2, wrongs2, wrongs_std2] = test_sparse_ep(suffix, D_u(i), D_it(j), 'kl', utils);
%         [t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%             pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = ...
%             add_test_pref_results(t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
%                 pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2, ...
%                 t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%                 pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std);
%         
%         [t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, pref_loss_std2, ...
%             util_loss2, util_loss_std2, wrongs2, wrongs_std2] = test_MEL(suffix, D_u(i), D_it(j), utils);
%         [t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%             pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = ...
%             add_test_pref_results(t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
%                 pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2, ...
%                 t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%                 pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std);
%             
%         [t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, pref_loss_std2, ...
%             util_loss2, util_loss_std2, wrongs2, wrongs_std2] = test_heuristics(suffix, D_u(i), D_it(j), utils);
%         [t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%             pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = ...
%             add_test_pref_results(t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
%                 pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2, ...
%                 t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
%                 pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std);
%     end
% end


return ;



% 
% if(D_u > 0 || D_it > 0)
% tic
%     [e, idx] = sort(entropy, 'descend');
%     if D_u < size(u,1)
%         sparse_users = sparse_users(idx); % [dummy idx1] 
%         % sparse_users = sparse_users(idx1);
%         sparse_users = sparse_users(1:D_u);
%     else
%         sparse_users = 1:size(u,1);
%     end
%     if D_it < size(x,1)
%         sparse_items = sparse_items(idx); % [dummy idx1]
%         % sparse_items = sparse_items(idx1,:);
%         sparse_items = sparse_items(1:D_it);
%         clear dummy;
%     else
%         sparse_items = size(x,1);
%     end
%     D = length(sparse_users) * length(sparse_items);
%     idx = idx(1:D);
%     Sigma = Sigma(idx, idx);
%     nu = nu(idx);   
%     t2 = toc ;
%    
%     [t_test2, c_mean2, c_std2, test_count2] = test_preference(sparse_users, sparse_items, ...
%         nu, x, u, pref, pref_test, covfunc_u, covfunc_x, params_u, params_it, 'sparse_ep');
%     
%     t = [t1;t1+t2,];
%     t_test = [t_test;t_test2];
%     c_mean = [c_mean;c_mean2];
%     c_std = [c_std;c_std2];
%     test_count = [test_count;test_count2];
%     pref_length = [pref_length;pref_length];
% end    
