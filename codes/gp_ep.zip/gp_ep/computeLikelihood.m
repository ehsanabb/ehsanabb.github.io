function [s] = computeLikelihood(i,j, mu, sigma, gamma)    
    sig = sigma(i,i) + sigma(j,j) - sigma(i,j) - sigma(j,i) + gamma^2 ;
    s = (mu(i) - mu(j)) / sig;
    s = normcdf(s);
return; 