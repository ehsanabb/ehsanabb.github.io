function [items] = get_partial_prefs(pref, ui, item_count)

p =  pref(pref(:,1) == ui,:);
items = cell(item_count, 1); % size(p, 1)

    for i = 1 : size(p, 1)
        it = items{p(i, 3)};
        it = [it; p(i,2)];
        items{p(i, 3)} = it;
    end

return ;