function prepare_movielense(user_count)

ITEM_LIMIT = 40;
s = ['data/movielense' int2str(ITEM_LIMIT) '.mat' ];
if exist(s, 'file')
    load(s);
else
    system('cp ../socialrec/pref_movielense_700.csv data/');
    system('cp ../socialrec/u_movielense_700.csv data/');
    system('cp ../socialrec/x_movielense_700.csv data/');

    udata = dlmread('data/u_movielense_700.csv', ',');
    idata = dlmread('data/x_movielense_700.csv', ',');
    pref = dlmread('data/pref_movielense_700_1.csv', ',');

    x = idata(1:ITEM_LIMIT,:); 
    pref = pref(pref(:,2)<ITEM_LIMIT,:);
    pref = pref(pref(:,3)<ITEM_LIMIT,:);

    save(s);
end

p = [];
p_test = [];
users = [];
u_id = 0;
user_id = 0;
while length(users) < user_count && u_id < size(udata,1)
%for u_id = 1 : user_count
    u_id = u_id + 1;
    p_u = pref(pref(:,1)==u_id-1,:);
    %p_u = p_u(p_u(:,2)<ITEM_LIMIT,:);
    %p_u = p_u(p_u(:,3)<ITEM_LIMIT,:);    
    p_u = p_u+1;
    if size(p_u,1) > 10
        %p_u(:,1) = p_u(:,1) + 1;
        user_id = user_id + 1;
        p_u(:,1) = user_id;
        l = size(p_u,1);
        l2 = int32(l/2);
        a = randperm(l,l2);
        p = [p;p_u(a,:)]; %
        p_u(a,:) = [];
        p_test = [p_test;p_u];        
        users = [users;u_id];
    end
end

u = udata(users,:); %1:user_count
%pref = pref(ismember(pref(:,1),users-1),:); % 0:user_count-1

u = add_idx(u);
x = add_idx(x);

s = strcat('movielense', int2str(user_count));

dlmwrite(strcat('data/x_', s, '.csv'), x);
dlmwrite(strcat('data/u_', s, '.csv'), u);
dlmwrite(strcat('data/pref_', s, '.csv'), p);
dlmwrite(strcat('data/pref_', s, '_test.csv'), p_test);

partition_csv(strcat('data/pref_', s, '_test.csv'), 10);
return ;