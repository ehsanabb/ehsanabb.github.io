
% system('cat results/results_ep_* > results/results_ep.csv')
% system('cat results/results_sparse_* > results/results_sparse.csv')
% system('cat results/results_laplace_* > results/results_laplace.csv')



r = dlmread('results/new_results_ep.csv');
rs = dlmread('results/new_results_sparse.csv');
rl = dlmread('results/new_results_laplace.csv');

r = sortrows(r,3);
rs = sortrows(rs,3);
rl = sortrows(rl,3);

legend boxoff

figure; 
hold on;
plot(rs(:,3),rs(:,9), 'b', 'LineWidth', 3);
plot(r(:,3),r(:,7), 'r--', 'LineWidth', 3);
plot(rl(:,3),rl(:,7), 'g--', 'LineWidth', 3);
hold off;
xlabel('No. Preferences', 'FontSize', 24); ylabel('Prediction time (s)', 'FontSize', 24);% zlabel('Cumulative Probability');
set(gca, 'FontSize', 24);
leg = legend('Sparse-EP','EP', 'Laplace', 'Location', 'NorthWest');
set(leg, 'Box', 'off')
%set(gca, 'AxesFontSize', 24);

print -depsc 'tex/pred_time.eps'
system('epstopdf tex/pred_time.eps');


clear r, rs, rl, gca

r = dlmread('results/new_results_ep.csv');
rs = dlmread('results/new_results_sparse.csv');
rl = dlmread('results/new_results_laplace.csv');

r = sortrows(r,3);
rs = sortrows(rs,3);
rl = sortrows(rl,3);

%r = r(1:7,:);
%rs = rs(1:7,:);
%%rl = rl(1:10,:);

a_r = [r(:,3), (r(:,4)) * 100,(r(:,5))]; % ./r(:,5))
a_rs = [rs(:,3), (rs(:,4)) * 100,(rs(:,5))]; % ./rs(:,5)
a_rl = [rl(:,3), (rl(:,4)) * 100,(rl(:,5))]; %./rl(:,5)

figure; 
hold on;
errorbar(a_rs(:,1),a_rs(:,2), a_rs(:,3), 'b', 'LineWidth', 3);
errorbar(a_r(:,1),a_r(:,2), a_r(:,3), 'r--', 'LineWidth', 3);
errorbar(a_rl(:,1),a_rl(:,2), a_rl(:,3), 'g--', 'LineWidth', 3);
xlabel('No. Preferences', 'FontSize', 24); ylabel('% Correct predictions', 'FontSize', 24);% zlabel('Cumulative Probability');
set(gca, 'FontSize', 24);
leg = legend('Sparse-EP','EP','Laplace', 'Location', 'SouthEast');
set(leg, 'Box', 'off')
hold off;
%set(leg, 'AxesFontSize', 20);
print -depsc 'tex/pref_prediction.eps'
system('epstopdf tex/pref_prediction.eps');


figure; 
hold on;
plot(rs(:,3),log(rs(:,2)), 'b', 'LineWidth', 3);
plot(r(:,3),log(r(:,2)), 'r--', 'LineWidth', 3);
plot(rl(:,3),log(rl(:,2)), 'g--', 'LineWidth', 3);
hold off;
xlabel('No. Preferences', 'FontSize', 24); ylabel('Inference time (log(s))', 'FontSize', 24);% zlabel('Cumulative Probability');
set(gca, 'FontSize', 24);
leg = legend('Sparse-EP','EP','Laplace',  'Location', 'NorthWest');
set(leg, 'Box', 'off')
%set(gca, 'AxesFontSize', 24);
print -depsc 'tex/training_time.eps'
system('epstopdf tex/training_time.eps');


figue;
c = dlmread('results/new_conv_ep_30.11.2011.00.38_1_210.csv');
hold on 
plot([1:length(c)], c,'LineWidth', 3);
hold off
xlabel('No. Iterations', 'FontSize', 24); ylabel('||\nu_{new} - \nu_{old}||', 'FontSize', 24);% zlabel('Cumulative Probability');
set(gca, 'FontSize', 24);
print -depsc 'tex/convergence.eps'
system('epstopdf tex/convergence.eps');


figure;
r = dlmread('results/all.csv');
r = [r(:,2), r(:,3), r(:,4), r(:,5)];

rs= r(r(:,2) == 2,:);
rl= r(r(:,2) == 4,:);
rm= r(r(:,2) == 3,:);
r= r(r(:,2) == 1,:);

r = sortrows(r,1);
rs = sortrows(rs,1);
rl = sortrows(rl,1);
rm = sortrows(rm,1);

hold on 
errorbar(rs(:,1),(rs(:,3)),rs(:,4) , 'b--', 'LineWidth', 3);
errorbar(r(:,1),(r(:,3)), r(:,4), 'r--', 'LineWidth', 3);
errorbar(rl(:,1),(rl(:,3)), rl(:,4), 'g--', 'LineWidth', 3);
errorbar(rm(:,1),(rm(:,3)), rm(:,4), 'b-', 'LineWidth', 3);
leg = legend('Sparse-EP','EP', 'Laplace', 'Max Loss', 'Location', 'South');
hold off

xlabel('', 'FontSize', 24); ylabel('', 'FontSize', 24);
set(gca, 'FontSize', 24);
print -depsc 'tex/mel.eps'
system('epstopdf tex/mel.eps');

