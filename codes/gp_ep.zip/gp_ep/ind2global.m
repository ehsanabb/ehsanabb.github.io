function  idx_global = ind2global(idx, task_id, N)
idx_global = (task_id-1)*N + idx;
return;
