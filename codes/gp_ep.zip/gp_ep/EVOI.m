function [evoi, mel] = EVOI(u, ui, x, i, j, mu, Sig, indeces)
    global FID g;
    
    [ind, mel_d, S] = MEL(u, ui, x, mu, Sig, indeces);
    
    [ind, mel, S] = MEL(u, ui, x, mu, Sig, [indeces, i,j]);
    l1 = likelihood(i,j, mu, S, g);
    %[ind, mel2, S] = MEL(u, ui, x, mu, Sig, [indeces, j,i]);
    l2 = likelihood(j, i, mu, S, g);    
    evoi = -mel_d + l1 * mel + l2 * mel;
    
%    fprintf(FID, 'user: %d, item1: %d, item2: %d, mei: %d, evoi: %d\n', u, i, j, mei, evoi);
return ;

function [s] = likelihood(i, j, mu, sigma, gamma)
    sig = sigma(1,1) + sigma(2,2) - sigma(1,2) - sigma(2,1) + gamma^2 ;
    s = (mu(i) - mu(j)) / sig;
    s = normcdf(s);
return ;

function [ei] = computeEI(i, f_best, mu, s)
    z = (mu(i) - f_best) / s;
    ei = s * (z * normcdf(z) + normpdf(z));
return ;