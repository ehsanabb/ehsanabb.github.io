function test_optimize_kernel(suffix)

global K_star k_inv gam;
% suffix = 'sushi50';

x = dlmread(strcat('data/x_' , suffix , '.1.csv'));
u = dlmread(strcat('data/u_' , suffix , '.1.csv'));
pref = dlmread(strcat('data/pref_' , suffix , '.1.csv'));
pref_test = strcat('data/pref_' , suffix , '.1_test.csv');

covfunc_u = 'ard_kernel_m'; 
covfunc_it = 'ard_kernel_m';

%if exist('kernels.mat')
%    load kernels.mat
%else
    params_u = init_params(size(u, 2));
%end
[K_u D_u] = feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u);  

if ~exist ('params_it')
    params_it = init_params(size(x, 2));
end
[K_it D_it] = feval (covfunc_it, params_it{1,2}, params_it{2,2}, params_it{3,2}, x); 

old_params_u = params_u;
old_params_it = params_it;
gam = 3;

converged = false;
iter = 1;
results = [];

[K_u] = sparse( feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u) );  
[K_it] = sparse( feval (covfunc_it, params_it{1,2}, params_it{2,2}, params_it{3,2}, x) ); 
K_star = sparse(kron(K_u, K_it));
k_inv = sparse( kron(inv(correct_singular(K_u)), inv(correct_singular(K_it))) );

while(~converged && iter < 10)
    fprintf('Iteration %2.0f\n', iter);
    [Sigma, nu mu] = ...
            ep_efficient_inverse_sparse(k_inv, pref, 3, size(x,1));

	if issparse(Sigma)
        Sigma = full(Sigma);
    end
        
    [K_u K_it params_u params_it] = optimize_kernel(u, x, covfunc_u, covfunc_it, ...
                K_u, K_it, D_u, D_it, params_u, params_it, nu, Sigma);

	[t_test, c_mean, c_std, test_count] = test_preference(1:size(u,1),  1:size(x,1), Sigma, mu, x, ...
        u, pref, pref_test, covfunc_u, covfunc_it, params_u, params_it, 'optimize_kernel',[] , '', size(x,1)*size(u,1));
            
    converged = (iter > 2 && check_params(params_u, old_params_u) && check_params(params_it, old_params_it));
    
    filename = get_filename(iter, suffix); %strcat('k_params_', int2str(iter), '_', suffix, '.mat');
    results = [results; iter, c_mean, c_std];
    
    save (['cache/kernel_records_', suffix , '.mat'], 'results');
    save (filename);
    iter = iter + 1;
end

[b idx] = max(results(:,2))
best = results(idx, :)
s = regexprep(suffix, '\d*', '');
s = regexprep(s, '-[\w]*', '');

load( get_filename(best(1), suffix) );
save(['cache/kernels_', s, '.mat'], 'params_u', 'params_it'); %kernels.mat 
save(['cache/kernels_', suffix, '.mat'], 'params_u', 'params_it'); 

% old
% system( ['rm', ' ', 'kerenls.mat'] );
% system( ['cp', ' ', 'k_params_', int2str(best(1)), '_', suffix, '.mat', ' ', 'kerenls.mat'] );
% load kernels.mat
% save kernels.mat 'params_u' 'params_it'
% system( ['cp', ' ', 'kernels.mat kernels_', s, '.mat'] );

return; 

function [filename] = get_filename(iter, suffix)
    filename = strcat('k_params_', int2str(iter), '_', suffix, '.mat');
    filename = ['cache/' filename];
return;

function [check] = check_params(params, old_params)
s = 0;
for i = 1 : (size(params, 1))
     s = s + norm(params{i,2} - old_params{i,2});
end
   check = s < .5;
return; 

function [params] = init_params(dim)
    params = cell(3,2);
    params{1,1} = 'sigma1';
    params{1,2} = 1;
    params{2,1} = 'sigma2';
    params{2,2} = 1;
    params{3,1} = 'M';
    params{3,2} = eye(dim); % -0
return;