function [Kn] = normalize_kernel(K)
    Kn = zeros(size(K));
    for i = 1 : size(K,1)
        for j = 1 : i
            Kn(i,j) = K(i,j) / sqrt( K(i,i) * K(j,j) );
            Kn(j,i) = Kn(i,j);
        end
    end
return;