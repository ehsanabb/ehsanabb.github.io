
function [ k ] = gaussian_kernel( x1, x2, gamma )
	k = exp(-gamma * norm(x1 - x2).^2 / 2  );
end

