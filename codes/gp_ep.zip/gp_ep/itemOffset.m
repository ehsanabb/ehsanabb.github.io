function [item1, item2] = itemOffsets(u, i, item_count)

user_offset = (u-1) * item_count;
item1 = i + user_offset  ;
item2 = j + user_offset;

end