function plot_accuracy(filename, epspath, no_user_performance, rc, add_legend)
global replication_count

if ~exist('rc', 'var')
    rc = 10;
end

replication_count = rc;

%if ~exist('filename', 'var') || length(filename) == 0
%    filename = '-accuracy_time_synthetic_19.02.2012.14.26-.csv';
%    epspath = 'synthetic_noiseless-5';
%else
%    system(['cp results/' filename ' -' filename]);
%end

data = dlmread(['results/' filename]);
bar_tick_width = 10;
marker_size = 10;

if ~exist('no_user_performance', 'var')
   no_user_performance = max(data(:,2)); 
end


record = fopen(['results/', 'records.txt'], 'a');
fprintf(record, '%s\n', filename);
fclose(record);


%% Results to plot
r_plot = 1;
rl_plot = 0;
rs_plot = 0;
rm_plot = 0;
rm2_plot = 1;
rm3_plot = 0;
rm4_plot = 0;
rm5_plot = 0;
ri_plot = 1;
ri2_plot = 0;
rh1_plot = 1;
kl_plot = 0;
svm_plot = 0;

r_color = 'b--';
rl_color = 'y--';
rs_color = 'r';
rm_color = '[0.2 0.2 .2]';
ri_color = 'k';
ri2_color = 'm';
rh1_color = 'g';
rm2_color = 'b';
rm3_color = 'c';
rm4_color = 'b';
rm5_color = '[0.2 0.2 .2]';
kl_color = 'r';
svm_color = 'r--';

r_marker = 'o';
rl_marker= 'o';
rs_marker = '+';
rm_marker= '*';
ri_marker = 'v';
ri2_marker = 'd';
rh1_marker = 's';
rm2_marker= '+';
rm3_marker = '+';
rm4_marker = '*';
rm5_marker = 'v';
kl_marker = 'd';
svm_marker = '*';

loss_term = 'Loss';

%%
%sub_data = [data(:,1),data(:,2), data(:,3), data(:,4), data(:,5), data(:,6),data(:,7),data(:,13), data(:,8), data(:,9)];
sub_data =data;

draw_line =false;

var_idces = [5,7];
sub_data(:,var_idces) = sub_data(:,var_idces) * 2. / sqrt(replication_count); % 10 fold 
sub_data(:,10) = sub_data(:,10) ./ max(sub_data(:,10)) * 100;

if ~exist('no_user_performance', 'var')
    no_user_performance = max(sub_data(:,2));
end

if ~exist('add_legend', 'var')
    add_legend = false;
end

r_data_idx = 1;
rl_data_idx = 4;
svm_data_idx = 20;
rs_data_idx = 2;
rm_data_idx = 3;
ri_data_idx = 5;
ri2_data_idx = 6;
rh1_data_idx = 7;
rm2_data_idx = 8;
rm3_data_idx = 9;
rm4_data_idx = 10;
rm5_data_idx = 11;
kl_data_idx = 12;

r = sub_data(sub_data(:,3) == r_data_idx,:);
rl = sub_data(sub_data(:,3) == r_data_idx,:);
svm = sub_data(sub_data(:,3) == svm_data_idx,:);
rs_data = sub_data(sub_data(:,3) == rs_data_idx,:);
rm_data = sub_data(sub_data(:,3) == rm_data_idx,:);
ri_data = sub_data(sub_data(:,3) == ri_data_idx,:);
ri2_data = sub_data(sub_data(:,3) == ri2_data_idx,:);
rh1_data = sub_data(sub_data(:,3) == rh1_data_idx,:);
rm2_data = sub_data(sub_data(:,3) == rm2_data_idx,:);
rm3_data = sub_data(sub_data(:,3) == rm3_data_idx,:);
rm4_data = sub_data(sub_data(:,3) == rm4_data_idx,:);
rm5_data = sub_data(sub_data(:,3) == rm5_data_idx,:);
kl_data = sub_data(sub_data(:,3) == kl_data_idx,:);

% UNNECESSARY
r = max_idx_unique(r,2,4);
rl = max_idx_unique(rl,2,4);
svm = max_idx_unique(svm,2,4);

%legend_cell = {'Full EP', 'Full Laplace', 'IVM', 'VVM-VOI', 'VVM-UCB'};
i=1;
%legend_cell{1,i} = 'Full GP';
%i = 2;
if ~isempty(svm) && svm_plot
    legend_cell{1,i} = 'SVM-Rank';
    i = i + 1;
end
legend_cell{1,i} = 'IVM';
i = i + 1;
legend_cell{1,i} = 'VVM-VOI';
i = i + 1;
legend_cell{1,i} = 'VVM-UCB';

% rs = rs(rs(:,1) == max_dim(rs,1,4),:); % 1
% rm = rm(rm(:,1) == max_dim(rm,1,4),:);
if isempty(rl); rl=zeros(size(r)); end;

r = sortrows(r,2);
rl = sortrows(rl,2);
if ~isempty(svm), svm = sortrows(svm,2); end;

% if no_user_performance == -1, user_item = true; else, user_item = false; end;

if ~isempty(strfind(filename, 'users_items')), 
    user_item = true;     
    additional_filename_term = '_users_item';
else
    user_item = false; 
    additional_filename_term = '';
end;

%if user_item 
    sparse_dims = unique( data(:,15) );% unique(data(:,1).*data(:,2)); %./max(rm2_data(:,1).*rm2_data(:,2))*100;
%else
%    sparse_dims = unique(data(:,1));
%end
for no_user_idx = 1 : length(no_user_performance)
    no_user = no_user_performance(no_user_idx);

    dims = sort(sparse_dims, 'ascend');
    if user_item, 
        dims_idx = [1:max(1,int32((length(sparse_dims)/12))):length(sparse_dims)];
        dims_idx = unique( [dims_idx, (length(sparse_dims)-5):length(sparse_dims)] );
        dims_idx(dims_idx == 0) = [];
        dims_idx(dims_idx > length(dims)) = [];
        dims = unique( dims(dims_idx) );
        clearvars dims_idx
    end
    dims1 = [4,10,13,14] ;  
    for i = 1 : length(dims1) % 2
        dim1 = dims1(i);
        dim2 = dim1 + 1;
        if dim1 == 13, dim2 = size(data,2)+1; end;
            
        tex_tbl = dims;
 
           if size(tex_tbl,1) == length(dims),
                tex_tbl = [0; tex_tbl];            
            end
            
            figure('visible','off');
            hold on

          %  if user_item,
                [ii sparsity_dim] = select_idx( dims .* 100 ./ max(dims) );
          %  else
          %      [ii sparsity_dim] = select_idx( dims .* 100 ./ max(r(:,1)) );
          %  end
      %  try
            if i == 1
                term = '$\% 0/1$ Loss';
                const = 100; coef = -1;
                filename_term = [epspath '_performance' int2str(no_user) '_error'];
                if draw_line
                    idx = zeros(size(sparsity_dim));
                    if user_item
                        errorbar(sparsity_dim, idx+const + coef*mean(r(:,dim1)), ...
                        idx+mean(r(:,dim2)), r_color, 'Marker', ...
                        r_marker, 'MarkerSize', marker_size, 'LineWidth', 3); % a,
                    else
                        errorbar(sparsity_dim, idx+const + coef*mean(r(r(:,2) == no_user,dim1)), ...
                        idx+mean(r(r(:,2) == no_user,dim2)), r_color, 'Marker', ...
                        r_marker, 'MarkerSize', marker_size, 'LineWidth', 3); % a,
                    end
                end
            elseif i == 2
                term = 'Recommendation Loss';
                const = 0; coef = 1; % / no_user_performance;
                filename_term = [epspath '_performance' int2str(no_user) '_loss'];
                if draw_line                    
                    idx = zeros(size(sparsity_dim));
                    if user_item
                        errorbar(sparsity_dim, idx+const + coef*mean(r(:,dim1)), ...
                            idx+mean(r(:,dim2)), r_color, 'Marker', ...
                            r_marker, 'MarkerSize', marker_size, 'LineWidth', 3); % a,
                    else
                         errorbar(sparsity_dim, idx+const + coef*mean(r(r(:,2) == no_user,dim1)), ...
                            idx+mean(r(r(:,2) == no_user,dim2)), r_color, 'Marker', ...
                            r_marker, 'MarkerSize', marker_size, 'LineWidth', 3); % a,
                    end
                end
            elseif i == 3
                term = 'Time (s)';
                const = 0; coef = 1; % 100 / mean(r(r(:,2) == no_user,13)); 
                filename_term = [epspath int2str(no_user) '_time'];
                idx = zeros(size(sparsity_dim));
                c = idx;
                b = idx + mean(r(r(:,2) == no_user,dim1));
                idx = idx + 100;
                hh=errorbar(sparsity_dim, b, c, r_color, 'Marker', ...
                    r_marker, 'MarkerSize', marker_size, 'LineWidth', 3); % a,
                c = [idx,b];
                c = [[0,0];c];
              %  tex_tbl = [tex_tbl, c];
                clear a b c;
            else 
                term = '$p(\mathcal{D}|\textbf{f})$';
                const = 0; coef = 1;
                filename_term = [epspath '_performance' int2str(no_user) '_log'];
           end

 
          y_max = -100;
          y_min = 100;
            
            if rs_plot
%                 means = getmeans(dims, rs_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));                
%                 means = means(ii,:);
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%                if coef > 0, means(:,2) = coef * means(:,2); end;
%                if dim1 == 14,
%                    loglog(sparsity_dim, means(:,1), rs_color, 'Marker', rs_marker, ...
%                         'MarkerSize', marker_size, 'LineWidth', 3);
%                else
%                     hh=errorbar(sparsity_dim, means(:,1), means(:,2), rs_color, 'Marker', rs_marker, ...
%                         'MarkerSize', marker_size, 'LineWidth', 3);
%                end
%                 errorbar_tick(hh,bar_tick_width,2);            
%                 means = [[rs_data_idx,rs_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)-means(:,2)));

                [tex_tbl y_min y_max] = add_row_performance(rs_data, rs_color, rs_marker, ...
                                marker_size, rs_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);
            end
            if ri_plot
%                 means = getmeans(dims, ri_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%               %  if coef > 0, means(:,2) = coef * means(:,2); end;
%               if dim1 == 14,
%                   loglog(sparsity_dim, means(:,1), ri_color,'Marker', ri_marker,  ...
%                     'MarkerSize', marker_size, 'LineWidth', 3);
%               else
%                 hh=errorbar(sparsity_dim, means(:,1), means(:,2), ri_color,'Marker', ri_marker,  ...
%                     'MarkerSize', marker_size, 'LineWidth', 3);
%               end 
%                 %errorbar_tick(hh,bar_tick_width,2);            
%                 means = [[ri_data_idx,ri_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)));

                [tex_tbl y_min y_max] = add_row_performance(ri_data, ri_color, ri_marker, ...
                                marker_size, ri_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);
            end
            if ri2_plot
%                 means = getmeans(dims, ri2_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%                % if coef > 0, means(:,2) = coef * means(:,2); end;
%                if dim1 == 14,
%                   loglog(sparsity_dim, means(:,1), ri2_color,'Marker', ri2_marker, ...
%                         'MarkerSize', marker_size, 'LineWidth', 3);
%                else
%                     hh= errorbar(sparsity_dim, means(:,1), means(:,2), ri2_color,'Marker', ri2_marker, ...
%                         'MarkerSize', marker_size, 'LineWidth', 3);
%                end
%                 %errorbar_tick(hh,bar_tick_width,2);            
%                 means = [[ri2_data_idx,ri2_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)-means(:,2)));

                [tex_tbl y_min y_max] = add_row_performance(ri2_data, ri2_color, ri2_marker, ...
                                marker_size, ri2_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);
            end
            if rm_plot
%                  means = getmeans(dims, rm_data, 1, dim1, dim2, no_user, user_item);
%                  means(:,1) = const  + coef * means(:,1);
%                  m = means;
%                  ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%                 if coef > 0, means(:,2) = coef * means(:,2); end;
%                if dim1 == 14,
%                   loglog(sparsity_dim, means(:,1), rm_color, 'Marker', rm_marker, ...
%                      'MarkerSize', marker_size, 'LineWidth', 3);
%               else
%                  hh= errorbar(sparsity_dim, means(:,1), means(:,2), rm_color, 'Marker', rm_marker, ...
%                      'MarkerSize', marker_size, 'LineWidth', 3);
%                end
%                  errorbar_tick(hh,bar_tick_width,2);                      
% 
%                 means = [[rm_data_idx,rm_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)-means(:,2)));

                [tex_tbl y_min y_max] = add_row_performance(rm_data, rm_color, rm_marker, ...
                                marker_size, rm_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);
            end
            if rm2_plot
%                 means = getmeans(dims, rm2_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%               %  if coef > 0, means(:,2) = coef * means(:,2); end;
%                 if dim1 == 14,
%                     loglog(sparsity_dim, means(:,1), rm2_color, 'Marker', rm2_marker, ...
%                     'MarkerSize', marker_size,'LineWidth', 3);
%                 else
%                     hh= errorbar(sparsity_dim, means(:,1), means(:,2), rm2_color, 'Marker', rm2_marker, ...
%                         'MarkerSize', marker_size,'LineWidth', 3);
%                 end 
%                 %errorbar_tick(hh,bar_tick_width,2);            
%                 means = [[rm2_data_idx,rm2_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)-means(:,2)));

                [tex_tbl y_min y_max] = add_row_performance(rm2_data, rm2_color, rm2_marker, ...
                                marker_size, rm2_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);
            end
            if rm3_plot
%                 means = getmeans(dims, rm3_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%               %  if coef > 0, means(:,2) = coef * means(:,2); end;
%                 hh= errorbar(sparsity_dim, means(:,1), means(:,2), rm3_color, 'Marker', rm3_marker, ...
%                 'MarkerSize', marker_size,'LineWidth', 3);
%                 %errorbar_tick(hh,bar_tick_width,2);                        
%                 means = [[rm3_data_idx,rm3_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)));

                [tex_tbl y_min y_max] = add_row_performance(rm3_data, rm3_color, rm3_marker, ...
                                marker_size, rm3_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);


            end
            if rm4_plot
%                 means = getmeans(dims, rm4_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%               %  if coef > 0, means(:,2) = coef * means(:,2); end;
%                 hh=  errorbar(sparsity_dim, means(:,1), means(:,2), rm4_color,'Marker', rm4_marker, ...
%                 'MarkerSize', marker_size, 'LineWidth', 3);
%                 %errorbar_tick(hh,bar_tick_width,2);                        
%                 means = [[ri_data_idx,rm_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)-means(:,2)));

                [tex_tbl y_min y_max] = add_row_performance(rm4_data, rm4color, rm4_marker, ...
                                marker_size, rm4_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);

            end
            if rm5_plot
%                 means = getmeans(dims, rm5_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%               %  if coef > 0, means(:,2) = coef * means(:,2); end;
%                 hh= errorbar(sparsity_dim, means(:,1), means(:,2), rm5_color,'Marker', rm5_marker, ...
%                     'MarkerSize', marker_size, 'LineWidth', 3);
%                 %errorbar_tick(hh,bar_tick_width,2);            
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)-means(:,2)));

                [tex_tbl y_min y_max] = add_row_performance(rm5_data, rm5_color, rm5_marker, ...
                                marker_size, rm5_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);

            end

            if rh1_plot            
%                 means = getmeans(dims, rh1_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%               %  if coef > 0, means(:,2) = coef * means(:,2); end;
%                 if dim1 == 14,
%                     loglog(sparsity_dim, means(:,1), rh1_color,'Marker', rh1_marker, ...
%                         'MarkerSize', marker_size, 'LineWidth', 3);
%                 else
%                     hh= errorbar(sparsity_dim, means(:,1), means(:,2), rh1_color,'Marker', rh1_marker, ...
%                         'MarkerSize', marker_size, 'LineWidth', 3);
%                 end
%                 %errorbar_tick(hh,bar_tick_width,2);            
%                 means = [[rh1_data_idx,rh1_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)-means(:,2)));

                [tex_tbl y_min y_max] = add_row_performance(rh1_data, rh1_color, rh1_marker, ...
                                marker_size, rh1_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);

            end 
            if kl_plot            
%                 means = getmeans(dims, kl_data, 1, dim1, dim2, no_user, user_item);
%                 means(:,1) = const  + coef * means(:,1);
%                 m = means;
%                 ii = ~isnan(means(:,1));
%                 means = means(ii,:);
%                 ii = ismember(means(:,1),including_dim_percent);
%                 means = means(ii,:);
%                 sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));
%                 ii =  (sparsity_dim <= 80) ;
%                 means = means(ii,:);
%                 sparsity_dim = sparsity_dim(ii,:);
%               % if coef > 0, means(:,2) = coef * means(:,2); end;
%                 hh= errorbar(sparsity_dim, means(:,1), means(:,2), kl_color,'Marker', kl_marker, ...
%                     'MarkerSize', marker_size, 'LineWidth', 3);
%                 %errorbar_tick(hh,bar_tick_width,2);            
%                 means = [[kl_data_idx,kl_data_idx];m];
%                 tex_tbl = [tex_tbl, means];
%                 y_max = max(y_max, max(means(:,1)+means(:,2)));
%                 y_min = min(y_min, min(means(:,1)-means(:,2)));

                [tex_tbl y_min y_max] = add_row_performance(kl_data, kl_color, kl_marker, ...
                                marker_size, kl_data_idx, tex_tbl, ...
                                dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max);

            end 

            % leg = legend('EP','Laplace', 'Sparse-EP', 'Recommendatin Gain', 'IVM-EP1', 'IVM-Ep2', 'Location', 'BestOutside'); % 'NorthEast'     	    
            %  if i == 1
            %       ylim([y_min; y_max]); % ylim([90; 100]);               
            %  else
            %       ylim([0; 7]);
            %  end
            %  ylim([y_min; y_max]);
        
            if user_item,
                xlabel(['Percentage of users/items selected'], 'FontSize', 24); 
            else
                xlabel(['Percentage of items selected'], 'FontSize', 24); 
            end
            ylabel(term,'Interpreter','LaTex', 'FontSize', 24);            
            % leg = legend ('VVM', 'IVM', 'UCB-GP', 'Location', 'BestOutside');                               
            % if add_legend
            %    leg = legend (legend_cell{1,[1:4]}, 'Location', 'Best');  % 'Best'
            %    legend boxoff
            % end
            
            hold off  
            
            if i == 3 || add_legend
                leg = legend (legend_cell{1,[1:size(legend_cell,2)]}, 'Location', 'North');  % 'Best'
                legend boxoff
            end

            set(gca, 'FontSize', 24);                    
            axis tight      
           
            label = ['tex/images/'  filename_term additional_filename_term]; % int2str(dim1)
            print ('-depsc', [label '.eps']);
            system(['epstopdf ' label '.eps']);

            build_tex_table(tex_tbl,  'Performance', ...
            [filename_term], false);      
    end
end

return ;

%% plots
for d = sparse_dims'    
    sparsity_dim_percent = num2str( d * 100 / max(r(:,1)), '%2.1f');
    ri = ri_data(ri_data(:,1) == d,:);
    ri2 = ri2_data(ri2_data(:,1) == d,:);
    rs = rs_data(rs_data(:,1) == d,:); 
    rm = rm_data(rm_data(:,1) == d,:);
    rh1 = rh1_data(rh1_data(:,1) == d,:);
    rm2 = rm2_data(rm_data(:,1) == d,:);
%    rm3 = rm3_data(rm_data(:,1) == d,:);
%    rm4 = rm4_data(rm_data(:,1) == d,:);
%    rm5 = rm5_data(rm_data(:,1) == d,:);
    kl = kl_data(kl_data(:,1) == d,:);
    
    if isempty(rs); rs=zeros(size(r)); end;
    if isempty(ri); ri=zeros(size(r)); end;
    if isempty(ri2); ri2=zeros(size(r)); end;
    
    ri = sortrows(ri,2);
    ri2 = sortrows(ri2,2);
    rh1 = sortrows(rh1,2);
    rm = sortrows(rm,2);
    rs = sortrows(rs,2);
    rm2 = sortrows(rm2,2);
 %   rm3 = sortrows(rm3,2);
 %   rm4 = sortrows(rm4,2);
 %   rm5 = sortrows(rm5,2);
    kl = sortrows(kl,2);

% ---------------------------------------------------
    try
        figure('visible','off');
        hold on;
        if r_plot
            plot(r(:,2),(r(:,13))  , r_color, 'LineWidth', 3, 'Marker', r_marker, 'MarkerSize', marker_size);
        end
        if rl_plot
            plot(rl(:,2),rl(:,13) , rl_color, 'LineWidth', 3, 'Marker', rl_marker,'MarkerSize', marker_size);
        end
        if svm_plot && ~isempty(svm)
            plot(svm(:,2),(svm(:,8))  , svm_color, 'LineWidth', 3, 'Marker', svm_marker,'MarkerSize', marker_size);
        end
        if rs_plot
            plot(rs(:,2),rs(:,13) , rs_color, 'LineWidth', 3, 'Marker', r_marker, 'MarkerSize', marker_size);
        end
        if ri_plot
            plot(ri(:,2),ri(:,13) , ri_color, 'LineWidth', 3, 'Marker', ri_marker, 'MarkerSize', marker_size);
        end
        if ri2_plot
            plot(ri2(:,2),ri2(:,13) , ri2_color, 'LineWidth', 3, 'Marker', ri2_marker, 'MarkerSize', marker_size);
        end
        if rm_plot
            plot(rm(:,2),rm(:,13) , rm_color, 'LineWidth', 3, 'Marker', rm_marker, 'MarkerSize', marker_size);
        end
        if rm2_plot
            plot(rm2(:,2),rm2(:,13) , rm2_color, 'LineWidth', 3, 'Marker', rm2_marker, 'MarkerSize', marker_size);
        end
        if rm3_plot
            plot(rm3(:,2),rm3(:,13) , rm3_color, 'LineWidth', 3, 'Marker', rm3_marker, 'MarkerSize', marker_size);
        end
        if rm4_plot
            plot(rm4(:,2),rm4(:,13) , rm4_color, 'LineWidth', 3, 'Marker', rm4_marker, 'MarkerSize', marker_size);
        end
        if rm5_plot
            plot(rm5(:,2),rm5(:,13) , rm5_color, 'LineWidth', 3, 'Marker', rm5_marker, 'MarkerSize', marker_size);
        end
        if rh1_plot            
            plot(rh1(:,2),rh1(:,13) , rh1_color, 'LineWidth', 3, 'Marker', rh1_marker, 'MarkerSize', marker_size);
        end 
        if kl_plot            
            plot(kl(:,2),kl(:,13) , kl_color, 'LineWidth', 3, 'Marker', kl_marker, 'MarkerSize', marker_size);
        end 
        xlabel(['No. Users'], 'FontSize', 24); ylabel('Time (s)', 'FontSize', 24);
        hold off
    catch err
        fprintf('%s\n%s\n', ['plot_accuracy: ' epspath num2str(d)], err.message);
    end
%%    leg = legend (legend_cell, 'Location', 'NorthWest'); % <- this is the one
    
    % set(leg, 'FontSize', 14);
   % leg = legend('EP','Laplace', 'Sparse-EP', 'Max Loss (mean+varaince max)', 'Max Loss (mean max)', ...
   %     'Max Loss (utility mean max)', 'Max Loss (utility mean+variance max)', 'IVM-EP1', 'IVM-EP2', ...
   %     'Posterior mean+variance', 'Location', 'BestOutside'); % NorthEast

    set(gca, 'FontSize', 24);
      
    axis tight
    
    %fprintf('%s', epspath);
    print ('-depsc', ['tex/images/' epspath num2str(d) '_time' additional_filename_term '.eps']);
    system(['epstopdf ' 'tex/images/' epspath num2str(d) '_time' additional_filename_term '.eps']);

% -----------------------------------------------    
% plot utilties 
 sparsity_dim = r(:,2); % .* 100 ./ max(r(:,1)); 

try
        figure('visible','off');
        hold on;
        if r_plot
            errorbar(sparsity_dim,(r(:,8)),(r(:,9)) , r_color,'MarkerSize', marker_size, 'Marker', r_marker, 'LineWidth', 3);
        end
        if rl_plot
            errorbar(sparsity_dim,rl(:,8),rl(:,9) , rl_color,'MarkerSize', marker_size, 'Marker', rl_marker, 'LineWidth', 3);
        end
        if svm_plot && ~isempty(svm)
            errorbar(svm(:,2),(svm(:,8)),(svm(:,9))  , svm_color,'MarkerSize', marker_size, 'Marker', svm_marker, 'LineWidth', 3);
        end
        if rs_plot
            errorbar(sparsity_dim,rs(:,8),rs(:,9) , rs_color,'MarkerSize', marker_size, 'Marker', rs_marker, 'LineWidth', 3);
        end
        if ri_plot
            errorbar(sparsity_dim,ri(:,8),ri(:,9) , ri_color,'MarkerSize', marker_size, 'Marker', ri_marker, 'LineWidth', 3);
        end
        if ri2_plot
            errorbar(sparsity_dim,ri2(:,8),ri2(:,9) , ri2_color,'MarkerSize', marker_size, 'Marker', ri2_marker, 'LineWidth', 3);
        end
        if rm_plot
            errorbar(sparsity_dim,rm(:,8) ,rm(:,9) , rm_color,'MarkerSize', marker_size, 'Marker', rm_marker, 'LineWidth', 3);
        end
        if rm2_plot
            errorbar(sparsity_dim,rm2(:,8),rm2(:,9) , rm2_color,'MarkerSize', marker_size, 'Marker', rm2_marker, 'LineWidth', 3);
        end
        if rm3_plot
            errorbar(sparsity_dim,rm3(:,8) ,rm3(:,9) , rm3_color,'MarkerSize', marker_size, 'Marker', rm3_marker, 'LineWidth', 3);
        end
        if rm4_plot
            errorbar(sparsity_dim,rm4(:,8),rm4(:,9)  , rm4_color,'MarkerSize', marker_size, 'Marker', rm4_marker, 'LineWidth', 3);
        end
        if rm5_plot
            errorbar(sparsity_dim,rm5(:,8), rm5(:,9) , rm5_color,'MarkerSize', marker_size, 'Marker', rm5_marker, 'LineWidth', 3);
        end

        if rh1_plot            
            errorbar(sparsity_dim,rh1(:,8),rh1(:,9) , rh1_color,'MarkerSize', marker_size, 'Marker', rh1_marker, 'LineWidth', 3);
        end 
        if kl_plot            
            errorbar(sparsity_dim,kl(:,8),kl(:,9) , kl_color, 'MarkerSize',marker_size, 'Marker', kl_marker, 'LineWidth', 3);
        end 
        xlabel(['No. Users'], 'FontSize', 24); ylabel('Wrong Prediction Utility', 'FontSize', 24);
        
        
        hold off
    catch err
        fprintf('%s\n%s\n', ['plot_accuracy: ' epspath num2str(d)], err.message);
    end
%%    leg = legend (legend_cell, 'Location', 'NorthWest'); % <- this is the one
    
    % set(leg, 'FontSize', 14);
   % leg = legend('EP','Laplace', 'Sparse-EP', 'Max Loss (mean+varaince max)', 'Max Loss (mean max)', ...
   %     'Max Loss (utility mean max)', 'Max Loss (utility mean+variance max)', 'IVM-EP1', 'IVM-EP2', ...
   %     'Posterior mean+variance', 'Location', 'BestOutside'); % NorthEast

    set(gca, 'FontSize', 24)    ;
       
    axis tight
    
    %fprintf('%s', epspath);
    print ('-depsc', ['tex/images/' epspath num2str(d) '_util' additional_filename_term '.eps']);
    system(['epstopdf ' 'tex/images/' epspath num2str(d) '_util' additional_filename_term '.eps']);
    
    
%     try
%         figure('visible','off');
%         a = [r(:,6),rl(:,6),rs(:,6),rm(:,6),ri(:,6),ri2(:,6)];
%         bar(a);
%         a = unique(data(:,12));
%         set(gca, 'FontSize', 24);
%         xlabel(['\times ' num2str(r(2,2) - r(1,2)) ' Users , Sparse Dimensions: ' num2str(d)], 'FontSize', 24); ylabel(['Loss in (Users \times ' num2str(a(2)-a(1)) ' Preferences)'], 'FontSize', 24);
%         set(gca, 'FontSize', 24);
%         print ('-depsc', ['tex/images/' epspath num2str(d) '_err.eps']);
%         system(['epstopdf ' 'tex/images/' epspath num2str(d) '_err.eps']);
%     catch err
%         fprintf('%s', ['plot_accuracy: ' err.message]);
%     end
% ---------------------------------------------------

    y_max = -100;
    y_min = 100;
    
    dims = [4,6];
    for i = 1 : 2
        dim1 = dims1(i);
        dim2 = dim1 + 1;
    
        if i == 2
            term = 'Recommendation Loss';
            const = 0; coef = 1;
            filename_term ='loss';
        else
            term = '% 0/1 Loss';
            const = 100; coef = -1;
            filename_term = 'error';
       end

    
        try
            figure('visible','off');
            hold on;
            if r_plot
                s = const+ coef*(r(:,dim1));
                errorbar(r(:,2), s, r(:,dim2) , r_color,'MarkerSize',marker_size, 'Marker', r_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+r(:,dim2)));
                y_min = min(y_min, min(s-r(:,dim2)));
            end
            if rl_plot
                s = const+ coef*(rl(:,dim1));
                errorbar(rl(:,2),s,rl(:,dim2) , rl_color,'MarkerSize',marker_size, 'Marker', rl_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+rl(:,dim2)));
                y_min = min(y_min, min(s-rl(:,dim2)));

            end
            if svm_plot  && ~isempty(svm)
                s = const+ coef*(svm(:,dim1));
                errorbar(svm(:,2),s,svm(:,dim2) , svm_color,'MarkerSize',marker_size, 'Marker', svm_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+svm(:,dim2)));
                y_min = min(y_min, min(s-svm(:,dim2)));

            end
            if rs_plot
                s = const+ coef*(rs(:,dim1));
                errorbar(rs(:,2),s,rs(:,dim2) , rs_color,'MarkerSize',marker_size, 'Marker', rs_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+rs(:,dim2)));
                y_min = min(y_min, min(s-rs(:,dim2)));

            end
            if ri_plot
                s = const+ coef*(ri(:,dim1));
                errorbar(ri(:,2),s,ri(:,dim2) , ri_color,'MarkerSize',marker_size, 'Marker', ri_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+ri(:,dim2)));
                y_min = min(y_min, min(s-ri(:,dim2)));

            end
            if ri2_plot
                s = const+ coef*(ri2(:,dim1));
                errorbar(ri2(:,2),s,ri2(:,dim2) , ri2_color,'MarkerSize',marker_size, 'Marker', ri2_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+ri2(:,dim2)));
                y_min = min(y_min, min(s-ri2(:,dim2)));

            end
            if rm_plot
                s = const+ coef*(rm(:,dim1));
                errorbar(rm(:,2),s,rm(:,dim2) , rm_color,'MarkerSize',marker_size, 'Marker', rm_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+rm(:,dim2)));
                y_min = min(y_min, min(s-rm(:,dim2)));

            end
            if rm2_plot
                s = const+ coef*(rm2(:,dim1));
                errorbar(rm2(:,2), s,rm2(:,dim2) , rm2_color,'MarkerSize',marker_size, 'Marker', rm2_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+rm2(:,dim2)));
                y_min = min(y_min, min(s-rm2(:,dim2)));

            end
            if rm3_plot
                s = const+ coef*(rm3(:,dim1));
                errorbar(rm3(:,2),s,rm3(:,dim2) , rm3_color,'MarkerSize',marker_size, 'Marker', rm3_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+rm3(:,dim2)));
                y_min = min(y_min, min(s-rm3(:,dim2)));

            end
            if rm4_plot
                s = const+ coef*(rm4(:,dim1));
                errorbar(rm4(:,2),s,rm4(:,dim2) , rm4_color,'MarkerSize',marker_size, 'Marker', rm4_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+rm4(:,dim2)));
                y_min = min(y_min, min(s-rm4(:,dim2)));
            end
            if rm5_plot
                s = const+ coef*(rm5(:,dim1));
                errorbar(rm5(:,2),s,rm5(:,dim2) , rm5_color,'MarkerSize',marker_size, 'Marker', rm5_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+rm5(:,dim2)));
                y_min = min(y_min, min(s-rm5(:,dim2)));
            end

            if rh1_plot         
                s = const+ coef*(rh1(:,dim1))   ;
                errorbar(rh1(:,2),s,rh1(:,dim2) , rh1_color, 'MarkerSize',marker_size, 'Marker', rh1_marker,'LineWidth', 3);
                y_max = max(y_max, max(s+rh1(:,dim2)));
                y_min = min(y_min, min(s-rh1(:,dim2)));
            end 
            if kl_plot          
                s = const+ coef*(kl(:,dim1))  ;
                errorbar(kl(:,2),s,kl(:,dim2) , kl_color,'MarkerSize',marker_size, 'Marker', kl_marker, 'LineWidth', 3);
                y_max = max(y_max, max(s+kl(:,dim2)));
                y_min = min(y_min, min(s-kl(:,dim2)));
            end 
             if ~strcmpi(filename_term, 'loss')
                 y_min = 0; % 90
                 y_max = 10;
             else
                 y_min = 0;
                 y_max = 10;
             end
           % ylim([y_min y_max]);
            xlabel(['No. Users'], 'FontSize', 24); ...
                    ylabel(term, 'FontSize', 24);
                    
            hold off
            
            %%    leg = legend (legend_cell, 'Location', 'NorthWest'); % <- this is the one
    
    % set(leg, 'FontSize', 14);
   % leg = legend('EP','Laplace', 'Sparse-EP', 'Max Loss (mean+varaince max)', 'Max Loss (mean max)', ...
   %     'Max Loss (utility mean max)', 'Max Loss (utility mean+variance max)', 'IVM-EP1', 'IVM-EP2', ...
   %     'Posterior mean+variance', 'Location', 'BestOutside'); % NorthEast
	
        set(gca, 'FontSize', 24);
        %fprintf('%s', epspath);
        
        axis tight
        
        print ('-depsc', ['tex/images/' epspath '_' filename_term '_' num2str(d) additional_filename_term '.eps']);
        system(['epstopdf ' 'tex/images/' epspath '_' filename_term '_' num2str(d) additional_filename_term '.eps']);

        catch err
            fprintf('%s\n%s\n', ['plot_accuracy: ' epspath '_' filename_term '_' num2str(d) '\n'], err.message);
        end
        
    end
    
    y_max = -100;
    y_min = 100;
    
    try
        figure('visible','off');
        %hold on;
        a = [r(:,6),rl(:,6),rs(:,6),rm(:,6),ri(:,6),ri2(:,6)];
        bar(a);
        a = unique(data(:,12));
        set(gca, 'FontSize', 24);
               
        %leg = legend('EP','Laplace', 'Sparse-EP', 'Max Loss', 'IVM-EP1', 'IVM-EP2', 'Location', 'BestOutside'); %NorthWest
        if length(a) > 2, b=a(2)-a(1); else, b = a(1); end;
        xlabel(['\times ' num2str(r(2,2) - r(1,2)) ' Users' ], 'FontSize', 24); ylabel(['Loss in (Users \times ' num2str(b) ' Preferences)'], 'FontSize', 24);
        set(gca, 'FontSize', 24);
        axis tight
        %fprintf('%s', epspath);
        print ('-depsc', ['tex/images/' epspath num2str(d) '_err' additional_filename_term '.eps']);
        system(['epstopdf ' 'tex/images/' epspath num2str(d) '_err' additional_filename_term '.eps']);
    catch err
        fprintf('%s\n%s\n', ['plot_accuracy bar: ' epspath num2str(d)], err.message);
    end
    
    % ---------------------------------------------------
    tex_tbl = [0; r(:,2)];
    % ylim([-.2 1.5]);
    
    sparsity_dim = r(:,2); % .* 100 ./ max(r(:,1)); 
    
    try
        figure('visible','off');
        hold on
        if r_plot
            errorbar(sparsity_dim, r(:,6), r(:,7), r_color, 'MarkerSize',marker_size, 'Marker', r_marker,'LineWidth', 3);
            tex_tbl = [tex_tbl, [[r_data_idx, r_data_idx];r(:,[6,7])]];
            y_max = max(y_max, max(r(:,6)+r(:,7)));
            y_min = min(y_min, min(r(:,6)-r(:,7)));
        end
        if rl_plot
           errorbar(sparsity_dim, rl(:,6), rl(:,7), rl_color, 'MarkerSize',marker_size, 'Marker', rl_marker,'LineWidth', 3);
           tex_tbl = [tex_tbl, [[rl_data_idx, rl_data_idx];rl(:,[6,7])]];
	   y_max = max(y_max, max(rl(:,6)+rl(:,7)));
            y_min = min(y_min, min(rl(:,6)-rl(:,7)));
        end
        if svm_plot  && ~isempty(svm)
           errorbar(svm(:,2), svm(:,6), svm(:,7), svm_color,'MarkerSize',marker_size, 'Marker', svm_marker, 'LineWidth', 3);
           tex_tbl = [tex_tbl, [[svm_data_idx, svm_data_idx];svm(:,[6,7])]];
        	y_max = max(y_max, max(svm(:,6)+svm(:,7)));
            y_min = min(y_min, min(svm(:,6)-svm(:,7)));
        end        
        if rs_plot
             errorbar(sparsity_dim, rs(:,6), rs(:,7), rs_color,'MarkerSize',marker_size, 'Marker', rs_marker, 'LineWidth', 3);
             tex_tbl = [tex_tbl, [[rs_data_idx, rs_data_idx];rs(:,[6,7])]];
            y_max = max(y_max, max(rs(:,6)+rs(:,7)));
            y_min = min(y_min, min(rs(:,6)-rs(:,7)));
        end
        if ri_plot
              errorbar(sparsity_dim, ri(:,6), ri(:,7), ri_color,'MarkerSize',marker_size, 'Marker', ri_marker, 'LineWidth', 3);
              tex_tbl = [tex_tbl, [[ri_data_idx, ri_data_idx];ri(:,[6,7])]];
            y_max = max(y_max, max(ri(:,6)+ri(:,7)));
            y_min = min(y_min,min( ri(:,6)-ri(:,7)));
        end
        if ri2_plot
             errorbar(sparsity_dim, ri2(:,6), ri2(:,7), ri2_color,'MarkerSize',marker_size, 'Marker', ri2_marker, 'LineWidth', 3);
             tex_tbl = [tex_tbl, [[ri2_data_idx, ri2_data_idx];ri2(:,[6,7])]];
        	y_max = max(y_max, max(ri2(:,6)+ri2(:,7)));
            y_min = min(y_min, min(ri2(:,6)-ri2(:,7)));
        end
        if rm_plot
             errorbar(sparsity_dim, rm(:,6), rm(:,7), rm_color, 'MarkerSize',marker_size, 'Marker', rm_marker,'LineWidth', 3);
             tex_tbl = [tex_tbl, [[rm_data_idx, rm_data_idx];rm(:,[6,7])]];
            y_max = max(y_max,max( rm(:,6) + rm(:,7)));
            y_min = min(y_min, min(rm(:,6) - rm(:,7)));
        end
        if rm2_plot
          errorbar(sparsity_dim, rm2(:,6), rm2(:,7), rm2_color, 'MarkerSize',marker_size, 'Marker', rm2_marker,'LineWidth', 3);
          tex_tbl = [tex_tbl, [[rm2_data_idx, rm2_data_idx];rm2(:,[6,7])]];
            y_max = max(y_max, max( rm2(:,6) + rm2(:,7)));
            y_min = min(y_min, min(rm2(:,6) - rm2(:,7)));
        end
        if rm3_plot
             errorbar(sparsity_dim, rm3(:,6), rm3(:,7), rm3_color,'MarkerSize',marker_size, 'Marker', rm3_marker, 'LineWidth', 3);
             tex_tbl = [tex_tbl, [[rm3_data_idx, rm3_data_idx];rm3(:,[6,7])]];
            y_max = max(y_max, max(rm3(:,6) + rm3(:,7)));
            y_min = min(y_min, min(rm3(:,6) - rm3(:,7)));
        end
        if rm4_plot
            errorbar(sparsity_dim, rm4(:,6), rm4(:,7), rm4_color, 'MarkerSize',marker_size, 'Marker', rm4_marker,'LineWidth', 3);
            tex_tbl = [tex_tbl, [[rm4_data_idx, rm4_data_idx];rm4(:,[6,7])]];
        	y_max = max(y_max, max(rm4(:,6) + rm4(:,7)));
            y_min = min(y_min, min(rm4(:,6) - rm4(:,7)));
        end
         if rm5_plot
            errorbar(sparsity_dim, rm5(:,6), rm5(:,7), rm5_color,'MarkerSize',marker_size, 'Marker', rm5_marker, 'LineWidth', 3);
            tex_tbl = [tex_tbl, [[rm5_data_idx, rm5_data_idx];rm5(:,[6,7])]];
        	y_max = max(y_max, max(rm5(:,6) + rm5(:,7)));
            y_min = min(y_min, min( rm5(:,6) - rm5(:,7)));
        end
        if rh1_plot            
            errorbar(sparsity_dim, rh1(:,6), rh1(:,7), rh1_color,'MarkerSize',marker_size, 'Marker', rh1_marker, 'LineWidth', 3);
	            tex_tbl = [tex_tbl, [[rh1_data_idx, rh1_data_idx];rh1(:,[6,7])]];
            y_max = max(y_max, max(rh1(:,6) + rh1(:,7)));
            y_min = min(y_min, min(rh1(:,6) - rh1(:,7)));
        end 
       if kl_plot            
            errorbar(sparsity_dim, kl(:,6), kl(:,7), kl_color, 'MarkerSize',marker_size, 'Marker', kl_marker,'LineWidth', 3);
            tex_tbl = [tex_tbl, [[kl_data_idx, kl_data_idx];kl(:,[6,7])]];
        	y_max = max(y_max, max(kl(:,6) + kl(:,7)));
            y_min = min(y_min, min( kl(:,6) - kl(:,7)));
        end 
        %leg = legend('EP','Laplace', 'Sparse-EP', 'Max Loss', 'IVM-EP1', 'IVM-Ep2', 'Location', 'BestOutside'); % 'NorthEast'
        xlabel(['No. Users'], 'FontSize', 24); ylabel('Loss', 'FontSize', 24);
        %ylim([-.2 1.5]);
                        
        leg = legend (legend_cell); % , 'Location', 'NorthWest');
        legend boxoff
        ylim([y_min y_max]);
        hold off

        set(gca, 'FontSize', 24);
                
        axis tight
        
        %fprintf('%s', epspath);
        print ('-depsc', ['tex/images/' epspath num2str(d) '_errorbar' additional_filename_term '.eps']);
        system(['epstopdf ' 'tex/images/' epspath num2str(d) '_errorbar' additional_filename_term '.eps']);
    catch err
        fprintf('%s\n', ['plot_accuracy error_bar: ' err.message]);
    end
    build_tex_table(tex_tbl,  'Error bar', [epspath num2str(d) '_errorbar']);
% ---------------------------------------------------

    try

        
       	figure('visible','off');
        hold on
        y_max= 1.8;
        y_min=-1;
        tex_tbl = [0; r(:,2)];
   
        sparsity_dim = r(:,2); % .* 100 ./ max(r(:,1)); 
        
        if r_plot
             errorbar(sparsity_dim, r(:,6)./r(:,2), r(:,7)./r(:,2), r_color, ...
                 'MarkerSize',marker_size, 'Marker', r_marker,'LineWidth', 3);
             tex_tbl = [tex_tbl, [[r_data_idx, r_data_idx];[r(:,6)./r(:,2),r(:,7)./r(:,2)]]];
             y_max = max(y_max, max(r(:,6)./r(:,2)));
             y_min = min(y_min, min(r(:,6)./r(:,2)));
        end
        if rl_plot
           errorbar(sparsity_dim, rl(:,6)./rl(:,2), rl(:,7)./rl(:,2), rl_color, ...
                 'MarkerSize',marker_size, 'Marker', rl_marker, 'LineWidth', 3);
           tex_tbl = [tex_tbl, [[rl_data_idx, rl_data_idx];[rl(:,6)./rl(:,2),rl(:,7)./rl(:,2)]]];
           y_max = max(y_max, max(rl(:,6)./rl(:,2)));
           y_min = min(y_min, min(rl(:,6)./rl(:,2)));
        end
        if svm_plot && ~isempty(svm)
           errorbar(svm(:,2), svm(:,6)./svm(:,2), svm(:,7)./svm(:,2), svm_color, ...
                 'MarkerSize',marker_size, 'Marker', svm_marker, 'LineWidth', 3);
           tex_tbl = [tex_tbl, [[svm_data_idx, svm_data_idx];[svm(:,6)./svm(:,2),svm(:,7)./svm(:,2)]]];
           y_max = max(y_max, max(svm(:,6)./svm(:,2)));
           y_min = min(y_min, min(svm(:,6)./svm(:,2)));
        end
        if rs_plot
            errorbar(sparsity_dim, rs(:,6)./rs(:,2), rs(:,7)./rs(:,2), rs_color, ...
                 'MarkerSize',marker_size, 'Marker', rs_marker, 'LineWidth', 3);
            tex_tbl = [tex_tbl, [[rs_data_idx, rs_data_idx];[rs(:,6)./rs(:,2),rs(:,7)./rs(:,2)]]];
            y_max = max(y_max, max(rs(:,6)./rs(:,2)));
            y_min = min(y_min, min(rs(:,6)./rs(:,2)));
        end
        if ri_plot
              errorbar(sparsity_dim, ri(:,6)./ri(:,2), ri(:,7)./ri(:,2), ri_color, ...
                 'MarkerSize',marker_size, 'Marker', ri_marker, 'LineWidth', 3);
              tex_tbl = [tex_tbl, [[ri_data_idx, ri_data_idx];[ri(:,6)./ri(:,2),ri(:,7)./ri(:,2)]]];
              y_max = max(y_max, max(ri(:,6)./ri(:,2)));
              y_min = min(y_min, min(ri(:,6)./ri(:,2)));
        end
        if ri2_plot
             errorbar(sparsity_dim, ri2(:,6)./ri2(:,2), ri2(:,7)./ri2(:,2), ri2_color,  ...
                 'MarkerSize',marker_size, 'Marker', ri2_marker,'LineWidth', 3);
             tex_tbl = [tex_tbl, [[ri2_data_idx, ri2_data_idx];[ri2(:,6)./ri2(:,2),ri2(:,7)./ri2(:,2)]]];
             y_max = max(y_max, max(ri2(:,6)./ri2(:,2)));
             y_min = min(y_min, min(ri2(:,6)./ri2(:,2)));
        end
        if rm_plot
             errorbar(sparsity_dim, rm(:,6)./rm(:,2), rm(:,7)./rm(:,2), rm_color,  ...
                 'MarkerSize',marker_size, 'Marker', rm_marker,'LineWidth', 3);
             tex_tbl = [tex_tbl, [[rm_data_idx, rm_data_idx];[rm(:,6)./rm(:,2),rm(:,7)./rm(:,2)]]];
             y_max = max(y_max, max(rm(:,6)./rm(:,2)));
             y_min = min(y_min, min(rm(:,6)./rm(:,2)));
        end
        if rm2_plot
            errorbar(sparsity_dim, rm2(:,6)./rm2(:,2), rm2(:,7)./rm2(:,2), rm2_color, ...
                 'MarkerSize',marker_size, 'Marker', rm2_marker, 'LineWidth', 3);
            tex_tbl = [tex_tbl, [[rm2_data_idx, rm2_data_idx];[rm2(:,6)./rm2(:,2),rm2(:,7)./rm2(:,2)]]];
            y_max = max(y_max, max(rm2(:,6)./rm2(:,2)));
              y_min = min(y_min, min(rm2(:,6)./rm2(:,2)));
        end
        if rm3_plot
             errorbar(sparsity_dim, rm3(:,6)./rm3(:,2), rm3(:,7)./rm3(:,2), rm3_color, ...
                 'MarkerSize',marker_size, 'Marker', rm3_marker, 'LineWidth', 3);
             tex_tbl = [tex_tbl, [[rm3_data_idx, rm3_data_idx];[rm3(:,6)./rm3(:,2),rm3(:,7)./rm3(:,2)]]];
             y_max = max(y_max, max(rm3(:,6)./rm3(:,2)));
             y_min = min(y_min, min(rm3(:,6)./rm3(:,2)));
        end
        if rm4_plot
             errorbar(sparsity_dim, rm4(:,6)./rm4(:,2), rm4(:,7)./rm4(:,2), rm4_color, ...
                 'MarkerSize',marker_size, 'Marker', rm4_marker, 'LineWidth', 3);
             tex_tbl = [tex_tbl, [[rm4_data_idx, rm4_data_idx];[rm4(:,6)./rm4(:,2),rm4(:,7)./rm4(:,2)]]];
             y_max = max(y_max, max(rm4(:,6)./rm4(:,2)));
             y_min = min(y_min, min(rm4(:,6)./rm4(:,2)));
        end
        if rm5_plot
             errorbar(sparsity_dim, rm5(:,6)./rm5(:,2), rm5(:,7)./rm5(:,2), rm5_color, ...
                 'MarkerSize',marker_size, 'Marker', rm5_marker, 'LineWidth', 3);
             tex_tbl = [tex_tbl, [[rm5_data_idx, rm5_data_idx];[rm5(:,6)./rm5(:,2),rm5(:,7)./rm5(:,2)]]];
             y_max = max(y_max, max(rm5(:,6)./rm5(:,2)));
              y_min = min(y_min, min(rm5(:,6)./rm5(:,2)));
        end

        if rh1_plot            
           errorbar(sparsity_dim, rh1(:,6)./rh1(:,2), rh1(:,7)./rh1(:,2), rh1_color, ...
                 'MarkerSize',marker_size, 'Marker', rh1_marker, 'LineWidth', 3);
           tex_tbl = [tex_tbl, [[rh1_data_idx, rh1_data_idx];[rh1(:,6)./rh1(:,2),rh1(:,7)./rh1(:,2)]]];
           y_max = max(y_max, max(rh1(:,6)./rh1(:,2)));
              y_min = min(y_min, min(rh1(:,6)./rh1(:,2)));
        end 
        if kl_plot                        
           errorbar(sparsity_dim, kl(:,6)./kl(:,2), kl(:,7)./kl(:,2), kl_color, ...
                 'MarkerSize',marker_size, 'Marker', kl_marker, 'LineWidth', 3);
           tex_tbl = [tex_tbl, [[kl_data_idx, kl_data_idx];[kl(:,6)./kl(:,2),kl(:,7)./kl(:,2)]]];
           y_max = max(y_max, max(kl(:,6)./kl(:,2)));
              y_min = min(y_min, min(kl(:,6)./kl(:,2)));
        end 
       
        leg = legend (legend_cell); %, 'Location', 'NorthWest');
        legend boxoff
        %leg = legend('EP','Laplace', 'Sparse-EP', 'Max Loss', 'IVM-EP1', 'IVM-Ep2', 'Location', 'BestOutside'); % 'NorthEast'
    
        hold on
        %ylim([y_min y_max]);        
        if strcmpi(epspath, 'sushi')
            ylim([0 0.2]);       
        else
            ylim([0 0.7]);       
        end
        set(gca, 'FontSize', 24);
        xlabel(['No. Users' ], 'FontSize', 24); ...
                    ylabel('Normalized Recommendation Loss', 'FontSize', 24);
        %fprintf('%s', epspath);
        axis tight
        
        print ('-depsc', ['tex/images/' epspath num2str(d) '_errorbar_norm' additional_filename_term '.eps']);
        system(['epstopdf ' 'tex/images/' epspath num2str(d) '_errorbar_norm' additional_filename_term '.eps']);
        
        build_tex_table(tex_tbl,  'Normalized Recommendation Loss', [epspath num2str(d) '_errorbar_norm'], false);
    catch err
        fprintf('%s', ['plot_accuracy error bar norm: ' err.message]);
    end
        
end
% system('find tex/images/*.eps -exec epstopdf {} \;');


% system('cd tex && pdflatex -synctex=1 -interaction=nonstopmode icml.tex');
return ;

function [newr] = max_idx_unique(r,dim_idx, max_dim)
d = unique(r(:,dim_idx));
newr = [];
for i = 1 : length(d)
    t = r(r(:, dim_idx) == d(i),:);
    [dummy temp] = max(t(:,max_dim)); 
    newr = [newr;t(temp,:)];
end

return ;

function [dim] = max_dim(r, dim_idx, max_dim)
d = unique(r(:,dim_idx));
m = -Inf;
dim = 1;
for i = 1 : length(d)
    t = r(r(:,dim_idx) == d(i),:);
    temp = max(t(:,max_dim)); 
    if temp > m
       dim = d(i);
       m = temp;
    end
end
return ;

function [means] = getmeans(dims, data, col, mean_col, sig_col, no_user, user_item)
global replication_count
    means = zeros(size(dims,1),2);
    i = 1;
    
    % just for a fixed number of users    
%    if user_item
%    else        
%        data = data(data(:,2) == no_user,:);
%    end

    for d = dims'
%        if user_item
            means(i,1) = mean( data(data(:,15) == d, mean_col) );
            means(i,2) = std( data(data(:,15) == d, mean_col) ) * 2. / sqrt(replication_count);
            %if sig_col < size(data, 2) 
            %    means(i,2) = mean( data(data(:,15) == d, sig_col) );
            %else
            %    means(i,2) = 0;
            %end
%        else            
%            if col > size(data,2) || mean_col > size(data,2), return; end;
%            means(i,1) = mean( data(  data(:,col) == d, mean_col ) );        
%            if sig_col < size(data, 2) 
%                means(i,2) = mean( data( data(:,col) == d, sig_col ) );
%            else
%                means(i,2) = 0;
%            end
%        end
        i = i + 1;
    end
return ;

function build_tex_table(tex_tbl, caption, label, if_max)
    if ~exist('if_max', 'var')
       if_max = true;
    end

   tex_tbl = sortrows(tex_tbl, 1);
     
   s = '';
   % s = '\begin{table}[t]\centering';
   % s = [s '\caption{' caption '}\label{tbl:' label '}'];
    a = '|'; % c|c|c|c|
    for i = 1 : size(tex_tbl,2)/2+1
        a = [a 'c|'];
    end
    s = [s '\begin{tabular}{' a '}\hline'];    
    
    tbl_text = '';
    for j = 1  : 2 : size(tex_tbl,2)
        tbl_text = [tbl_text alg_name(tex_tbl(1,j))];
        if j < size(tex_tbl,2)
            tbl_text = [tbl_text ' & '];
        end
    end    
    tbl_text = [tbl_text '\\ \hline '];
    for i = 2 : 1 : size(tex_tbl,1)
        for j = [1, 2:2:size(tex_tbl,2)]
            if j == 1,
                ss = num2str(tex_tbl(i,j));
            else
                ss = ' & ';
                tmp = [num2str(tex_tbl(i,j), '%10.2f') ' \pm ' num2str(tex_tbl(i,j+1),'%10.2f')];
                if ( if_max &&  tex_tbl(i,j) == max(tex_tbl(i,4:2:size(tex_tbl,2))) ) || ...
                        ( ~if_max &&  tex_tbl(i,j) == min(tex_tbl(i,4:2:size(tex_tbl,2))) )
                    ss = [ss '$\bf{' tmp '}$'];
                else
                    ss = [ss '$' tmp '$'];
                end
            end
            tbl_text = [tbl_text ss];
        end
        tbl_text = [tbl_text ' \\' ];
    end
    s = [s tbl_text '\hline'];
    s = [s '\end{tabular}'];
	%s = [s '\end{table}'];

    f = fopen(['tex/tbls/tbl_' label '.tex'], 'w+');    
    fwrite(f, s);
    fclose(f);
return ;


function tbl_text = add_tex_tbl_cell(tbl_text, dims, means)
    if isempty( tbl_text ), flag = true; else, flag = false; end;
    
     for i = 1 : length(dims)
         s = '';
         cel = [' & ' means(i,1) '\textpm' means(i,2) '\\\n'];
         if flag
             s = [num2str(dims(i)) cel];
         else
             
         end
         
     end
return ;

function [tex_tbl y_min y_max] = add_row_performance(data, color, marker, marker_size, data_idx, tex_tbl, ...
                                    dims, dim1, dim2, no_user, user_item, const, coef, y_min, y_max)
    means = getmeans(dims, data, 1, dim1, dim2, no_user, user_item);
    means(:,1) = const  + coef * means(:,1);
    m = means;
    ii = ~isnan(means(:,1));
    means = means(ii,:);
    sparsity_dim = dims(ii) .* 100 ./ max(dims(:,1));                
    [ii, sparsity_dim] = select_idx(sparsity_dim);
    means = means(ii,:);
   
 % ii =  (sparsity_dim <= 85) ;
  %sparsity_dim = sparsity_dim(ii,:);
 %  means = means(ii,:);
   % ii = ismember(means(:,1),including_dim_percent);
   % means = means(ii,:);    
   % sparsity_dim = sparsity_dim(ii,:);
    % if coef > 0, means(:,2) = coef * means(:,2); end;
    if dim1 == 14,
        plot(sparsity_dim, means(:,1), color, 'Marker', marker, ...
                'MarkerSize', marker_size, 'LineWidth', 3);
    else
        hh=errorbar(sparsity_dim, means(:,1), means(:,2), color, 'Marker', marker, ...
                'MarkerSize', marker_size, 'LineWidth', 3);
	end
    %errorbar_tick(hh,bar_tick_width,2);            
    means = [[data_idx,data_idx];m];
    tex_tbl = [tex_tbl, means];
    y_max = max(y_max, max(means(:,1)+means(:,2)));
    y_min = min(y_min, min(means(:,1)-means(:,2)));
return ;

function [idx, d] = select_idx(dims)
    idx = [];
    d   = [];
    for i = 1 : length(dims)
        t = floor(dims(i) / 10)*10;
        if ((t <= 100 && mod(t,10)== 0) || (t <= 10 && t >0)) && ~ismember(t, d)
            d = [d;t];        
            idx = [idx;i];
        end
    end
return ;