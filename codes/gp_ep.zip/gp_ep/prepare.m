function [suffix D_u D_it] = prepare(suffix, i, run_ep, replication)
if ~exist('suffix', 'var')
    suffix = 'synthetic'; 
end

if ~exist('run_ep', 'var')
	run_ep = true;
end

if ~exist('replication', 'var')
	replication = 0;
end

no_folds = 1;


if strcmp(suffix, 'sushi')
    if run_ep
        item_count = prepare_sushi(i,no_folds,replication);
    end
    %D_it = [1,2,4,6,8];
elseif strcmp(suffix, 'movielense')
    if run_ep
        prepare_movielense(i);
    end 
    %D_it = [2,4,6];
elseif strcmp(suffix, 'fb')
    if run_ep
        prepare_fb(i, no_folds,replication);
    end
    %D_it = [2:4:20];
elseif strcmp(suffix, 'car') 
    if run_ep
        item_count = prepare_car(i, suffix, no_folds,replication);
    end
    %D_it = [1,2,4,6,8];
elseif strcmp(suffix, 'car_sp') || strcmp(suffix, 'car2')
    if run_ep
        prepare_car(i, suffix, no_folds,replication);
    end
     % [1,2,6,10,12,14,16,18,20,22,24];
else
    if isempty(findstr('simple', suffix))
        suffix = 'synthetic';
        if run_ep
            prepare_synthetic(i);
        end
        %D_it = [2,4,6,8,10,12,14,16,18,20];
    else
        [a b] = strtok(suffix, '-');
        if run_ep
           [a,b,c,item_count] = prepare_simple_synthetic(i, b, no_folds,replication);
           clearvars a b c
        end
        %D_it = [2,4,6,8,10,12,14,16,20];
	end
end


if ~exist('item_count', 'var')
    x = dlmread(strcat('data/x_', suffix,int2str(i ), '.', num2str(replication), '.csv'));
    item_count = size(x,1);
end

D_it =[.1:.1:1]*double(item_count); 

sparse_type = get_option('sparse_type');
if strcmpi(sparse_type, 'users_items')
    t = i * item_count;
    t=t*[.1:.1:1];
    D_u = sqrt(t);
    D_it = D_u;
    
    %D_u = [ int32(i*.1) int32(i*.2) int32(i*.3) int32(i*.4) int32(i*.5) ...
    %        int32(i*.6) int32(i*.7) int32(i*.8) int32(i*.9) i];
	%        
    %i = item_count;    
	%D_it = [ int32(i*.1) int32(i*.2) int32(i*.3) int32(i*.4) int32(i*.5) ...
    %        int32(i*.6) int32(i*.7) int32(i*.8) int32(i*.9) i];
else
    D_u = i;
end
return ;
