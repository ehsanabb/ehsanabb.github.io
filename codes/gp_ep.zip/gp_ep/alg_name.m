function s = alg_name(alg_id)
	s = '';
    
    if alg_id == 1 
        s = 'EP';
    elseif alg_id == 2
        s = 'sparse_ep';
    elseif alg_id == 3
           s = 'mel';
    elseif alg_id == 4
           s = 'Laplace';
    elseif alg_id == 5 || alg_id == 6
           s = 'IVM';
    elseif alg_id == 7
           s = 'VVM-UCB';
    elseif alg_id == 8 || alg_id == 9 || alg_id == 10 || alg_id == 11,
           s = 'VVM-VOI';
    elseif alg_id == 12
           s = 'kl';
    elseif alg_id == 20,
           s = 'SVMRank';
    end      
end