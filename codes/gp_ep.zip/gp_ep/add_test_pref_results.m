function [t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
            pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] = add_test_pref_results( ...
                    t2, t_test2, c_mean2, c_std2, test_count2, pref_loss2, ...
            pref_loss_std2, util_loss2, util_loss_std2, wrongs2, wrongs_std2, ...
            t, t_test, c_mean, c_std, pref_length, test_count, pref_loss, ...
            pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std)
   % t = [t;t+t2];
    t_test = [t_test;t_test2];
    c_mean = [c_mean;c_mean2];
    c_std = [c_std;c_std2];
    test_count = [test_count;test_count2];
    pref_length = [pref_length];            
    pref_loss = [pref_loss;pref_loss2];            
    pref_loss_std = [pref_loss_std;pref_loss_std2];      
    util_loss = [util_loss;util_loss2];
    util_loss_std = [util_loss_std;util_loss_std2];
    wrongs = [wrongs;wrongs2];
    wrongs_std = [wrongs_std;wrongs_std2];    
return ;