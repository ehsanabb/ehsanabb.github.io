function prepare_fb(user_count,no_folds, replication)

s = strcat('fb', int2str(user_count), '.', num2str(replication));  % , int2str(ITEM_LIMIT)


if exist(strcat('data/x_', s, '.csv'), 'file')
    return;
end



% first column is the ids in users and links
udata = dlmread('../fb_data/fb/users', ',');
idata = dlmread('../fb_data/fb/links', ',');
likes = dlmread('../fb_data/fb/link_likes', ',');
dislikes = dlmread('../fb_data/fb/link_dislikes', ',');

%% Limit number of items/links used
% select the most likely items
items_count = count_items(idata(:,1), likes(:,2:end), dislikes(:,2:end));
ITEM_LIMIT = 50; 
most_used_items = items_count(1:ITEM_LIMIT,1);
clear items_count;

l = [likes(:,1), sum(likes(:,2:end) > 0,2)];
d = [dislikes(:,1), sum(dislikes(:,2:end) > 0,2)];
users_activity_count = users_links_count(udata(:,1), l, d);
clear l d;
%idata = idata(1:1000,:);
%idx = [false(size(likes,1),1),~ismember(likes(:,2:end), idata(:,1))];
%likes(idx) = 0;
%idx = [false(size(dislikes,1),1),~ismember(dislikes(:,2:end), idata(:,1))];
%dislikes(idx) = 0;

%% init
pref = cell(user_count,1);
%link_ids = [[1:length(idata)]',idata(:,1)];
link_ids = zeros(size(idata,1),2);
count = 1 ;
u_idx = 0 ;
filled_user_pref = 0;
no_prefs = 0;
u_idx_idx = 0;
%%
while filled_user_pref < user_count && u_idx_idx < size(users_activity_count,1)
    u_idx_idx = u_idx_idx + 1;
    u_idx = users_activity_count(u_idx_idx,1);
    %u_idx = u_idx + 1;
    l = likes(likes(:,1) == udata(u_idx,1),2:end);
    d = dislikes(dislikes(:,1) == udata(u_idx,1),2:end);
    
    for l_idx = 1 : length(l)
        if l(l_idx) ~= 0
            for d_idx = 1 : length(d)
                if d(d_idx) ~= 0
                    if ~ismember(l(l_idx), link_ids(:,1))
                        if ~ismember(l(l_idx), most_used_items); continue; end;
                        link_ids(count, 1) = l(l_idx);
                        link_ids(count, 2) = count;
                        l1 = count;
                        count = count + 1;
                    else
                        l1 = link_ids(link_ids(:,1) == l(l_idx),2);
                    end

                    if ~ismember(d(d_idx), link_ids(:,1))
                        if ~ismember(d(d_idx), most_used_items); continue; end;
                        link_ids(count, 1) = d(d_idx);
                        link_ids(count, 2) = count;
                        d1 = count;
                        count = count + 1;
                    else
                        d1 = link_ids(link_ids(:,1) == d(d_idx),2);
                    end

                    pref{filled_user_pref+1} = [pref{filled_user_pref+1};filled_user_pref+1,l1, d1];
                end
            end
        end
    end
    
    if size(pref{filled_user_pref+1},1) > 20
        filled_user_pref = filled_user_pref + 1;
        udata(u_idx,1) = filled_user_pref;
        no_prefs = no_prefs + length(pref{filled_user_pref});
    else
        udata(u_idx,1) = 0;
    end
    
end


%udata = udata(1:user_count,2:end);
items = zeros(count -1, size(idata,2)-1);
for ii = 1 : count - 1
    items(ii,:) = idata(idata(:,1) == link_ids(ii,1),2:end);
end

p = zeros(int32(no_prefs/2),3);
p_test = zeros(int32(no_prefs/2),3);

idx = 1;
idx_test = 1;
u_idx = zeros(user_count,1);
u_idxer = 1;
id = 1;
while u_idxer <= user_count 
    tmp = pref{id};
    l = size(tmp,1);
    u_idx(u_idxer) = id;
	id = id + 1;    
    if l < 10,
        continue;
    end	
    l2 = int32(3*l/5);
    tmp = tmp(randperm(l), :);    
    tmp(:,1) = u_idxer;
    p(idx:idx+l2-1,:) = tmp(1:l2,:);
    p_test(idx_test:idx_test+(l-l2)-1,:) = tmp(l2+1:l,:);
    idx = idx + l2;
    idx_test = idx_test + (l-l2);
    u_idxer = u_idxer + 1;    
end

%% prepare to be saved
udata = udata(u_idx,:); %udata(:,1) <= user_count,:);
[dummy, idx] = sort(udata(:,1));
udata = udata(idx,2:end);
%%

p = p(p(:,1)~=0,:);
p_test = p_test(p_test(:,1)~=0,:);

udata = add_idx(udata);
items = add_idx(items);
%%


dlmwrite(strcat('data/x_', s, '.csv'), items);
dlmwrite(strcat('data/u_', s, '.csv'), udata);
dlmwrite(strcat('data/pref_', s, '.csv'), p);
dlmwrite(strcat('data/pref_', s, '_test.csv'), p_test);

partition_csv(strcat('data/pref_', s, '_test.csv'), no_folds);

return ;

%% find most liked items
function [items_count] = count_items(it, l, d)
    items_count = zeros(length(it), 2);
    all = [l(:);d(:)];
    for i = 1 : length(it)
        a = find(all == it(i));
        items_count(i,1) = it(i);
        items_count(i,2) = length(a);
    end
    [dummy idx] = sort(items_count(:,2), 'descend');
    items_count  = items_count(idx, :);
return ;


function [users_count] = users_links_count(u, l, d)
    users_count = zeros(size(u,1),2);
    for i = 1 : size(u,1)
       users_count(i,1) = i;
       users_count(i,2) = getval(l(l(:,1)==u(i),2))+ getval(d(d(:,1)==u(i),2));
    end
    [dummy idx] = sort(users_count(:,2), 'descend');
    users_count  = users_count(idx, :);
return ;

function a = getval(b)
    if isempty(b)
        a = 0;
    else
        a = b;
    end
return ;