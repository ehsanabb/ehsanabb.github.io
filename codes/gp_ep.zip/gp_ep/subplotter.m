hh = figure('visible','off');
hold on
y_max= 1.8;
y_min=-1;
tex_tbl = [0; ar(:,2)];
   
if r_plot
     errorbar(ar(:,2), ar(:,6)./ar(:,2), ar(:,7)./ar(:,2), r_color, ...
         'MarkerSize',marker_size, 'Marker', r_marker,'LineWidth', 3);
     tex_tbl = [tex_tbl, [[r_data_idx, r_data_idx];[ar(:,6)./ar(:,2),ar(:,7)./ar(:,2)]]];
     y_max = max(y_max, ar(:,7)./ar(:,2));
     y_min = min(y_min, ar(:,7)./ar(:,2));
end
if rl_plot
   errorbar(ar(:,2), arl(:,6)./arl(:,2), arl(:,7)./arl(:,2), rl_color, ...
         'MarkerSize',marker_size, 'Marker', rl_marker, 'LineWidth', 3);
   tex_tbl = [tex_tbl, [[rl_data_idx, rl_data_idx];[arl(:,6)./arl(:,2),arl(:,7)./arl(:,2)]]];
   y_max = max(y_max, arl(:,7)./arl(:,2));
   y_min = min(y_min, arl(:,7)./arl(:,2));
end
if svm_plot && ~isempty(asvm)
   errorbar(asvm(:,2), asvm(:,6)./asvm(:,2), asvm(:,7)./asvm(:,2), svm_color, ...
         'MarkerSize',marker_size, 'Marker', svm_marker, 'LineWidth', 3);
   tex_tbl = [tex_tbl, [[svm_data_idx, svm_data_idx];[asvm(:,6)./asvm(:,2),asvm(:,7)./asvm(:,2)]]];
   y_max = max(y_max, asvm(:,7)./asvm(:,2));
   y_min = min(y_min, asvm(:,7)./asvm(:,2));
end
if rs_plot
    errorbar(ar(:,2), ars(:,6)./ars(:,2), ars(:,7)./ars(:,2), rs_color, ...
         'MarkerSize',marker_size, 'Marker', rs_marker, 'LineWidth', 3);
    tex_tbl = [tex_tbl, [[rs_data_idx, rs_data_idx];[ars(:,6)./ars(:,2),ars(:,7)./ars(:,2)]]];
    y_max = max(y_max, ars(:,7)./ars(:,2));
    y_min = min(y_min, ars(:,7)./ars(:,2));
end
if ri_plot
      errorbar(ar(:,2), ari(:,6)./ari(:,2), ari(:,7)./ari(:,2), ri_color, ...
         'MarkerSize',marker_size, 'Marker', ri_marker, 'LineWidth', 3);
      tex_tbl = [tex_tbl, [[ri_data_idx, ri_data_idx];[ari(:,6)./ari(:,2),ari(:,7)./ari(:,2)]]];
      y_max = max(y_max, ari(:,7)./ari(:,2));
      y_min = min(y_min, ari(:,7)./ari(:,2));
end
if ri2_plot
     errorbar(ar(:,2), ari2(:,6)./ari2(:,2), ari2(:,7)./ari2(:,2), ri2_color,  ...
         'MarkerSize',marker_size, 'Marker', ri2_marker,'LineWidth', 3);
     tex_tbl = [tex_tbl, [[ri2_data_idx, ri2_data_idx];[ari2(:,6)./ari2(:,2),ari2(:,7)./ari2(:,2)]]];
     y_max = max(y_max, ari2(:,7)./ari2(:,2));
     y_min = min(y_min, ari2(:,7)./ari2(:,2));
end
if rm_plot
     errorbar(ar(:,2), arm(:,6)./arm(:,2), arm(:,7)./arm(:,2), rm_color,  ...
         'MarkerSize',marker_size, 'Marker', rm_marker,'LineWidth', 3);
     tex_tbl = [tex_tbl, [[rm_data_idx, rm_data_idx];[arm(:,6)./arm(:,2),arm(:,7)./arm(:,2)]]];
     y_max = max(y_max, arm(:,7)./arm(:,2));
     y_min = min(y_min, arm(:,7)./arm(:,2));
end
if rm2_plot
    errorbar(ar(:,2), arm2(:,6)./arm2(:,2), arm2(:,7)./arm2(:,2), rm2_color, ...
         'MarkerSize',marker_size, 'Marker', rm2_marker, 'LineWidth', 3);
    tex_tbl = [tex_tbl, [[rm2_data_idx, rm2_data_idx];[arm2(:,6)./arm2(:,2),arm2(:,7)./arm2(:,2)]]];
    y_max = max(y_max, arm2(:,7)./arm2(:,2));
      y_min = min(y_min, arm2(:,7)./arm2(:,2));
end
if rm3_plot
     errorbar(ar(:,2), arm3(:,6)./arm3(:,2), arm3(:,7)./arm3(:,2), rm3_color, ...
         'MarkerSize',marker_size, 'Marker', rm3_marker, 'LineWidth', 3);
     tex_tbl = [tex_tbl, [[rm3_data_idx, rm3_data_idx];[arm3(:,6)./arm3(:,2),arm3(:,7)./arm3(:,2)]]];
     y_max = max(y_max, arm3(:,7)./arm3(:,2));
     y_min = min(y_min, arm3(:,7)./arm3(:,2));
end
if rm4_plot
     errorbar(r(:,2), arm4(:,6)./arm4(:,2), arm4(:,7)./arm4(:,2), rm4_color, ...
         'MarkerSize',marker_size, 'Marker', rm4_marker, 'LineWidth', 3);
     tex_tbl = [tex_tbl, [[rm4_data_idx, rm4_data_idx];[arm4(:,6)./arm4(:,2),arm4(:,7)./arm4(:,2)]]];
     y_max = max(y_max, arm4(:,7)./arm4(:,2));
     y_min = min(y_min, arm4(:,7)./arm4(:,2));
end
if rm5_plot
     errorbar(r(:,2), arm5(:,6)./arm5(:,2), arm5(:,7)./arm5(:,2), rm5_color, ...
         'MarkerSize',marker_size, 'Marker', rm5_marker, 'LineWidth', 3);
     tex_tbl = [tex_tbl, [[rm5_data_idx, rm5_data_idx];[arm5(:,6)./arm5(:,2),arm5(:,7)./arm5(:,2)]]];
     y_max = max(y_max, arm5(:,7)./arm5(:,2));
      y_min = min(y_min, arm5(:,7)./arm5(:,2));
end

if rh1_plot            
   errorbar(ar(:,2), arh1(:,6)./arh1(:,2), arh1(:,7)./arh1(:,2), rh1_color, ...
         'MarkerSize',marker_size, 'Marker', rh1_marker, 'LineWidth', 3);
   tex_tbl = [tex_tbl, [[rh1_data_idx, rh1_data_idx];[arh1(:,6)./arh1(:,2),arh1(:,7)./arh1(:,2)]]];
   y_max = max(y_max, arh1(:,7)./arh1(:,2));
      y_min = min(y_min, arh1(:,7)./arh1(:,2));
end 
if kl_plot                        
   errorbar(ar(:,2), akl(:,6)./akl(:,2), akl(:,7)./akl(:,2), kl_color, ...
         'MarkerSize',marker_size, 'Marker', kl_marker, 'LineWidth', 3);
   tex_tbl = [tex_tbl, [[kl_data_idx, kl_data_idx];[akl(:,6)./akl(:,2),akl(:,7)./akl(:,2)]]];
   y_max = max(y_max, akl(:,7)./akl(:,2));
   y_min = min(y_min, akl(:,7)./akl(:,2));
end 


ylim([y_min y_max]);
xlabel(['No. Users, Sparse Dimensions: ' num2str(d)], 'FontSize', 24); ylabel('Normalized Loss', 'FontSize', 24);
hold off

set(gca, 'FontSize', 24)        ;
        