    %load(['cache/params_', suffix, '.mat']);
    %tic
function [sparse_items, sparse_users idx] = find_ivm_items(x,u, pref, entropy_ivm, D_u, D_it)
    item_count = size(x,1);
    ee = sortrows(entropy_ivm, 2); %-
	if D_u * D_it >= length(ee),
         sparse_users = 1:size(u,1);
         sparse_items = [];
        for uu =  sparse_users
            sparse_items{uu} = 1:size(x,1);
        end
        idx = 1 : D_u * D_it;
        return ;
    end
    idx = zeros(int32(D_u * D_it), 1);
    i = 1;
    idx_i = 1;

    if D_u >= size(u,1)
        sparse_users = 1:size(u,1);
    end

    pref_length = size(pref,1);
    sparse_u_idx = 1;
    sparse_items = cell(size(u,1), 1);

    while idx_i <= D_u * D_it && i < size(ee,1)

        if D_u < size(u,1) && sparse_u_idx <= D_u
            sparse_users(sparse_u_idx) = pref(ee(i, 1), 1);
            sparse_u_idx = sparse_u_idx + 1;
        end 
        ui = ee(i, 1) ;
        if isinf( ui ) || isnan(ui)  || ui == 0          
            for j = 1 : D_u
                if length(sparse_items{j}) < D_it
                    ui = j;
                    break;
                end
            end
            if isinf(ui), continue; end;
            it = round(rand * D_it);
            item_idx = itemOffset(ui, it, item_count);
            idx(idx_i) = item_idx;
            idx_i = idx_i + 1;
            if length(sparse_items{ui}) < D_it,
                sparse_items{ui} = [sparse_items{ui};it];
            end
        else
           item_idx = itemOffset(pref(ui, 1), pref(ui, 2), item_count);
            if(length(sparse_items{pref(ui, 1)}) < D_it)
                idx(idx_i) = item_idx;
                idx_i = idx_i + 1;
                if length(sparse_items{pref(ui, 1)}), %length(sparse_items{ui}) < D_it,
                    sparse_items{pref(ui, 1)} = [sparse_items{pref(ui, 1)};pref(ui, 2)];
                end
            end

            item_idx = itemOffset(pref(ui, 1), pref(ui, 3), item_count);
            if(length(sparse_items{pref(ui, 1)}) < D_it)
                idx(idx_i) = item_idx;
                idx_i = idx_i + 1;
                if length(sparse_items{pref(ui, 1)}) < D_it, % length(sparse_items{ui}) < D_it,
                    sparse_items{pref(ui, 1)} = [sparse_items{pref(ui, 1)};pref(ui, 3)];
                end
            end 
        end    
        i = i + 1;
    end
    
return ;