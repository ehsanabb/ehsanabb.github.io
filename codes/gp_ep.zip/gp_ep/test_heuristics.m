function [t, t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
            util_loss, util_loss_std, wrongs, wrongs_std]  = test_heuristics(suffix, D_u, D_it, utils, beta, alpha)
global FID covfunc_u covfunc_x params_u params_it item_count mu;

FID = fopen('results/mel.txt','w');

load (['cache/params_', suffix, '.mat']);
tic 
% mu = nu' * sig;
% mu = sig * nu;

item_count = size(x,1);

if ~exist('beta', 'var')
    beta = 1;
end

if ~exist('alpha', 'var')
    alpha = 1;
end

items = {};
for ui = 1 : size(u,1)    
  %  items{ui} = [];
  idx = ( [1:item_count] + ((ui-1) * (item_count)) );
   [m,s] = normmax(mu(idx), sig(idx,idx));
   beta = .5; %beta * 1 / (2 * m); % -1. / (2 * s);
   alpha = 1 * alpha; % beta * m;
  [vals, idx] = sort(alpha * mu( idx ) +  beta * diag(sig(idx,idx)), 'descend' ); % .5 was on sig side
  items{ui} = idx(1:D_it);
end 

fclose(FID);
t = toc;

[t_test, c_mean, c_std, test_count, pref_loss, pref_loss_std, ...
            util_loss, util_loss_std, wrongs, wrongs_std] = test_preference(1:size(u,1), items, nu, x, u, ...
        pref, pref_test, covfunc_u, covfunc_x, params_u, params_it, ['heu' num2str(alpha) num2str(beta)], utils);

end
