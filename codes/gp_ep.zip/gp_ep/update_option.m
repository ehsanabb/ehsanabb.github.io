function update_option(param, val)
    eval([param '=' char(39) val char(39) ';']);
    clear param val
        
    save('options.mat', '-append');	
return ;