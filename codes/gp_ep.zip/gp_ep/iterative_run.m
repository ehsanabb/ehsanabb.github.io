function iterative_run(suffix, iteration, run_ep, replication_count)
global FID_RESULTS RUN_EP

clc

if ~exist('iteration', 'var') || isempty(iteration)
    iteration = 15:10:70;
end

results = [];

if ~exist('replication_count', 'var')    
    reeplication_count = 20;
end

if exist('run_ep', 'var')
    RUN_EP = run_ep;
else
    RUN_EP = true;
end

%if FID_RESULTS < 1
if ~exist('suffix', 'var')
    suffix = '';
end

[FID_RESULTS filename new_suffix]= get_results_file(suffix);
if strcmp(new_suffix, 'car_sp')
	% new_suffix = 'car2';
end
%end

for k = 1 : replication_count
    for i = iteration %5 : 10 : 15
       single_run(i, suffix, k);
    end
    % dlmwrite(strcat('results/all_results_sparse_', dt, int2str(k), '.csv'), results);
end

fclose(FID_RESULTS);
fclose('all');

fprintf('''%s'', ''%s''\n', filename, new_suffix);
% if strcmpi(get_option('sparse_type'), 'users_items')
%     no_users = -1;
% else
no_users = max(iteration);
% end



%plot_accuracy(filename, new_suffix, no_users, replication_count);
end

