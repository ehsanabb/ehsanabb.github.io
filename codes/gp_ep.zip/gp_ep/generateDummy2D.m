
size = 10;
X1 = 10 * randn(size,2);
%scatter(X1(:,1), X1(:,2), 'r');
%hold on
X2 = 40 + 10 * randn(size,2);
%scatter(X2(:,1), X2(:,2), 'b');
X3 = 80 + 10 * randn(size,2);
%scatter(X3(:,1), X3(:,2), 'g');
%hold off

u = [0,10;
    40,10;
    80,10];
X = [X1;X2;X3];
scatter(X(:,1), X(:,2), 'b.');
n = size/2;

x1_idx = [1:length(X1)]';
x2_idx = [length(X1) + 1: length(X1) + length(X2)]';
x3_idx = [length(X1) + length(X2) + 1: length(X1) + length(X2) + length(X3)]';
one = ones(n,1);
l = [1:size*size/4];
ll = length(l);

Pref_12 = [kron(one,x1_idx), kron(x2_idx,one)];
Pref1 = [Pref_12(l,:)];
Pref_test1 = [Pref_12(l+ll,:)];
Pref_13 = [kron(one,x1_idx), kron(x3_idx,one)];
Pref1 = [Pref1; Pref_13(l,:)];
Pref_test1 = [Pref_test1; Pref_13(l+ll,:)];
Pref = [ones(length(Pref1),1), Pref1];
Pref_test = [ones(length(Pref_test1),1), Pref_test1];
clear Pref_12
clear Pref_13
clear Pref1

Pref_21 = [kron(one,x2_idx), kron(x1_idx,one)];
Pref1 = [Pref_21(l,:)];
Pref_test1 = [Pref_21(l+ll,:)];
Pref_23 = [kron(one,x2_idx), kron(x3_idx,one)];
Pref1 = [Pref1; Pref_23(l,:)];
Pref_test1 = [Pref_test1; Pref_23(l+ll,:)];
Pref = [Pref; ones(length(Pref1),1)+1, Pref1];
Pref_test = [Pref_test; ones(length(Pref_test1),1)+1, Pref_test1];
clear Pref_21
clear Pref_23
clear Pref1

Pref_31 = [kron(one,x3_idx), kron(x1_idx,one)];
Pref1 = [Pref_31(l,:)];
Pref_test1 = [Pref_31(l+ll,:)];
Pref_32 = [kron(one,x3_idx), kron(x2_idx,one)];
Pref1 = [Pref1; Pref_32(l,:)];
Pref_test1 = [Pref_test1; Pref_32(l+ll,:)];
Pref = [Pref;ones(length(Pref1),1)+2, Pref1];
Pref_test = [Pref_test; ones(length(Pref_test1),1)+2, Pref_test1];
clear Pref_31
clear Pref_32
clear Pref1


dlmwrite('data/u_dummy.csv', u);
dlmwrite('data/x_dummy.csv', X);
dlmwrite('data/pref_dummy.csv', Pref);
dlmwrite('data/pref_dummy_test.csv', Pref_test);