if ~exist('times', 'var')
    load cache/params_sushi200.mat
    times = [];
    for i = 1 : 10 : 110
        idx = randperm(size(Sigma,1),min(size(Sigma,1),i * size(Sigma,1) / 100));
        tic
        inv(Sigma(idx,idx));    
         times = [times;
                    [i,toc]];
        disp(i);
    end
end 

r_color = 'b--';
rl_color = 'y--';
rs_color = 'r';
rm_color = '[0.2 0.2 .2]';
ri_color = 'k';
ri2_color = 'm';
rh1_color = 'g';
rm2_color = 'b';
rm3_color = 'c';
rm4_color = 'b';
rm5_color = '[0.2 0.2 .2]';
kl_color = 'r';
svm_color = 'r--';

r_marker = 'o';
rl_marker= 'o';
rs_marker = '+';
rm_marker= '*';
ri_marker = 'v';
ri2_marker = 'd';
rh1_marker = 's';
rm2_marker= '+';
rm3_marker = '+';
rm4_marker = '*';
rm5_marker = 'v';
kl_marker = 'd';
svm_marker = '*';

marker_size = 10;

hold on
plot(times(:,1), times(:,2), rh1_color, 'LineWidth', 2, 'Marker', rh1_marker, 'MarkerSize', marker_size);
plot(times(:,1), times(:,4), rm2_color, 'LineWidth', 2, 'Marker',rm2_marker, 'MarkerSize', marker_size);
plot(times(:,1), times(:,3), ri_color,'LineWidth', 2, 'Marker',ri_marker, 'MarkerSize', marker_size);
hold off

set(gca, 'FontSize', 24);
legend('VVM-UCB', 'VVM-VOI', 'IVM', 'Location', 'NorthWest');
xlabel('Percent of items selected.', 'FontSize', 24);
ylabel('Time (s)', 'FontSize', 24);
grid on
legend boxoff

print ('-depsc', 'tex/images/sushi200_time.eps');
system(['epstopdf tex/images/sushi200_time.eps']);