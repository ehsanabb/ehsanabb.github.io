function prepare_movielens(user_count)

system('cp ../workspace/socialrec/pref_movielense_700.csv data/');
system('cp ../workspace/socialrec/u_movielense_700.csv data/');
system('cp ../workspace/socialrec/x_movielense_700.csv data/');

udata = dlmread('data/u_movielense_700.csv', ',');
idata = dlmread('data/x_movielense_700.csv', ',');
pref = dlmread('data/pref_movielense_700_1.csv', ',');

ITEM_LIMIT = 100;

x = idata(1:ITEM_LIMIT,:); 
u = udata(1:user_count,:); 
p = [];
p_test = [];
pref = pref(ismember(pref(:,1),0:user_count-1),:);

for u_id = 1 : user_count
    p_u = pref(pref(:,1)==u_id-1,:);
    p_u = p_u(p_u(:,2)<ITEM_LIMIT,:);
    p_u = p_u(p_u(:,3)<ITEM_LIMIT,:);
    p_u = p_u+1;
    %p_u(:,1) = p_u(:,1) + 1;
    l = size(p_u,1);
    l2 = int32(l/2);
    p = [p;p_u(1:l2,:)];
    p_test = [p_test;p_u(l2+1:l,:)];
end

u = add_idx(u);
x = add_idx(x);

s = strcat('movielense', int2str(user_count));

dlmwrite(strcat('data/x_', s, '.csv'), x);
dlmwrite(strcat('data/u_', s, '.csv'), u);
dlmwrite(strcat('data/pref_', s, '.csv'), p);
dlmwrite(strcat('data/pref_', s, '_test.csv'), p_test);


return ;